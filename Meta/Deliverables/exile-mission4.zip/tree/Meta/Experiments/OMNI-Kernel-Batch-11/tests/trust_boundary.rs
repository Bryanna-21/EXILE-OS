//! TRUST-BOUNDARY DEMONSTRATION (mission "Core Execution and Trust Boundary", Phase 6). HOSTED.
//!
//! WHAT THIS IS: two or more kernel-scheduled contexts ("spaces"), each behind its own software page tables that
//! are walked by the Batch 8 mapper code, driven through the real syscall layer of this crate (`IpcKernel`).
//! WHAT THIS IS NOT: hardware enforcement. The MMU, ring 3, page faults and context switches are SIMULATED on the
//! host. Passing here is NOT evidence that isolation works on a CPU; that needs a booted target (see
//! Documentation/Architecture/Platform/TRUST_BOUNDARY_STATUS.md; the QEMU run is BLOCKED in this environment).
//!
//! Items (mission numbering): 1 independent contexts, 2 protected memory, 3 rejected unauthorized memory access,
//! 4 invalid/stale/revoked capabilities, 5 authorized vs unauthorized IPC, 6 containment of a failed process,
//! 7 recovery of a failed service.
#[path = "../../OMNI-Kernel-Batch-9/tests/common/mod.rs"]
mod common;
use common::*;
use exile_platform::supervisor::{
    Effects, Event as SupEvent, Policy, Refused, ServiceId, State as SupState, Supervisor,
};
use omni_kernel7::sched::SpaceId;
use omni_kernel7::syscall::SyscallFrame;
use omni10::abi::AbiMode;
use omni11::audit::Kind;
use omni11::caps::*;
use omni11::status;
use omni11::sys::*;

const CREATE: u64 = BASE;
const SARGS: u64 = BASE + 0x100;
const MSG: u64 = BASE + 0x200;
const DESCS: u64 = BASE + 0x700;
const RBUF: u64 = BASE + 0x1000;
const RRES: u64 = BASE + 0x1800;
const RARGS: u64 = BASE + 0x1900;
const ONLY_IN_2: u64 = BASE + 0x10000; // mapped in space 2 only
const SLEEP: u64 = 0x1F2;

fn ik(w: &World) -> &'static IpcKernel<'static> {
    Box::leak(Box::new(IpcKernel::new(w.k, w.b)))
}
fn call(ik: &IpcKernel, nr: u64, a: [u64; 6]) -> i64 {
    let mut f = SyscallFrame {
        rax: nr,
        rdi: a[0],
        rsi: a[1],
        rdx: a[2],
        r10: a[3],
        r8: a[4],
        r9: a[5],
        rcx: 0x4000_0000,
        r11: 0x202,
        user_rsp: 0x7FFF_0000,
        ..Default::default()
    };
    ik.syscall(AbiMode::Omni, &mut f);
    f.rax as i64
}
thread_local! { static BACKING: std::cell::Cell<Option<&'static dyn omni_kernel7::uaccess::UserBacking>> = const { std::cell::Cell::new(None) }; }
fn bk() -> &'static dyn omni_kernel7::uaccess::UserBacking {
    BACKING.with(|b| b.get()).expect("backing set")
}
fn poke(ik: &IpcKernel, sp: SpaceId, addr: u64, d: &[u8]) {
    let k = ik.abi.kernel;
    k.spaces
        .lock()
        .copy_to_user(bk(), sp, k.sched.loaded_space(), addr, d)
        .unwrap();
}
fn peek(ik: &IpcKernel, sp: SpaceId, addr: u64, n: usize) -> Vec<u8> {
    let k = ik.abi.kernel;
    let mut v = vec![0u8; n];
    k.spaces
        .lock()
        .copy_from_user(bk(), sp, k.sched.loaded_space(), addr, &mut v)
        .unwrap();
    v
}
fn header(op: u16, rid: u64, payload: &[u8], nh: u32) -> Vec<u8> {
    let mut m = vec![0u8; 32 + payload.len()];
    m[0..4].copy_from_slice(&((32 + payload.len()) as u32).to_le_bytes());
    m[4..6].copy_from_slice(&1u16.to_le_bytes());
    m[6..8].copy_from_slice(&op.to_le_bytes());
    m[12..14].copy_from_slice(&1u16.to_le_bytes());
    m[16..24].copy_from_slice(&rid.to_le_bytes());
    m[24..28].copy_from_slice(&(payload.len() as u32).to_le_bytes());
    m[28..32].copy_from_slice(&nh.to_le_bytes());
    m[32..].copy_from_slice(payload);
    m
}
fn dsc(h: u32, mode: u8, rights: Rights) -> [u8; 16] {
    let mut d = [0u8; 16];
    d[0..4].copy_from_slice(&h.to_le_bytes());
    d[4] = 1;
    d[5] = mode;
    d[8..12].copy_from_slice(&rights.0.to_le_bytes());
    d
}
fn send(ik: &IpcKernel, sp: SpaceId, h: u32, op: u16, payload: &[u8], descs: &[[u8; 16]]) -> i64 {
    let m = header(op, 7, payload, descs.len() as u32);
    poke(ik, sp, MSG, &m);
    for (i, d) in descs.iter().enumerate() {
        poke(ik, sp, DESCS + 16 * i as u64, d);
    }
    let mut a = [0u8; 48];
    a[0..8].copy_from_slice(&MSG.to_le_bytes());
    a[8..12].copy_from_slice(&(m.len() as u32).to_le_bytes());
    a[12..16].copy_from_slice(&(descs.len() as u32).to_le_bytes());
    a[16..24].copy_from_slice(&DESCS.to_le_bytes());
    poke(ik, sp, SARGS, &a);
    call(ik, SYS_SEND, [h as u64, SARGS, 0, 0, 0, 0])
}
/// Returns (status, payload, raw 88-byte result).
fn recv(ik: &IpcKernel, sp: SpaceId, h: u32, timeout: u64) -> (i64, Vec<u8>, Vec<u8>) {
    recv_c(ik, sp, h, timeout, 0)
}
/// Receive with a cancellation token handle (0 = none).
fn recv_c(
    ik: &IpcKernel,
    sp: SpaceId,
    h: u32,
    timeout: u64,
    cancel: u32,
) -> (i64, Vec<u8>, Vec<u8>) {
    let mut a = [0u8; 48];
    a[0..8].copy_from_slice(&RBUF.to_le_bytes());
    a[8..12].copy_from_slice(&1024u32.to_le_bytes());
    a[16..24].copy_from_slice(&RRES.to_le_bytes());
    a[24..32].copy_from_slice(&timeout.to_le_bytes());
    a[32..36].copy_from_slice(&cancel.to_le_bytes());
    poke(ik, sp, RARGS, &a);
    let r = call(ik, SYS_RECV, [h as u64, RARGS, 0, 0, 0, 0]);
    if r != 0 {
        return (r, vec![], vec![]);
    }
    let res = peek(ik, sp, RRES, 88);
    let n = u32::from_le_bytes(res[0..4].try_into().unwrap()) as usize;
    (0, peek(ik, sp, RBUF, n), res)
}
fn sender_of(res: &[u8]) -> u32 {
    u32::from_le_bytes(res[16..20].try_into().unwrap())
}
fn new_pair(ik: &IpcKernel, sp: SpaceId) -> (u32, u32) {
    assert_eq!(call(ik, SYS_ENDPOINT_CREATE, [CREATE, 0, 0, 0, 0, 0]), 0);
    let o = peek(ik, sp, CREATE, 8);
    (
        u32::from_le_bytes(o[0..4].try_into().unwrap()),
        u32::from_le_bytes(o[4..8].try_into().unwrap()),
    )
}
/// Kernel-side seeding (test only): a channel with one end in each space.
fn seed_pair(i: &IpcKernel, a: SpaceId, b: SpaceId) -> (u32, u32) {
    let mut st = i.state.lock();
    let (x, y) = st.create_pair(a).unwrap();
    let cap = st.table_mut(a).unwrap().remove(y).unwrap();
    let hb = st.table_mut(b).unwrap().insert(cap).unwrap();
    (x.0, hb.0)
}
fn setup(spaces: &[(SpaceId, bool)]) -> (World, &'static IpcKernel<'static>, Vec<u64>) {
    let w = world(false);
    let roots = spaces
        .iter()
        .map(|&(s, extra)| {
            let mut r = vec![Range::rw(BASE, 2, 0)];
            if extra {
                r.push(Range::rw(ONLY_IN_2, 1, 0));
            }
            w.space(s, &r)
        })
        .collect();
    let i = ik(&w);
    (w, i, roots)
}
macro_rules! thread {
    ($w:expr, $sp:expr, $b:expr) => {{
        let bk: &'static dyn omni_kernel7::uaccess::UserBacking = $w.b;
        spawn_fn(&$w.k.sched, $sp, move || {
            BACKING.with(|c| c.set(Some(bk)));
            $b
        })
    }};
}
fn run(w: &World) {
    let mut n = 0;
    w.k.sched.run(|s| {
        s.tick();
        n += 1;
        n < 200
    });
}
fn sleep(i: &IpcKernel, t: u64) {
    call(i, SLEEP, [t, 0, 0, 0, 0, 0]);
}

// ---- 1 + 2: independent contexts and protected memory --------------------------------------------------

#[test]
fn tb_01_02_two_contexts_have_disjoint_physical_memory_and_their_own_capability_tables() {
    let (w, i, roots) = setup(&[(2, true), (3, false)]);
    assert_ne!(roots[0], roots[1], "distinct page-table roots");
    for va in [BASE, BASE + 0x1000] {
        let (a, b) = (
            w.phys_of(roots[0], va).unwrap(),
            w.phys_of(roots[1], va).unwrap(),
        );
        assert_ne!(a, b, "same virtual address, different physical frame");
    }
    assert!(
        w.phys_of(roots[1], ONLY_IN_2).is_none(),
        "space 3 has no mapping where space 2 does"
    );
    const SECRET: &[u8] = b"space-2-secret";
    let l = log();
    let (l2, l3) = (l.clone(), l.clone());
    thread!(w, 2, {
        poke(i, 2, BASE + 0x400, SECRET);
        push(&l2, 1);
        sleep(i, 3);
        push(&l2, 4);
    });
    thread!(w, 3, {
        sleep(i, 1); // space 2 has written its secret by now
        // same virtual address in our own space: zeros, not space 2's data
        let seen = peek(i, 3, BASE + 0x400, SECRET.len());
        push(
            &l3,
            if seen == vec![0u8; SECRET.len()] {
                2
            } else {
                -2
            },
        );
        poke(i, 3, BASE + 0x400, b"space-3-data!!");
        push(&l3, 3);
    });
    run(&w);
    assert_eq!(
        snap(&l),
        [1, 2, 3, 4],
        "both contexts ran, interleaved by the scheduler"
    );
    assert_eq!(
        &(0..SECRET.len() as u64)
            .map(|o| w.byte_at(roots[0], BASE + 0x400 + o).unwrap())
            .collect::<Vec<_>>()[..],
        SECRET,
        "space 2's secret survived space 3's writes"
    );
    assert_eq!(
        w.byte_at(roots[1], BASE + 0x400),
        Some(b's'),
        "space 3 wrote only its own frame"
    );
    assert_eq!(
        i.state.lock().live_objects(),
        0,
        "no IPC objects were involved"
    );
}

// ---- 3: unauthorized memory access is rejected ---------------------------------------------------------

#[test]
fn tb_03_syscalls_reject_pointers_the_caller_may_not_touch_and_change_nothing() {
    let w = world(false);
    let r2 = w.space(2, &[Range::rw(BASE, 2, 0), Range::rw(ONLY_IN_2, 1, 0xAA)]);
    w.space(3, &[Range::rw(BASE, 2, 0)]);
    let r4 = w.space(
        4,
        &[Range::ro(BASE, 1, 0x55), Range::rw(BASE + 0x1000, 1, 0)],
    );
    let i = ik(&w);
    let l = log();
    let (l3, l4) = (l.clone(), l.clone());
    thread!(w, 3, {
        let before = i.state.lock().table(3).map(|t| t.len()).unwrap_or(0);
        // output pointer into memory that exists only in space 2
        push(
            &l3,
            call(i, SYS_ENDPOINT_CREATE, [ONLY_IN_2, 0, 0, 0, 0, 0]),
        );
        // kernel-half and null-page pointers
        push(
            &l3,
            call(
                i,
                SYS_ENDPOINT_CREATE,
                [0xFFFF_8000_0000_0000, 0, 0, 0, 0, 0],
            ),
        );
        push(&l3, call(i, SYS_ENDPOINT_CREATE, [0, 0, 0, 0, 0, 0]));
        let after = i.state.lock().table(3).map(|t| t.len()).unwrap_or(0);
        push(&l3, (after - before) as i64);
    });
    thread!(w, 4, {
        // output pointer into a READ-ONLY page of our own space
        push(&l4, call(i, SYS_ENDPOINT_CREATE, [BASE, 0, 0, 0, 0, 0]));
        let t = i.state.lock().table(4).map(|t| t.len()).unwrap_or(0);
        push(&l4, t as i64);
    });
    run(&w);
    let got = snap(&l);
    // thread 3 logs 4 values (3 results + count of new caps), thread 4 logs 2 (result + table size)
    assert_eq!(got.len(), 6, "{got:?}");
    let errs = [got[0], got[1], got[2], got[4]];
    let (g3, g4): (Vec<i64>, Vec<i64>) = (got[..4].to_vec(), got[4..].to_vec());
    for r in [g3[0], g3[1], g3[2], g4[0]] {
        assert!(
            r == status::FAULT || r == status::INVALID_ARGUMENT,
            "unauthorized pointer must be refused, got {r}: {got:?}"
        );
    }
    let _ = errs;
    assert_eq!(g3[3], 0, "failed calls created no capability");
    assert_eq!(g4[1], 0, "failed call left space 4's table empty");
    assert_eq!(i.state.lock().live_objects(), 0, "no kernel object leaked");
    // the memory the calls aimed at is unchanged
    assert_eq!(
        w.byte_at(r2, ONLY_IN_2),
        Some(0xAA),
        "space 2's memory untouched by space 3's attempt"
    );
    assert_eq!(
        w.byte_at(r4, BASE),
        Some(0x55),
        "read-only page still holds its original byte"
    );
    // every refusal was audited with the kernel-asserted caller
    let log = i.audit.lock();
    let failed = log.iter().filter(|e| e.kind == Kind::Failed).count();
    assert!(failed >= 4, "refusals are audited, saw {failed}");
    assert!(log.iter().any(|e| e.space == 3) && log.iter().any(|e| e.space == 4));
}

// ---- 4: invalid, stale, rights-insufficient and revoked capabilities ----------------------------------

#[test]
fn tb_04_invalid_stale_unauthorized_and_revoked_capabilities_are_rejected() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    // space 3 additionally owns handles that space 2 has never been given
    let (a23, b23) = seed_pair(i, 2, 3);
    // Handle values are per space and may coincide numerically; take one whose slot space 2 never fills
    // (high index), so the value is valid in space 3 and meaningless in space 2.
    let y_only3 = {
        let mut st = i.state.lock();
        let mut last = 0;
        for _ in 0..6 {
            last = st.create_pair(3).unwrap().1.0;
        }
        last
    };
    assert!(
        Handle(y_only3).index() >= 8,
        "slot index beyond anything space 2 will use"
    );
    // read-only capability for space 2 (cannot send): a channel end inserted with READ only
    let ro_h = {
        let mut st = i.state.lock();
        let (p, _q) = st.create_pair(3).unwrap();
        let c = *st.table(3).unwrap().get(p).unwrap();
        st.table_mut(2)
            .unwrap()
            .insert(Cap {
                rights: Rights::READ,
                ..c
            })
            .unwrap()
            .0
    };
    let (l2, l3) = (log(), log());
    let (m2, m3) = (l2.clone(), l3.clone());
    thread!(w, 2, {
        let (a, b) = new_pair(i, 2);
        push(&m2, send(i, 2, 0, 1, b"x", &[])); // never issued
        push(&m2, send(i, 2, 0x7FFF_0001, 1, b"x", &[])); // forged value
        push(&m2, send(i, 2, y_only3, 1, b"x", &[])); // valid in space 3 only
        push(&m2, send(i, 2, ro_h, 1, b"x", &[])); // right missing: READ only, send needs WRITE
        push(&m2, call(i, SYS_HANDLE_RELEASE, [a as u64, 0, 0, 0, 0, 0])); // ok
        push(&m2, send(i, 2, a, 1, b"x", &[])); // stale after release
        // revocation: a fresh live pair (c, d); copy end `d` to space 3, keep `c` alive, then close `d`
        let (_c, d) = new_pair(i, 2);
        let _ = b;
        push(
            &m2,
            send(i, 2, a23, 9, b"cap", &[dsc(d, 2, Rights::CHANNEL_DEFAULT)]),
        );
        sleep(i, 3); // space 3 receives the copy and uses it once
        push(&m2, call(i, SYS_ENDPOINT_CLOSE, [d as u64, 0, 0, 0, 0, 0])); // revoke: we hold ADMIN
        sleep(i, 3);
    });
    thread!(w, 3, {
        let (r, _, res) = recv(i, 3, b23, 20);
        push(&m3, r);
        let copy = u32::from_le_bytes(res[28..32].try_into().unwrap());
        push(&m3, i64::from(copy != 0));
        push(&m3, send(i, 3, copy, 1, b"ok", &[])); // the copy works before revocation
        sleep(i, 4);
        push(&m3, send(i, 3, copy, 1, b"late", &[])); // revoked for every holder
    });
    run(&w);
    let (g2, g3) = (snap(&l2), snap(&l3));
    let inv = status::INVALID_HANDLE;
    assert_eq!(
        g2[..6],
        [inv, inv, inv, status::ACCESS_DENIED, 0, inv],
        "{g2:?}"
    );
    assert_eq!(g2[6], 0, "authorized capability copy succeeded: {g2:?}");
    assert_eq!(g2[7], 0, "owner closed (revoked) its end: {g2:?}");
    assert_eq!(g3[..3], [0, 1, 0], "receiver got a working copy: {g3:?}");
    assert_eq!(
        g3[3], inv,
        "after revocation the other holder's copy is dead: {g3:?}"
    );
    let log = i.audit.lock();
    assert!(
        log.count(Kind::Denied) >= 5,
        "denials audited: {}",
        log.count(Kind::Denied)
    );
    assert!(
        log.iter()
            .filter(|e| e.kind == Kind::Denied)
            .all(|e| e.space == 2 || e.space == 3)
    );
}

// ---- 5: authorized and unauthorized IPC, kernel-asserted caller identity --------------------------------

#[test]
fn tb_05_ipc_requires_a_capability_and_the_receiver_learns_the_real_sender() {
    let (w, i, _) = setup(&[(2, false), (3, false), (4, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let (l2, l3, l4) = (log(), log(), log());
    let (m2, m3, m4) = (l2.clone(), l3.clone(), l4.clone());
    thread!(w, 2, {
        // payload claims to come from space 9; the claim is just bytes and carries no authority
        push(&m2, send(i, 2, a, 1, b"i am space 9", &[]));
        // bounded: the queue holds a few messages, then refuses instead of growing
        let mut full = 0;
        for _ in 0..8 {
            if send(i, 2, a, 1, b"x", &[]) == status::WOULD_BLOCK {
                full += 1;
            }
        }
        push(&m2, i64::from(full > 0));
        // an oversized message (header says 2 KiB) is rejected, not truncated
        let big = vec![0u8; 2048];
        push(&m2, send(i, 2, a, 1, &big, &[]));
    });
    thread!(w, 3, {
        sleep(i, 1);
        let (r, p, res) = recv(i, 3, b, 0);
        push(&m3, r);
        push(&m3, i64::from(&p[..] == b"i am space 9"));
        push(&m3, i64::from(sender_of(&res)));
    });
    thread!(w, 4, {
        // space 4 was never given any capability: every use of any value fails
        for h in [a, b, 0u32, 1, 0x1_0000, 0x1_0001] {
            push(&m4, send(i, 4, h, 1, b"intrude", &[]));
        }
        push(&m4, recv(i, 4, b, 0).0);
    });
    run(&w);
    let (g2, g3, g4) = (snap(&l2), snap(&l3), snap(&l4));
    assert_eq!(g2[0], 0, "authorized send");
    assert_eq!(g2[1], 1, "queue is bounded");
    assert_eq!(
        g2[2],
        status::INVALID_ARGUMENT,
        "oversized message rejected"
    );
    assert_eq!(g3[0], 0, "authorized receive");
    assert_eq!(g3[1], 1, "payload arrived intact");
    assert_eq!(
        g3[2], 2,
        "kernel stamped the real sender (space 2), not the payload's claim of 9"
    );
    assert!(
        g4.iter().all(|r| *r == status::INVALID_HANDLE),
        "unauthorized space 4 refused everywhere: {g4:?}"
    );
    let log = i.audit.lock();
    assert!(
        log.iter()
            .filter(|e| e.space == 4)
            .all(|e| e.kind == Kind::Denied),
        "all of space 4's attempts audited as denials"
    );
    assert_eq!(log.iter().filter(|e| e.space == 4).count(), 7);
    assert!(
        log.iter()
            .any(|e| e.space == 2 && e.nr == 0x102 && e.kind == Kind::Allowed)
    );
    assert!(
        log.iter()
            .any(|e| e.space == 3 && e.nr == 0x103 && e.kind == Kind::Allowed)
    );
}

// ---- 6: containment of a failed user-space process ------------------------------------------------------

#[test]
fn tb_06_a_failed_process_is_terminated_alone_and_the_others_keep_working() {
    let (w, i, roots) = setup(&[(2, false), (3, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let (l2, l3) = (log(), log());
    let (m2, m3) = (l2.clone(), l3.clone());
    thread!(w, 3, {
        // misbehaves: wild pointers (refused), then blocks forever waiting; will be terminated
        push(
            &m3,
            call(i, SYS_ENDPOINT_CREATE, [0xDEAD_0000, 0, 0, 0, 0, 0]),
        );
        let (r, _, _) = recv(i, 3, b, 1000);
        push(&m3, 999 + r); // never reached: the thread is killed
    });
    thread!(w, 2, {
        poke(i, 2, BASE + 0x40, b"survivor");
        sleep(i, 2);
        // the kernel's response to the fault: terminate that process only
        push(&m2, i.terminate_space(3).map(|n| n as i64).unwrap_or(-99));
        // failure is REPORTED to the peer, not silent
        push(&m2, send(i, 2, a, 1, b"anyone?", &[]));
        // and the healthy process can still use the kernel normally
        let (x, _y) = new_pair(i, 2);
        push(&m2, send(i, 2, x, 1, b"still alive", &[]));
        push(&m2, i64::from(peek(i, 2, BASE + 0x40, 8) == b"survivor"));
    });
    run(&w);
    let (g2, g3) = (snap(&l2), snap(&l3));
    assert_eq!(g3.len(), 1, "the failed process never resumed: {g3:?}");
    assert!(g3[0] == status::FAULT || g3[0] == status::INVALID_ARGUMENT);
    assert_eq!(g2[0], 1, "one thread terminated");
    assert_eq!(g2[1], status::PEER_DEAD, "failure reported to the peer");
    assert_eq!(g2[2], 0, "survivor still gets service");
    assert_eq!(g2[3], 1, "survivor's memory intact");
    let _ = roots;
    assert!(
        i.audit
            .lock()
            .iter()
            .any(|e| e.kind == Kind::SpaceTerminated && e.space == 3)
    );
    assert_eq!(
        i.state.lock().table(3).map_or(0, |t| t.len()),
        0,
        "terminated space holds no authority"
    );
}

// ---- 7: recovery of a failed service -----------------------------------------------------------------------

struct Fx {
    i: &'static IpcKernel<'static>,
    k: &'static omni_kernel7::syscall::Kernel,
    b: &'static dyn omni_kernel7::uaccess::UserBacking,
    client: SpaceId,
    svc: SpaceId,
    handles: std::cell::Cell<(u32, u32)>, // (client's end, service's end) of the current incarnation
    events: std::cell::RefCell<Vec<SupEvent>>,
    refuse: std::cell::Cell<bool>,
}
impl Effects for Fx {
    fn grant_caps(&mut self, _id: ServiceId, _inc: u32) -> Result<(), Refused> {
        if self.refuse.get() {
            return Err(Refused);
        }
        // fresh channel: one end to the service space, the other to its client
        self.handles.set(seed_pair(self.i, self.client, self.svc));
        Ok(())
    }
    fn spawn(&mut self, _id: ServiceId, inc: u32) -> Result<(), Refused> {
        let (i, b, svc_h, svc) = (self.i, self.b, self.handles.get().1, self.svc);
        let _ = spawn_fn(&self.k.sched, self.svc, move || {
            BACKING.with(|c| c.set(Some(b)));
            // serve: answer every request with its incarnation number
            for _ in 0..8 {
                let (r, _, _) = recv(i, svc, svc_h, 30);
                if r == 0 {
                    send(i, svc, svc_h, 2, format!("served-by-{inc}").as_bytes(), &[]);
                }
            }
        });
        Ok(())
    }
    fn kill(&mut self, _id: ServiceId, _inc: u32) {
        let _ = self.i.terminate_space(self.svc);
    }
    fn revoke_caps(&mut self, _id: ServiceId, _inc: u32) {
        // service loses everything; the client's handle to the dead incarnation is revoked too
        self.i.cleanup_space(self.svc);
        let (ch, _) = self.handles.get();
        let mut st = self.i.state.lock();
        if let Some(t) = st.table_mut(self.client) {
            t.remove(Handle(ch));
        }
        st.gc(&self.k.sched);
    }
    fn audit(&mut self, ev: SupEvent) {
        if let SupEvent::Started(_, inc) = ev
            && inc > 1
        {
            self.i
                .audit
                .lock()
                .push(Kind::ServiceRestart, self.svc, 0, i64::from(inc));
        }
        self.events.borrow_mut().push(ev);
    }
}

#[test]
fn tb_07_a_crashed_service_is_restarted_and_clients_reacquire_fresh_authority() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (k, b) = (w.k, w.b);
    let l = log();
    let m = l.clone();
    let result = std::sync::Arc::new(std::sync::Mutex::new(None));
    let res2 = result.clone();
    thread!(w, 2, {
        let fx = &mut Fx {
            i,
            k,
            b,
            client: 2,
            svc: 3,
            handles: Default::default(),
            events: Default::default(),
            refuse: Default::default(),
        };
        let id = ServiceId(7);
        let pol = Policy {
            max_failures: 3,
            backoff_base: 4,
            backoff_cap: 64,
            stable_after: 1000,
            health_timeout: 0,
            start_timeout: 50,
        };
        let mut sup = Supervisor::<2>::new();
        sup.register(id, pol).unwrap();
        sup.start(id, 0, fx).unwrap();
        sup.started(id, 1, 0, fx).unwrap();
        // --- incarnation 1 works
        let h1 = fx.handles.get().0;
        push(&m, send(i, 2, h1, 1, b"ping", &[]));
        let (r, p, _) = recv(i, 2, h1, 20);
        push(&m, r);
        push(&m, i64::from(p == b"served-by-1"));
        // --- crash: kernel terminates the process; the supervisor learns of the exit
        fx.kill(id, 1);
        sup.exited(id, 1, 139, 10, fx).unwrap();
        push(&m, send(i, 2, h1, 1, b"ping", &[])); // old authority is revoked
        let st = sup.status(id).unwrap();
        push(
            &m,
            i64::from(matches!(st.0, SupState::Backoff { until: 14 })),
        );
        sup.tick(13, fx);
        push(&m, i64::from(sup.status(id).unwrap().1 == 1)); // not restarted before backoff elapses
        sup.tick(14, fx);
        sup.started(id, 2, 14, fx).unwrap();
        // --- incarnation 2: client reacquired a fresh handle
        let h2 = fx.handles.get().0;
        assert_ne!(h2, h1, "a fresh capability, not the old one");
        push(&m, send(i, 2, h2, 1, b"ping", &[]));
        let (r, p, _) = recv(i, 2, h2, 20);
        push(&m, r);
        push(&m, i64::from(p == b"served-by-2"));
        push(&m, send(i, 2, h1, 1, b"ping", &[])); // the dead incarnation's handle never works again
        *res2.lock().unwrap() = Some((sup.status(id), fx.events.borrow().clone()));
    });
    run(&w);
    let g = snap(&l);
    assert_eq!(g[0], 0, "{g:?}");
    assert_eq!(g[1], 0);
    assert_eq!(g[2], 1, "incarnation 1 served the request");
    assert_eq!(
        g[3],
        status::INVALID_HANDLE,
        "authority of the crashed incarnation was revoked"
    );
    assert_eq!(g[4], 1, "backoff scheduled");
    assert_eq!(g[5], 1, "no restart before the backoff elapsed");
    assert_eq!(g[6], 0, "send to the new incarnation");
    assert_eq!(g[7], 0);
    assert_eq!(g[8], 1, "incarnation 2 served the request");
    assert_eq!(
        g[9],
        status::INVALID_HANDLE,
        "stale handle stays dead: {g:?}"
    );
    let (st, ev) = result.lock().unwrap().take().expect("driver finished");
    assert!(matches!(st, Some((SupState::Running { .. }, 2))));
    let pos = |e: SupEvent| {
        ev.iter()
            .position(|x| *x == e)
            .unwrap_or_else(|| panic!("missing {e:?} in {ev:?}"))
    };
    assert!(
        pos(SupEvent::Failure(
            ServiceId(7),
            1,
            exile_platform::supervisor::Reason::Exited(139)
        )) < pos(SupEvent::CapsGranted(ServiceId(7), 2))
    );
    assert!(
        pos(SupEvent::CapsRevoked(ServiceId(7), 1)) < pos(SupEvent::CapsGranted(ServiceId(7), 2)),
        "revoke before regrant"
    );
    let log = i.audit.lock();
    assert!(
        log.iter()
            .any(|e| e.kind == Kind::ServiceRestart && e.result == 2),
        "restart audited in the kernel ring"
    );
    assert!(
        log.iter()
            .any(|e| e.kind == Kind::SpaceTerminated && e.space == 3)
    );
}

// ---- 4b: a stale capability can never alias a NEW object that reuses the same pool slot ----------------------

#[test]
fn tb_08_stale_capability_does_not_alias_a_reused_object_slot() {
    let w = world(false);
    w.space(2, &[Range::rw(BASE, 1, 0)]);
    w.space(3, &[Range::rw(BASE, 1, 0)]);
    let i = ik(&w);
    let mut st = i.state.lock();
    let (a, _b) = st.create_pair(2).unwrap();
    let old = *st.table(2).unwrap().get(a).unwrap();
    // destroy it (revocation), then create a new pair: the pool slot is reused with a new generation
    let (oi, _) = st.resolve(2, a, ObjectType::Channel, Rights::NONE).unwrap();
    st.close(oi, &w.k.sched);
    let (a2, _b2) = st.create_pair(2).unwrap();
    let new = *st.table(2).unwrap().get(a2).unwrap();
    assert_eq!(
        new.obj, old.obj,
        "precondition: the same pool slot was reused"
    );
    assert_ne!(new.obj_gen, old.obj_gen, "but with a different generation");
    // an attacker-controlled holder (space 3) presents the OLD capability value for that slot
    let h = st.table_mut(3).unwrap().insert(old).unwrap();
    assert_eq!(
        st.resolve(3, h, ObjectType::Channel, Rights::NONE).err(),
        Some(status::INVALID_HANDLE),
        "stale object generation must be rejected even though the slot is live again"
    );
    // control: the genuine new capability resolves
    let h2 = st.table_mut(3).unwrap().insert(new).unwrap();
    assert!(st.resolve(3, h2, ObjectType::Channel, Rights::NONE).is_ok());
}

// ---- cancellation tokens (0x104 create, 0x105 signal): contract 1.2 -------------------------------------------
// HOSTED tests of the Rust test-bed kernel, like everything above. Semantics under test:
//   * a token is a capability object of type Cancellation; rights SIGNAL (signal it) and WAIT (name it in a wait);
//   * signal is sticky and idempotent; a wait that names a signalled token returns CANCELLED and consumes NOTHING;
//   * a signal wakes every thread currently blocked on that token, and no other thread;
//   * tokens share the object pool, generations and GC with channels (stale handles are rejected, space exit frees them).

fn dsc_t(h: u32, otype: u8, mode: u8, rights: Rights) -> [u8; 16] {
    let mut d = dsc(h, mode, rights);
    d[4] = otype;
    d
}
fn send_c(ik: &IpcKernel, sp: SpaceId, h: u32, cancel: u32) -> i64 {
    let m = header(1, 7, b"p", 0);
    poke(ik, sp, MSG, &m);
    let mut a = [0u8; 48];
    a[0..8].copy_from_slice(&MSG.to_le_bytes());
    a[8..12].copy_from_slice(&(m.len() as u32).to_le_bytes());
    a[32..36].copy_from_slice(&cancel.to_le_bytes());
    poke(ik, sp, SARGS, &a);
    call(ik, SYS_SEND, [h as u64, SARGS, 0, 0, 0, 0])
}
fn new_token(ik: &IpcKernel, sp: SpaceId) -> u32 {
    assert_eq!(call(ik, SYS_CANCEL_CREATE, [CREATE, 0, 0, 0, 0, 0]), 0);
    u32::from_le_bytes(peek(ik, sp, CREATE, 4).try_into().unwrap())
}
fn signal(ik: &IpcKernel, h: u32) -> i64 {
    call(ik, SYS_CANCEL_SIGNAL, [h as u64, 0, 0, 0, 0, 0])
}
/// Kernel-side test seeding: copy a token capability into another space with the given rights.
fn give_token(i: &IpcKernel, from: SpaceId, h: u32, to: SpaceId, rights: Rights) -> u32 {
    let mut st = i.state.lock();
    let c = *st.table(from).unwrap().get(Handle(h)).unwrap();
    st.table_mut(to)
        .unwrap()
        .insert(Cap { rights, ..c })
        .unwrap()
        .0
}

#[test]
fn cn_01_token_has_its_own_type_and_rights_and_is_not_a_channel() {
    let (w, i, _) = setup(&[(2, false)]);
    let l = log();
    let m = l.clone();
    thread!(w, 2, {
        let t = new_token(i, 2);
        let (a, _b) = new_pair(i, 2);
        // rights of a new token
        let c = *i.state.lock().table(2).unwrap().get(Handle(t)).unwrap();
        push(
            &m,
            i64::from(c.otype == ObjectType::Cancellation && c.rights == Rights::CANCEL_DEFAULT),
        );
        push(
            &m,
            i64::from(!c.rights.contains(Rights::ADMIN) && !c.rights.contains(Rights::READ)),
        );
        // type confusion both ways
        push(&m, send(i, 2, t, 1, b"x", &[])); // token used as a channel
        push(&m, recv(i, 2, t, 0).0);
        push(&m, signal(i, a)); // channel used as a token
        push(&m, recv_c(i, 2, a, 0, a).0); // channel passed as the cancel handle
        push(&m, call(i, SYS_ENDPOINT_CLOSE, [t as u64, 0, 0, 0, 0, 0])); // close is for channels
        push(
            &m,
            call(i, SYS_ENDPOINT_STATS, [t as u64, BASE + 0x1A00, 0, 0, 0, 0]),
        );
        // never-issued token handle
        push(&m, signal(i, 0x7777));
        push(&m, recv_c(i, 2, a, 0, 0x7777).0);
        push(&m, send_c(i, 2, a, 0x7777));
    });
    run(&w);
    let inv = status::INVALID_HANDLE;
    assert_eq!(
        snap(&l),
        [1, 1, inv, inv, inv, inv, inv, inv, inv, inv, inv]
    );
}

#[test]
fn cn_02_a_signalled_token_cancels_the_wait_and_consumes_no_message() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let l3 = log();
    let m3 = l3.clone();
    let l2 = log();
    let m2 = l2.clone();
    let tok3 = std::sync::Arc::new(std::sync::atomic::AtomicU32::new(0));
    let t3 = tok3.clone();
    thread!(w, 2, {
        let t = new_token(i, 2);
        t3.store(
            give_token(i, 2, t, 3, Rights::WAIT),
            std::sync::atomic::Ordering::SeqCst,
        );
        push(&m2, send(i, 2, a, 1, b"queued-before-cancel", &[]));
        push(&m2, signal(i, t));
        push(&m2, signal(i, t)); // idempotent
        sleep(i, 5);
    });
    thread!(w, 3, {
        sleep(i, 2);
        let tok = tok3.load(std::sync::atomic::Ordering::SeqCst);
        // the message IS queued, but the token is already signalled: cancellation wins, nothing consumed
        let (r1, _, _) = recv_c(i, 3, b, 0, tok);
        let (r2, _, _) = recv_c(i, 3, b, 10, tok); // sticky: also immediate with a timeout
        push(&m3, r1);
        push(&m3, r2);
        push(&m3, i64::from(i.state.lock().queue_len_of_end(3, b) == 1));
        // without the token the very same message is still there
        let (r3, p, _) = recv(i, 3, b, 0);
        push(&m3, r3);
        push(&m3, i64::from(p == b"queued-before-cancel"));
    });
    run(&w);
    assert_eq!(snap(&l2), [0, 0, 0], "signal succeeds and is idempotent");
    assert_eq!(snap(&l3), [status::CANCELLED, status::CANCELLED, 1, 0, 1]);
}

#[test]
fn cn_03_signal_wakes_a_blocked_receiver_promptly_and_only_that_one() {
    let (w, i, _) = setup(&[(2, false), (3, false), (4, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let (a2, b2) = seed_pair(i, 2, 4);
    let toks = std::sync::Arc::new(std::sync::Mutex::new((0u32, 0u32, 0u32)));
    let (l3, l4, l2) = (log(), log(), log());
    let (m3, m4, m2) = (l3.clone(), l4.clone(), l2.clone());
    let (tk, tk3, tk4) = (toks.clone(), toks.clone(), toks.clone());
    thread!(w, 2, {
        let ta = new_token(i, 2);
        let tb = new_token(i, 2);
        *tk.lock().unwrap() = (
            give_token(i, 2, ta, 3, Rights::WAIT),
            give_token(i, 2, tb, 4, Rights::WAIT),
            1,
        );
        sleep(i, 3);
        push(&m2, signal(i, ta)); // cancels space 3's wait only
        sleep(i, 3);
        push(&m2, send(i, 2, a2, 1, b"for-space-4", &[])); // space 4's wait is intact and still gets this
        let _ = a;
    });
    thread!(w, 3, {
        sleep(i, 1);
        let tok = tk3.lock().unwrap().0;
        let t0 = w_ticks(i);
        let (r, _, _) = recv_c(i, 3, b, 500, tok);
        push(&m3, r);
        push(&m3, i64::from(w_ticks(i) - t0 < 100)); // woken by the signal, not by the 500-tick timeout
        // cleaned up: the channel works normally afterwards
        let (r2, _, _) = recv(i, 3, b, 0);
        push(&m3, r2);
    });
    thread!(w, 4, {
        sleep(i, 1);
        let tok = tk4.lock().unwrap().1;
        let (r, p, _) = recv_c(i, 4, b2, 500, tok);
        push(&m4, r);
        push(&m4, i64::from(p == b"for-space-4"));
    });
    run(&w);
    assert_eq!(snap(&l2), [0, 0]);
    assert_eq!(snap(&l3), [status::CANCELLED, 1, status::WOULD_BLOCK]);
    assert_eq!(
        snap(&l4),
        [0, 1],
        "a different token's wait is unaffected by the signal"
    );
}
fn w_ticks(i: &IpcKernel) -> u64 {
    i.abi.kernel.sched.ticks()
}

#[test]
fn cn_04_rights_gate_signalling_and_waiting() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (_a, b) = seed_pair(i, 2, 3);
    let l = log();
    let m = l.clone();
    thread!(w, 2, {
        let t = new_token(i, 2);
        let wait_only = give_token(i, 2, t, 3, Rights::WAIT);
        let sig_only = give_token(i, 2, t, 3, Rights::SIGNAL);
        let none = give_token(i, 2, t, 3, Rights::NONE);
        COPIES.with(|c| c.set((wait_only, sig_only, none)));
        sleep(i, 3);
        push(&m, i64::from(!i.state.lock().is_signalled_by_handle(2, t))); // nobody with insufficient rights signalled it
    });
    let l3 = log();
    let m3 = l3.clone();
    thread!(w, 3, {
        sleep(i, 1);
        let (wait_only, sig_only, none) = COPIES.with(|c| c.get());
        push(&m3, signal(i, wait_only)); // may wait, may not signal
        push(&m3, signal(i, none));
        push(&m3, recv_c(i, 3, b, 0, sig_only).0); // may signal, may not wait
        push(&m3, recv_c(i, 3, b, 0, none).0);
        push(&m3, send_c(i, 3, b, sig_only));
    });
    run(&w);
    let d = status::ACCESS_DENIED;
    assert_eq!(snap(&l3), [d, d, d, d, d]);
    assert_eq!(snap(&l), [1]);
}
thread_local! { static COPIES: std::cell::Cell<(u32, u32, u32)> = const { std::cell::Cell::new((0, 0, 0)) }; }

#[test]
fn cn_05_send_honours_a_signalled_token_and_enqueues_nothing() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let l = log();
    let m = l.clone();
    thread!(w, 2, {
        let t = new_token(i, 2);
        push(&m, send_c(i, 2, a, t)); // token live and unsignalled: normal send
        push(&m, signal(i, t));
        push(&m, send_c(i, 2, a, t)); // signalled: CANCELLED, not queued
        push(&m, i.state.lock().queue_len_of_end(3, b) as i64);
    });
    run(&w);
    assert_eq!(snap(&l), [0, 0, status::CANCELLED, 1]);
}

#[test]
fn cn_06_tokens_travel_in_messages_with_their_type_and_attenuated_rights() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (a, b) = seed_pair(i, 2, 3);
    let l2 = log();
    let l3 = log();
    let (m2, m3) = (l2.clone(), l3.clone());
    thread!(w, 2, {
        let t = new_token(i, 2);
        // copy to space 3 with WAIT only, keeping SIGNAL ourselves
        push(
            &m2,
            send(
                i,
                2,
                a,
                1,
                b"tok",
                &[dsc_t(t, 4, 2, Rights::WAIT.union(Rights::TRANSFER))],
            ),
        );
        // escalation attempt: ask for SIGNAL on a handle we hold without it
        let weak = give_token(
            i,
            2,
            t,
            2,
            Rights::WAIT
                .union(Rights::TRANSFER)
                .union(Rights::DUPLICATE),
        );
        push(
            &m2,
            send(
                i,
                2,
                a,
                1,
                b"esc",
                &[dsc_t(weak, 4, 2, Rights::SIGNAL.union(Rights::TRANSFER))],
            ),
        );
        sleep(i, 3);
        push(&m2, signal(i, t));
    });
    thread!(w, 3, {
        sleep(i, 1);
        let (r, _, res) = recv(i, 3, b, 0);
        let got = u32::from_le_bytes(res[28..32].try_into().unwrap());
        push(&m3, r);
        let c = *i.state.lock().table(3).unwrap().get(Handle(got)).unwrap();
        push(&m3, i64::from(c.otype == ObjectType::Cancellation)); // type survived the transfer
        push(
            &m3,
            i64::from(c.rights.contains(Rights::WAIT) && !c.rights.contains(Rights::SIGNAL)),
        );
        push(&m3, signal(i, got)); // attenuated: cannot signal
        let (r2, _, _) = recv_c(i, 3, b, 100, got); // the token the sender later signals cancels our wait
        push(&m3, r2);
    });
    run(&w);
    assert_eq!(
        snap(&l2),
        [0, status::ACCESS_DENIED, 0],
        "escalation by copy is refused"
    );
    assert_eq!(
        snap(&l3),
        [0, 1, 1, status::ACCESS_DENIED, status::CANCELLED]
    );
}

#[test]
fn cn_07_space_exit_frees_tokens_and_stale_handles_never_alias_a_reused_slot() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    let (l2, l3) = (log(), log());
    let (m2, m3) = (l2.clone(), l3.clone());
    let stale = std::sync::Arc::new(std::sync::atomic::AtomicU32::new(0));
    let (s2, s3) = (stale.clone(), stale.clone());
    thread!(w, 3, {
        let t = new_token(i, 3);
        s3.store(t, std::sync::atomic::Ordering::SeqCst);
        let _ = new_pair(i, 3);
        // blocks on its own token; will be terminated while waiting
        let (r, _, _) = recv_c(i, 3, 0, 1000, t); // handle 0 is no channel: fails at once
        push(&m3, r);
        let (a, _b) = new_pair(i, 3);
        let (r, _, _) = recv_c(i, 3, a, 1000, t);
        push(&m3, 999 + r); // never reached
    });
    thread!(w, 2, {
        sleep(i, 3);
        push(&m2, i.state.lock().live_objects() as i64);
        push(&m2, i.terminate_space(3).map(|n| n as i64).unwrap_or(-99));
        push(&m2, i.state.lock().live_objects() as i64); // the token and the channels are gone
        // a new token reuses the pool slot; the old handle value (in the dead space) never resolves anywhere
        let t2 = new_token(i, 2);
        let old = s2.load(std::sync::atomic::Ordering::SeqCst);
        push(&m2, signal(i, old.max(1) + 100)); // junk
        push(&m2, i64::from(t2 != 0));
    });
    run(&w);
    let g3 = snap(&l3);
    assert_eq!(
        g3,
        [status::INVALID_HANDLE],
        "first recv failed on handle 0; the second never completed: {g3:?}"
    );
    let g2 = snap(&l2);
    assert!(g2[0] >= 3, "token + 2 channel ends were live: {g2:?}");
    assert_eq!(g2[1], 1);
    assert_eq!(g2[2], 0, "terminated space released tokens and channels");
    assert_eq!(g2[3], status::INVALID_HANDLE);
    assert_eq!(g2[4], 1);
}

#[test]
fn cn_08_stale_token_capability_does_not_alias_a_new_token_in_the_same_slot() {
    let w = world(false);
    w.space(2, &[Range::rw(BASE, 1, 0)]);
    w.space(3, &[Range::rw(BASE, 1, 0)]);
    let i = ik(&w);
    let mut st = i.state.lock();
    let h = st.create_token(2).unwrap();
    let old = *st.table(2).unwrap().get(h).unwrap();
    st.table_mut(2).unwrap().remove(h).unwrap();
    st.gc(&w.k.sched); // destroys the token
    let h2 = st.create_token(2).unwrap();
    let new = *st.table(2).unwrap().get(h2).unwrap();
    assert_eq!(old.obj, new.obj, "pool slot reused");
    assert_ne!(old.obj_gen, new.obj_gen);
    let forged = st.table_mut(3).unwrap().insert(old).unwrap();
    assert_eq!(
        st.resolve(3, forged, ObjectType::Cancellation, Rights::NONE)
            .err(),
        Some(status::INVALID_HANDLE)
    );
    // a destroyed token must not mark an unrelated live channel's peer dead (tokens have no peer)
    let (x, y) = st.create_pair(2).unwrap();
    let before = st.is_peer_dead(
        st.resolve(2, x, ObjectType::Channel, Rights::NONE)
            .unwrap()
            .0,
    );
    let t3 = st.create_token(2).unwrap();
    st.table_mut(2).unwrap().remove(t3).unwrap();
    st.gc(&w.k.sched);
    let after = st.is_peer_dead(
        st.resolve(2, x, ObjectType::Channel, Rights::NONE)
            .unwrap()
            .0,
    );
    let _ = y;
    assert!(!before && !after, "destroying a token disturbed a channel");
}

#[test]
fn cn_09_token_creation_is_bounded_by_the_pool_and_leaks_nothing() {
    let w = world(false);
    w.space(2, &[Range::rw(BASE, 1, 0)]);
    let i = ik(&w);
    let mut st = i.state.lock();
    let mut made = Vec::new();
    loop {
        match st.create_token(2) {
            Ok(h) => made.push(h),
            Err(e) => {
                assert_eq!(e, status::QUOTA_EXCEEDED);
                break;
            }
        }
    }
    assert!(!made.is_empty() && made.len() <= 32);
    assert_eq!(st.live_objects(), made.len());
    for h in made {
        st.table_mut(2).unwrap().remove(h).unwrap();
    }
    st.gc(&w.k.sched);
    assert_eq!(st.live_objects(), 0, "all tokens collected");
    assert!(st.create_token(2).is_ok(), "pool usable again");
}

#[test]
fn cn_10_waiters_on_one_token_are_bounded() {
    let (w, i, _) = setup(&[(2, false)]);
    let l = log();
    let pairs: Vec<(u32, u32)> = (0..5)
        .map(|_| {
            let mut st = i.state.lock();
            let (x, y) = st.create_pair(2).unwrap();
            (x.0, y.0)
        })
        .collect();
    let tok = i.state.lock().create_token(2).unwrap().0;
    for (n, (x, _)) in pairs.iter().enumerate() {
        let (m, x) = (l.clone(), *x);
        thread!(w, 2, {
            sleep(i, n as u64);
            let (r, _, _) = recv_c(i, 2, x, 50, tok);
            push(&m, r);
        });
    }
    let m = l.clone();
    thread!(w, 2, {
        sleep(i, 20);
        push(&m, signal(i, tok));
    });
    run(&w);
    let g = snap(&l);
    assert_eq!(
        g.iter().filter(|r| **r == status::BUSY).count(),
        1,
        "exactly the fifth waiter is refused: {g:?}"
    );
    assert_eq!(
        g.iter().filter(|r| **r == status::CANCELLED).count(),
        4,
        "{g:?}"
    );
}

#[test]
fn cn_11_timed_out_and_refused_waits_leave_no_waiter_registrations_behind() {
    let (w, i, _) = setup(&[(2, false)]);
    let (x, _x2) = {
        let mut st = i.state.lock();
        let (a, b) = st.create_pair(2).unwrap();
        (a.0, b.0)
    };
    let tok = i.state.lock().create_token(2).unwrap().0;
    let l = log();
    let m = l.clone();
    thread!(w, 2, {
        // more timed-out waits than MAX_WAITERS: a leaked registration would make the 5th wait BUSY
        for _ in 0..6 {
            push(&m, recv_c(i, 2, x, 2, tok).0);
        }
        push(&m, i.state.lock().waiter_count(2, tok) as i64);
        push(&m, i.state.lock().waiter_count(2, x) as i64);
    });
    run(&w);
    let t = status::TIMED_OUT;
    assert_eq!(snap(&l), [t, t, t, t, t, t, 0, 0]);
}

#[test]
fn cn_12_a_refused_token_registration_rolls_back_the_channel_registration() {
    let (w, i, _) = setup(&[(2, false)]);
    let chans: Vec<u32> = (0..5)
        .map(|_| i.state.lock().create_pair(2).unwrap().0.0)
        .collect();
    let tok = i.state.lock().create_token(2).unwrap().0;
    let l = log();
    // four long waiters fill the token's waiter table
    for (n, &c) in chans.iter().take(4).enumerate() {
        thread!(w, 2, {
            sleep(i, n as u64);
            let _ = recv_c(i, 2, c, 40, tok);
        });
    }
    let (m, last) = (l.clone(), chans[4]);
    thread!(w, 2, {
        sleep(i, 10);
        push(&m, recv_c(i, 2, last, 40, tok).0); // fifth: BUSY
        push(&m, i.state.lock().waiter_count(2, last) as i64); // channel registration must be rolled back
    });
    run(&w);
    assert_eq!(snap(&l), [status::BUSY, 0]);
}

// ---- audit identity, forgery resistance, faults, export ---------------------------------------------------------
use omni11::audit::{Event as AuditEvent, Kind as AKind};

fn all_events(i: &IpcKernel) -> Vec<AuditEvent> {
    i.audit.lock().iter().copied().collect()
}

#[test]
fn au_01_identity_binds_once_is_attached_to_records_and_survives_termination() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    assert_eq!(i.identity_of(2), None);
    assert_eq!(i.bind_identity(2, 0xAB, 1), Ok(()));
    assert_eq!(
        i.bind_identity(2, 0xCD, 2),
        Err(status::INVALID_STATE),
        "no silent re-identification"
    );
    assert_eq!(i.bind_identity(3, 0, 1), Err(status::INVALID_ARGUMENT));
    assert_eq!(i.bind_identity(3, 5, 0), Err(status::INVALID_ARGUMENT));
    assert_eq!(i.bind_identity(99, 5, 1), Err(status::INVALID_ARGUMENT));
    assert_eq!(i.identity_of(2).unwrap().principal, 0xAB);
    thread!(w, 2, {
        let _ = new_pair(i, 2);
    });
    run(&w);
    let ev = all_events(i);
    let bound = ev.iter().find(|e| e.kind == AKind::IdentityBound).unwrap();
    assert_eq!((bound.space, bound.result), (2, 0xAB));
    let first_call = ev
        .iter()
        .find(|e| e.nr == SYS_ENDPOINT_CREATE as u16)
        .unwrap();
    assert_eq!(
        first_call.principal, 0xAB,
        "syscall records carry the principal of the acting space"
    );
    assert_eq!(
        ev.iter()
            .filter(|e| e.kind == AKind::Denied && e.nr == 0)
            .count(),
        4,
        "refused bindings are audited"
    );
    i.terminate_space(2).unwrap();
    assert_eq!(i.identity_of(2), None, "binding dropped with the space");
    let term = all_events(i)
        .into_iter()
        .find(|e| e.kind == AKind::SpaceTerminated)
        .unwrap();
    assert_eq!(
        term.principal, 0xAB,
        "termination record still names who died"
    );
}

#[test]
fn au_02_user_code_cannot_forge_or_mislabel_audit_records() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    i.bind_identity(2, 0x22, 1).unwrap();
    i.bind_identity(3, 0x33, 1).unwrap();
    thread!(w, 3, {
        // hostile space: every syscall number around the IPC range with junk, including args that look like
        // an audit request ("space 2", "kind Allowed")
        for nr in 0x0FF..=0x108u64 {
            let _ = call(i, nr, [2, 1, 0x22, 0xDEAD, 0, 0]);
            let _ = call(i, nr, [u64::MAX, u64::MAX, u64::MAX, 0, 0, 0]);
        }
    });
    run(&w);
    let before = all_events(i);
    assert!(!before.is_empty());
    for e in before.iter().filter(|e| e.kind != AKind::IdentityBound) {
        assert_eq!(
            e.space, 3,
            "every record is attributed to the real caller: {e:?}"
        );
        assert_eq!(e.principal, 0x33);
        assert!(
            matches!(e.kind, AKind::Allowed | AKind::Denied | AKind::Failed),
            "user code can only cause these: {e:?}"
        );
    }
    assert!(
        !before
            .iter()
            .any(|e| e.space == 2 && e.kind != AKind::IdentityBound),
        "space 2 never acted"
    );
    // kernel-side components cannot mint privileged kinds either
    for k in [
        AKind::Allowed,
        AKind::Denied,
        AKind::Failed,
        AKind::SpaceTerminated,
        AKind::IdentityBound,
        AKind::Fault,
    ] {
        assert!(!i.record_external(k, 2, 7), "{k:?} must be refused");
    }
    assert_eq!(
        all_events(i).len(),
        before.len(),
        "refused external records leave no trace"
    );
    assert!(i.record_external(AKind::ServiceRestart, 2, 2));
    assert!(i.record_external(AKind::PolicyDenied, 2, 9));
    let ev = all_events(i);
    assert_eq!(ev[ev.len() - 1].kind, AKind::PolicyDenied);
    assert_eq!(ev[ev.len() - 1].principal, 0x22);
}

#[test]
fn au_03_a_malformed_frame_is_audited_as_a_fault_and_kills_only_the_caller() {
    let (w, i, _) = setup(&[(2, false), (3, false)]);
    i.bind_identity(2, 0x22, 1).unwrap();
    let l = log();
    let m = l.clone();
    thread!(w, 2, {
        let mut f = omni_kernel7::syscall::SyscallFrame {
            rax: SYS_ENDPOINT_CREATE,
            rcx: 0xFFFF_8000_0000_0000, // kernel address as the user return pointer
            r11: 0x202,
            user_rsp: 0x7FFF_0000,
            ..Default::default()
        };
        i.syscall(AbiMode::Omni, &mut f);
        push(&m, 999); // never reached: the thread was terminated
    });
    let m3 = l.clone();
    thread!(w, 3, {
        push(&m3, call(i, SYS_ENDPOINT_CREATE, [CREATE, 0, 0, 0, 0, 0]));
    });
    run(&w);
    assert_eq!(
        snap(&l),
        [0],
        "space 3 unaffected, space 2's thread never resumed"
    );
    let f = all_events(i)
        .into_iter()
        .find(|e| e.kind == AKind::Fault)
        .expect("fault recorded");
    assert_eq!((f.space, f.principal), (2, 0x22));
}

#[test]
fn au_04_overflow_is_bounded_visible_and_never_blocks() {
    let (w, i, _) = setup(&[(2, false)]);
    thread!(w, 2, {
        for _ in 0..300 {
            let _ = call(i, SYS_HANDLE_RELEASE, [0x7777, 0, 0, 0, 0, 0]);
        }
    });
    run(&w);
    let log = i.audit.lock();
    assert_eq!(log.total(), 300);
    assert_eq!(log.dropped(), 300 - omni11::audit::CAPACITY as u64);
    assert_eq!(log.count(AKind::Denied), omni11::audit::CAPACITY);
    let mut out = [AuditEvent {
        seq: 0,
        kind: AKind::Failed,
        space: 0,
        nr: 0,
        principal: 0,
        result: 0,
    }; 16];
    let (n, total, dropped) = log.export(&mut out);
    assert_eq!((n, total, dropped), (16, 300, 172));
    assert_eq!(
        out[0].seq, 173,
        "export starts at the oldest surviving record; the seq gap shows the loss"
    );
}
