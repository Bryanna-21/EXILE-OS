//! Bounded audit log for security-relevant IPC/capability events.
//!
//! Contract (docs/CONTRACTS.md, "Audit"): every denied operation and every authority-changing operation
//! (endpoint create/close, send, receive, release, space termination) appends one fixed-size record.
//! The log is a ring: when full the OLDEST record is overwritten and `dropped` counts the loss, so loss
//! is always observable and the log can never block or allocate. Records carry kernel-asserted
//! identity (space and thread come from the scheduler, never from user arguments).
//!
//! Limits: the log lives in kernel memory only. Nothing persists it, ships it to a service, or protects
//! it against a kernel compromise. Hosted tests only.
//!
//! Forgery: records are only written by kernel code (`IpcKernel::ipc_entry`, `terminate_space`,
//! `bind_identity`, `record_external`). No syscall takes audit content from user memory.

use crate::status;

/// Ring capacity (records).
pub const CAPACITY: usize = 128;

/// What happened.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum Kind {
    /// Operation succeeded and changed or used authority (create/close/send/recv/release).
    Allowed = 1,
    /// Operation refused for lack of authority: invalid/stale handle or access denied.
    Denied = 2,
    /// Operation failed for another reason (bad argument, quota, timeout, ...).
    Failed = 3,
    /// A whole space was terminated and its authority released.
    SpaceTerminated = 4,
    /// A supervised service restarted (written by a supervisor through `record_external`).
    ServiceRestart = 5,
    /// A principal identity was bound to a space by the trusted launcher (`IpcKernel::bind_identity`).
    IdentityBound = 6,
    /// The kernel killed a thread for a malformed syscall frame (a fault, not a refused request).
    Fault = 7,
    /// A trusted policy component (LibExilePolicy broker, via `record_external`) denied a request.
    PolicyDenied = 8,
}

/// One record. `nr` is the syscall number (0 for non-syscall events), `result` the returned status
/// (or a count / incarnation for lifecycle events).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub struct Event {
    /// Monotonic sequence number, starting at 1. Gaps mean records were overwritten.
    pub seq: u64,
    /// Event class.
    pub kind: Kind,
    /// Acting space (kernel-asserted); 0 for the kernel itself.
    pub space: u16,
    /// Syscall number or 0.
    pub nr: u16,
    /// Principal bound to `space` when the record was written (0 = none/unbound/kernel). Captured at
    /// write time so it survives the space's termination.
    pub principal: u64,
    /// Status or event-specific value.
    pub result: i64,
}

const EMPTY: Event = Event {
    seq: 0,
    kind: Kind::Failed,
    space: 0,
    nr: 0,
    principal: 0,
    result: 0,
};

/// The ring.
pub struct AuditLog {
    buf: [Event; CAPACITY],
    next_seq: u64,
    dropped: u64,
}

impl AuditLog {
    /// Empty log.
    pub const fn new() -> Self {
        AuditLog {
            buf: [EMPTY; CAPACITY],
            next_seq: 1,
            dropped: 0,
        }
    }

    /// Classify a syscall result.
    pub fn classify(result: i64) -> Kind {
        match result {
            r if r >= 0 => Kind::Allowed,
            status::INVALID_HANDLE | status::ACCESS_DENIED => Kind::Denied,
            _ => Kind::Failed,
        }
    }

    /// Append a record.
    pub fn push(&mut self, kind: Kind, space: u16, nr: u16, result: i64) {
        self.push_as(kind, space, nr, result, 0);
    }

    /// Append a record that carries the acting space's bound principal.
    pub fn push_as(&mut self, kind: Kind, space: u16, nr: u16, result: i64, principal: u64) {
        let seq = self.next_seq;
        self.next_seq += 1;
        let slot = (seq as usize - 1) % CAPACITY;
        if seq as usize > CAPACITY {
            self.dropped += 1;
        }
        self.buf[slot] = Event {
            seq,
            kind,
            space,
            nr,
            principal,
            result,
        };
    }

    /// Export strategy (NOT persistence): copy the held records, oldest first, into `out` for a trusted
    /// consumer (a future audit service or syscall). Returns (records copied, total ever appended,
    /// dropped). The consumer detects loss from `dropped` and from `seq` gaps. Nothing here writes to
    /// storage or protects the records from a kernel compromise.
    pub fn export(&self, out: &mut [Event]) -> (usize, u64, u64) {
        let mut n = 0;
        for (slot, e) in out.iter_mut().zip(self.iter()) {
            *slot = *e;
            n += 1;
        }
        (n, self.total(), self.dropped)
    }

    /// Records lost to overwriting.
    pub fn dropped(&self) -> u64 {
        self.dropped
    }

    /// Total records ever appended.
    pub fn total(&self) -> u64 {
        self.next_seq - 1
    }

    /// Records still held, oldest first.
    pub fn iter(&self) -> impl Iterator<Item = &Event> {
        let total = self.total() as usize;
        let held = total.min(CAPACITY);
        let first = total - held;
        (first..total).map(move |i| &self.buf[i % CAPACITY])
    }

    /// Count of held records of a kind.
    pub fn count(&self, kind: Kind) -> usize {
        self.iter().filter(|e| e.kind == kind).count()
    }
}

impl Default for AuditLog {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classification() {
        assert_eq!(AuditLog::classify(0), Kind::Allowed);
        assert_eq!(AuditLog::classify(status::INVALID_HANDLE), Kind::Denied);
        assert_eq!(AuditLog::classify(status::ACCESS_DENIED), Kind::Denied);
        assert_eq!(AuditLog::classify(status::QUOTA_EXCEEDED), Kind::Failed);
        assert_eq!(AuditLog::classify(status::TIMED_OUT), Kind::Failed);
    }

    #[test]
    fn records_in_order_and_ring_overwrites_oldest_visibly() {
        let mut l = AuditLog::new();
        for i in 0..(CAPACITY as i64 + 10) {
            l.push(Kind::Allowed, 1, 0x102, i);
        }
        assert_eq!(l.total(), CAPACITY as u64 + 10);
        assert_eq!(l.dropped(), 10);
        let v: std::vec::Vec<_> = l.iter().collect();
        assert_eq!(v.len(), CAPACITY);
        assert_eq!(v[0].seq, 11, "oldest 10 overwritten");
        assert_eq!(v.last().unwrap().seq, CAPACITY as u64 + 10);
        assert!(
            v.windows(2).all(|w| w[1].seq == w[0].seq + 1),
            "contiguous and ordered"
        );
    }

    #[test]
    fn empty_log_is_empty() {
        let l = AuditLog::new();
        assert_eq!(l.iter().count(), 0);
        assert_eq!((l.total(), l.dropped()), (0, 0));
    }
}
