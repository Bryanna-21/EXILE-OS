import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import run_trust_boundary as R


def st(**kw):
    return [{"stage": k, "verdict": v, "detail": ""} for k, v in kw.items()]


class Policy(unittest.TestCase):
    def test_hosted_pass_with_blocked_target_is_never_pass(self):
        self.assertEqual(R.overall(st(contracts="PASS", platform="PASS", b11="PASS", target="BLOCKED")), "INCOMPLETE")

    def test_any_failure_is_fail_even_if_target_blocked(self):
        self.assertEqual(R.overall(st(contracts="PASS", platform="FAIL", target="BLOCKED")), "FAIL")

    def test_pass_requires_target_pass_and_everything_pass(self):
        self.assertEqual(R.overall(st(contracts="PASS", target="PASS")), "PASS")
        self.assertEqual(R.overall(st(contracts="BLOCKED", target="PASS")), "INCOMPLETE")

    def test_target_stage_is_blocked_here_and_says_why(self):
        v, d = R.stage_target()
        self.assertEqual(v, "BLOCKED")
        self.assertIn("no bootable kernel image implements", d)


if __name__ == "__main__":
    unittest.main()
