#!/usr/bin/env python3
"""Reproducible trust-boundary demonstration runner.

Stages: contracts (drift + self-test), platform tests, Batch 11 trust-boundary tests (HOSTED),
and the TARGET stage (booted kernel image under QEMU). The target stage is BLOCKED unless every
prerequisite exists AND a kernel image implementing the contract exists, which is never the case
today, so the overall verdict can never be PASS: the best possible result is HOSTED-PASS/TARGET-BLOCKED.

Exit codes: 0 PASS (only when the target stage really ran and passed), 3 INCOMPLETE (hosted pass, target
blocked), 4 FAIL (any executed stage failed), 2 usage.
"""
import json, os, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
PIN = os.path.join(REPO, "Meta", "Experiments", "OMNI-Kernel-Batch-10", "toolchain.pin")


def run(cmd, cwd, env=None, timeout=900):
    e = dict(os.environ)
    e.update(env or {})
    try:
        r = subprocess.run(cmd, cwd=cwd, env=e, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr
    except (OSError, subprocess.TimeoutExpired) as ex:
        return 99, repr(ex)


def stage_contracts():
    rc1, o1 = run([sys.executable, "-B", os.path.join(HERE, "check_contracts.py")], REPO)
    rc2, o2 = run([sys.executable, "-B", os.path.join(HERE, "check_contracts.py"), "--self-test"], REPO)
    return ("PASS" if rc1 == 0 and rc2 == 0 else "FAIL"), (o1.strip().splitlines() or [""])[-1] + " | " + (o2.strip().splitlines() or [""])[-1]


def cargo_stage(manifest_dir, extra, tgt):
    if not shutil.which("cargo"):
        return "BLOCKED", "cargo not installed"
    rc, out = run(["cargo", "test", "--offline"] + extra, manifest_dir, {"CARGO_TARGET_DIR": tgt})
    counts = [l for l in out.splitlines() if l.startswith("test result:")]
    return ("PASS" if rc == 0 and counts else "FAIL"), "; ".join(c.split(";")[0] for c in counts) or out[-300:]


def stage_supervisor_equivalence():
    """Rust reference model vs C++ port on shared vectors (HOSTED; says nothing about SystemServer or the kernel)."""
    if not shutil.which("cargo") or not (shutil.which("g++") or shutil.which("clang++")):
        return "BLOCKED", "cargo or a C++ compiler is missing"
    script = os.path.join(REPO, "Meta", "Exile", "validation", "run_supervisor_equivalence.sh")
    env = {"EXILE_EQ_WORK": tempfile.mkdtemp(prefix="exile-sup-eq-")}
    if shutil.which("g++") is None:
        env["CXX"] = "clang++"
    rc, out = run(["sh", script], REPO, env)
    last = (out.strip().splitlines() or [""])[-1]
    return ("PASS" if rc == 0 else "FAIL"), last


def stage_target():
    """TARGET-LEVEL evidence: a booted kernel image. Never PASS unless every prerequisite is real."""
    missing = []
    for tool in ("qemu-system-x86_64", "grub-mkrescue", "xorriso"):
        if not shutil.which(tool):
            missing.append(tool + " not installed")
    rc, out = run([sys.executable, "-B", os.path.join(REPO, "Meta", "Exile", "build", "exile_build.py"), "--repo", REPO, "preflight", "--with-zig"], REPO)
    if rc != 0:
        missing.append("pinned toolchain preflight exit %d (rustc 1.91.1 / x86_64-unknown-none / zig 0.15.2)" % rc)
    # Even with every tool present, no kernel image implements these contracts yet.
    missing.append("no bootable kernel image implements the capability/IPC/audit contract (Kernel/ has no such object; OMNI images are not wired to it)")
    return "BLOCKED", "; ".join(missing)


def overall(stages):
    """Pure function so the policy is testable."""
    v = {s["stage"]: s["verdict"] for s in stages}
    if "FAIL" in v.values():
        return "FAIL"
    target = v.get("target")
    if target == "PASS" and all(x == "PASS" for x in v.values()):
        return "PASS"
    return "INCOMPLETE"


def main(argv):
    tgt = os.environ.get("CARGO_TARGET_DIR") or tempfile.mkdtemp(prefix="exile-tb-")
    stages = []
    for name, fn in (
        ("contracts", stage_contracts),
        ("platform-tests", lambda: cargo_stage(os.path.join(REPO, "Meta", "Exile", "platform"), [], tgt + "/plat")),
        ("batch11-trust-boundary-tests (HOSTED)", lambda: cargo_stage(os.path.join(REPO, "Meta", "Experiments", "OMNI-Kernel-Batch-11"), [], tgt + "/b11")),
        ("supervisor-rust-vs-cpp (HOSTED)", stage_supervisor_equivalence),
        ("target", stage_target),
    ):
        verdict, detail = fn()
        stages.append({"stage": name if name == "target" else name, "verdict": verdict, "detail": detail})
        print("%-42s %-8s %s" % (name, verdict, detail[:200]))
    o = overall(stages)
    print("\nOVERALL: %s%s" % (o, "  (hosted evidence only: NO hardware or target enforcement is demonstrated)" if o != "PASS" else ""))
    if "--json" in argv:
        print(json.dumps({"overall": o, "stages": stages}, indent=1))
    return {"PASS": 0, "INCOMPLETE": 3, "FAIL": 4}[o]


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
