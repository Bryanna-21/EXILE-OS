#!/usr/bin/env python3
"""Check exile-contracts-v1.json against the Rust sources that implement it.

Exit 0: every checked constant matches. Exit 4: drift. Exit 2: usage/IO problem.
`--self-test` mutates the contract and requires every mutation to be detected.
This checks NAMES AND NUMBERS only. It does not prove behaviour (the tests do) and it does not
check the C++ kernel, which has no implementation of this contract yet.
"""
import json, os, re, sys, copy

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
B11 = os.path.join(REPO, "Meta", "Experiments", "OMNI-Kernel-Batch-11", "src")
PLAT = os.path.join(REPO, "Meta", "Exile", "platform", "src")


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def const(src, name):
    m = re.search(r"pub const %s\s*:\s*[A-Za-z0-9_<>\[\]; ]+=\s*([^;]+);" % re.escape(name), src)
    if not m:
        raise KeyError(name)
    v = m.group(1).strip().replace("_", "")
    if v.startswith("1<<") or v.startswith("1 <<"):
        return 1 << int(v.split("<<")[1])
    if v.startswith("0x"):
        return int(v, 16)
    return int(v)


def enum_body(src, name):
    m = re.search(r"pub enum %s\s*\{(.*?)\n\}" % name, src, re.S)
    if not m:
        raise KeyError(name)
    return m.group(1)


def struct_fields(src, name):
    m = re.search(r"pub struct %s\s*\{(.*?)\n\}" % name, src, re.S)
    if not m:
        raise KeyError(name)
    return re.findall(r"pub (\w+):", m.group(1))


def check(c):
    bad = []

    def eq(what, want, got):
        if want != got:
            bad.append("%s: contract=%r source=%r" % (what, want, got))

    caps, ipc, sysr, st, aud = (read(os.path.join(B11, f)) for f in ("caps.rs", "ipc.rs", "sys.rs", "status.rs", "audit.rs"))
    sup = read(os.path.join(PLAT, "supervisor.rs"))
    # rights bits
    for name, bit in c["capabilities"]["rights"].items():
        if name == "valid_mask":
            eq("rights.valid_mask", int(bit, 16), int(re.search(r"VALID_MASK: u32 = (0x[0-9A-Fa-f]+)", caps).group(1), 16))
            continue
        m = re.search(r"pub const %s: Rights = Rights\(1 << (\d+)\)" % name.upper(), caps)
        eq("rights." + name, bit, int(m.group(1)) if m else None)
    eq("max_handles", c["capabilities"]["handle"]["max_handles_per_space"], const(caps, "MAX_HANDLES"))
    # limits
    for k, v in c["ipc"]["limits"].items():
        eq("limit." + k, v, const(ipc, k.upper() if k != "wire_header_bytes" else "WIRE_HEADER"))
    eq("wire_version", c["ipc"]["wire_version"], const(ipc, "ABI_VERSION_WIRE"))
    # syscalls
    for k, v in c["ipc"]["syscalls"].items():
        eq("syscall." + k, int(v, 16), const(sysr, "SYS_" + k.upper()))
    sizes = {"send_args": "SEND_ARGS_SIZE", "recv_args": "RECV_ARGS_SIZE", "recv_result": "RECV_RESULT_SIZE", "stats": "STATS_SIZE", "descriptor": "DESC_SIZE"}
    for k, v in c["ipc"]["sizes"].items():
        eq("size." + k, v, const(sysr, sizes[k]))
    for k, v in c["ipc"]["status"].items():
        eq("status." + k, v, const(st, k))
    # explicit cancellation tokens (contract 1.2.0)
    canc = c["ipc"]["cancellation"]
    eq("cancel_create_out_size", canc["cancel_create_out_size"], const(sysr, "CANCEL_CREATE_OUT_SIZE"))
    eq("max_waiters_per_token", canc["max_waiters_per_token"], const(ipc, "MAX_WAITERS"))
    m = re.search(r"CANCEL_DEFAULT: Rights =\s*Rights\((.*?)\);", caps, re.S)
    bits = 0
    for n in re.findall(r"Self::(\w+)\.0", m.group(1)) if m else []:
        b = re.search(r"pub const %s: Rights = Rights\(1 << (\d+)\)" % n, caps)
        bits |= 1 << int(b.group(1))
    eq("token_default_rights", int(canc["token_default_rights"], 16), bits)
    for needle in ("SYS_CANCEL_CREATE =>", "SYS_CANCEL_SIGNAL =>", "status::CANCELLED"):
        if needle not in sysr:
            bad.append("cancellation not implemented in sys.rs: missing %s" % needle)
    # sender identity is actually written at offset 16
    if "rb[16..20]" not in sysr or "msg.sender" not in sysr:
        bad.append("sender_space is not written at recv_result offset 16")
    # audit
    eq("audit.capacity", c["audit"]["capacity"], const(aud, "CAPACITY"))
    kinds = dict((n, int(v)) for n, v in re.findall(r"(\w+)\s*=\s*(\d+),", enum_body(aud, "Kind")))
    eq("audit.kinds", c["audit"]["kinds"], kinds)
    eq("audit.record_fields", c["audit"]["record_fields"], struct_fields(aud, "Event"))
    m = re.search(r"matches!\(kind, ([^)]*)\)", sysr)
    ext = [x.strip().split("::")[1] for x in m.group(1).split("|")] if m else None
    eq("audit.external_kinds_allowed", c["audit"]["external_kinds_allowed"], ext)
    # supervision
    eq("supervisor policy fields", c["recovery"]["supervisor_policy_fields"], struct_fields(sup, "Policy"))
    events = re.findall(r"^\s{4}(\w+)[,(]", enum_body(sup, "Event"), re.M)
    eq("supervisor events", c["recovery"]["supervisor_events"], events)
    return bad


def main(argv):
    path = os.path.join(HERE, "exile-contracts-v1.json")
    try:
        with open(path, encoding="utf-8") as f:
            c = json.load(f)
    except OSError as e:
        print("cannot read contract:", e, file=sys.stderr)
        return 2
    if "--self-test" in argv:
        muts = [
            lambda d: d["capabilities"]["rights"].__setitem__("admin", 6),
            lambda d: d["ipc"]["limits"].__setitem__("max_msg_bytes", 2048),
            lambda d: d["ipc"]["status"].__setitem__("PEER_DEAD", -11),
            lambda d: d["ipc"]["syscalls"].__setitem__("send", "0x109"),
            lambda d: d["ipc"]["sizes"].__setitem__("recv_result", 80),
            lambda d: d["audit"]["kinds"].__setitem__("Denied", 9),
            lambda d: d["audit"].__setitem__("capacity", 64),
            lambda d: d["audit"]["external_kinds_allowed"].append("Allowed"),
            lambda d: d["audit"]["record_fields"].remove("principal"),
            lambda d: d["recovery"]["supervisor_policy_fields"].append("extra"),
            lambda d: d["recovery"]["supervisor_events"].pop(),
            lambda d: d["capabilities"]["handle"].__setitem__("max_handles_per_space", 64),
            lambda d: d["ipc"]["cancellation"].__setitem__("cancel_create_out_size", 4),
            lambda d: d["ipc"]["cancellation"].__setitem__("token_default_rights", "0xF8"),
            lambda d: d["ipc"]["cancellation"].__setitem__("max_waiters_per_token", 8),
        ]
        missed = 0
        for i, m in enumerate(muts):
            d = copy.deepcopy(c)
            m(d)
            hit = bool(check(d))
            print("mutation %d: %s" % (i, "detected" if hit else "MISSED"))
            missed += not hit
        print("self-test: %d/%d detected" % (len(muts) - missed, len(muts)))
        return 0 if missed == 0 and not check(c) else 4
    try:
        bad = check(c)
    except (KeyError, OSError, AttributeError) as e:
        print("cannot extract from source:", repr(e), file=sys.stderr)
        return 2
    for b in bad:
        print("DRIFT", b)
    print("CONTRACT MATCHES SOURCE" if not bad else "CONTRACT DRIFT: %d" % len(bad))
    return 0 if not bad else 4


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
