#!/bin/sh
# Runs every supervisor scenario vector through the Rust reference model and the C++ port and requires
# byte-identical traces (and a match with the committed *.expected). HOSTED evidence only.
# Usage: run_supervisor_equivalence.sh [--regen]   (--regen rewrites *.expected from the Rust model)
set -eu
repo=$(cd "$(dirname "$0")/../../.." && pwd)
lib="$repo/Userland/Libraries/LibExileSupervisor"
work=${EXILE_EQ_WORK:-"${TMPDIR:-/tmp}/exile-sup-eq"}
mkdir -p "$work"
(cd "$repo/Meta/Exile/platform" && CARGO_TARGET_DIR="$work/rust" cargo build --offline --example sup_trace -q)
${CXX:-g++} -std=c++20 -Wall -Wextra -Wpedantic -Werror -o "$work/sup_trace_cpp" "$lib/Supervisor.cpp" "$lib/tests/sup_trace.cpp"
fail=0; n=0
for v in "$lib"/vectors/*.scn; do
  n=$((n+1)); b=$(basename "$v" .scn)
  "$work/rust/debug/examples/sup_trace" "$v" > "$work/$b.rust"
  "$work/sup_trace_cpp" "$v" > "$work/$b.cpp"
  [ "${1:-}" = "--regen" ] && cp "$work/$b.rust" "$lib/vectors/$b.expected"
  if cmp -s "$work/$b.rust" "$work/$b.cpp" && cmp -s "$work/$b.rust" "$lib/vectors/$b.expected"; then
    echo "PASS $b ($(wc -l < "$work/$b.rust") trace lines)"
  else
    echo "FAIL $b"; diff "$work/$b.rust" "$work/$b.cpp" | head -10 || true; fail=1
  fi
done
echo "vectors: $n  result: $([ $fail = 0 ] && echo EQUIVALENT || echo DIVERGED)"
exit $fail
