//! Service supervision policy: stable identity, health monitoring, bounded restart with exponential
//! backoff, capability revocation and reacquisition, and audit events.
//!
//! This is a PORTABLE, DETERMINISTIC STATE MACHINE. It does not spawn processes or touch capabilities
//! itself: it asks its `Effects` implementation to. That keeps the policy testable on a host and
//! reusable by SystemServer (C++, via a thin port) or a Rust init. Status: reference model with host
//! tests ONLY. It is NOT wired into `Userland/Services/SystemServer`, which still uses its own
//! 3-attempt logic (see Documentation/Architecture/Platform/TRUST_BOUNDARY_STATUS.md).
//!
//! Identity: a service has a stable `ServiceId`; each start gets a fresh `Incarnation`. Events that name
//! an old incarnation are ignored, so a late exit or heartbeat from a dead instance can never affect
//! its successor. Capabilities are bound to (id, incarnation): they are revoked BEFORE the successor
//! starts and granted fresh to it.
//!
//! Time is an abstract monotonically non-decreasing tick counter supplied by the caller.

/// Stable service identity.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ServiceId(pub u16);

/// Instance counter; 0 is never used.
pub type Incarnation = u32;

/// Per-service policy.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Policy {
    /// Consecutive failures (without a stable run in between) allowed before giving up.
    pub max_failures: u8,
    /// First backoff delay in ticks (must be > 0).
    pub backoff_base: u64,
    /// Upper bound on backoff delay.
    pub backoff_cap: u64,
    /// A run at least this long counts as stable and resets the failure count.
    pub stable_after: u64,
    /// A running service must heartbeat at least this often; 0 disables health checks.
    pub health_timeout: u64,
    /// Time allowed for a start to be confirmed by `started`.
    pub start_timeout: u64,
}

/// Lifecycle state.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State {
    /// Registered, not yet started.
    Stopped,
    /// Spawned, awaiting `started` until the deadline.
    Starting {
        /// Tick at which an unconfirmed start is declared failed.
        deadline: u64,
    },
    /// Confirmed running since `since`; last heartbeat at `last_beat`.
    Running {
        /// Tick at which the start was confirmed.
        since: u64,
        /// Tick of the most recent heartbeat.
        last_beat: u64,
    },
    /// Waiting to restart at `until`.
    Backoff {
        /// Tick at which the restart is due.
        until: u64,
    },
    /// Budget exhausted. Terminal until an operator calls `reset`.
    Failed,
}

/// Audit-worthy supervisor event.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Event {
    /// Instance spawned.
    Started(ServiceId, Incarnation),
    /// Instance confirmed running.
    Running(ServiceId, Incarnation),
    /// Instance exited or was declared dead; `reason` says why.
    Failure(ServiceId, Incarnation, Reason),
    /// Restart scheduled after `delay` ticks.
    RestartScheduled(ServiceId, Incarnation, u64),
    /// Authority of an instance was revoked.
    CapsRevoked(ServiceId, Incarnation),
    /// Authority was granted to a new instance.
    CapsGranted(ServiceId, Incarnation),
    /// Gave up; escalate to an operator or recovery mode instead of looping.
    GaveUp(ServiceId),
    /// An event naming a superseded incarnation was ignored.
    StaleIgnored(ServiceId, Incarnation),
}

/// Why an instance failed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Reason {
    /// Process exited with this status (non-zero) or was killed.
    Exited(i32),
    /// No heartbeat within the health timeout.
    Unhealthy,
    /// `started` not confirmed within the start timeout.
    StartTimeout,
    /// Spawn or capability grant failed.
    SpawnFailed,
}

/// An `Effects` operation was refused or failed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Refused;

/// Side effects requested by the supervisor.
pub trait Effects {
    /// Start a new instance. Err = could not spawn.
    fn spawn(&mut self, id: ServiceId, inc: Incarnation) -> Result<(), Refused>;
    /// Forcibly stop an instance (health or start timeout).
    fn kill(&mut self, id: ServiceId, inc: Incarnation);
    /// Revoke ALL authority held by that instance.
    fn revoke_caps(&mut self, id: ServiceId, inc: Incarnation);
    /// Grant the service's declared authority to the new instance. Err = refused.
    fn grant_caps(&mut self, id: ServiceId, inc: Incarnation) -> Result<(), Refused>;
    /// Record an audit event.
    fn audit(&mut self, ev: Event);
}

/// Errors from the management API.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SupError {
    /// Registry full.
    Full,
    /// Unknown service.
    Unknown,
    /// Policy invalid.
    BadPolicy,
    /// Operation illegal in the current state.
    BadState,
}

#[derive(Clone, Copy)]
struct Svc {
    id: ServiceId,
    policy: Policy,
    state: State,
    inc: Incarnation,
    failures: u8,
}

/// Supervisor over at most `N` services.
pub struct Supervisor<const N: usize> {
    svcs: [Option<Svc>; N],
}

impl<const N: usize> Default for Supervisor<N> {
    fn default() -> Self {
        Self::new()
    }
}

impl<const N: usize> Supervisor<N> {
    /// Empty supervisor.
    pub const fn new() -> Self {
        Supervisor { svcs: [None; N] }
    }

    /// Register a service (Stopped).
    pub fn register(&mut self, id: ServiceId, policy: Policy) -> Result<(), SupError> {
        if policy.backoff_base == 0
            || policy.backoff_cap < policy.backoff_base
            || policy.max_failures == 0
            || policy.start_timeout == 0
        {
            return Err(SupError::BadPolicy);
        }
        if self.svcs.iter().flatten().any(|s| s.id == id) {
            return Err(SupError::BadState);
        }
        let slot = self
            .svcs
            .iter_mut()
            .find(|s| s.is_none())
            .ok_or(SupError::Full)?;
        *slot = Some(Svc {
            id,
            policy,
            state: State::Stopped,
            inc: 0,
            failures: 0,
        });
        Ok(())
    }

    fn svc(&mut self, id: ServiceId) -> Result<&mut Svc, SupError> {
        self.svcs
            .iter_mut()
            .flatten()
            .find(|s| s.id == id)
            .ok_or(SupError::Unknown)
    }

    /// Current state and incarnation.
    pub fn status(&self, id: ServiceId) -> Option<(State, Incarnation)> {
        self.svcs
            .iter()
            .flatten()
            .find(|s| s.id == id)
            .map(|s| (s.state, s.inc))
    }

    /// Consecutive failure count.
    pub fn failures(&self, id: ServiceId) -> Option<u8> {
        self.svcs
            .iter()
            .flatten()
            .find(|s| s.id == id)
            .map(|s| s.failures)
    }

    /// Begin the first start of a Stopped service.
    pub fn start<E: Effects>(
        &mut self,
        id: ServiceId,
        now: u64,
        fx: &mut E,
    ) -> Result<(), SupError> {
        let s = self.svc(id)?;
        if s.state != State::Stopped {
            return Err(SupError::BadState);
        }
        launch(s, now, fx);
        Ok(())
    }

    /// Operator reset of a Failed service back to Stopped (clears the failure count).
    pub fn reset(&mut self, id: ServiceId) -> Result<(), SupError> {
        let s = self.svc(id)?;
        if s.state != State::Failed {
            return Err(SupError::BadState);
        }
        s.state = State::Stopped;
        s.failures = 0;
        Ok(())
    }

    /// The instance reports it is up. Ignored (and audited) if `inc` is not current.
    pub fn started<E: Effects>(
        &mut self,
        id: ServiceId,
        inc: Incarnation,
        now: u64,
        fx: &mut E,
    ) -> Result<(), SupError> {
        let s = self.svc(id)?;
        if inc != s.inc {
            fx.audit(Event::StaleIgnored(id, inc));
            return Ok(());
        }
        if let State::Starting { .. } = s.state {
            s.state = State::Running {
                since: now,
                last_beat: now,
            };
            fx.audit(Event::Running(id, inc));
            Ok(())
        } else {
            Err(SupError::BadState)
        }
    }

    /// Liveness signal from an instance.
    pub fn heartbeat<E: Effects>(
        &mut self,
        id: ServiceId,
        inc: Incarnation,
        now: u64,
        fx: &mut E,
    ) -> Result<(), SupError> {
        let s = self.svc(id)?;
        if inc != s.inc {
            fx.audit(Event::StaleIgnored(id, inc));
            return Ok(());
        }
        if let State::Running { since, .. } = s.state {
            s.state = State::Running {
                since,
                last_beat: now,
            };
        }
        Ok(())
    }

    /// The instance exited (or was reaped). `status == 0` is a clean exit: authority is revoked and the
    /// service goes to `Stopped` (no restart). Any other status is a failure.
    pub fn exited<E: Effects>(
        &mut self,
        id: ServiceId,
        inc: Incarnation,
        status: i32,
        now: u64,
        fx: &mut E,
    ) -> Result<(), SupError> {
        let s = self.svc(id)?;
        if inc != s.inc {
            fx.audit(Event::StaleIgnored(id, inc));
            return Ok(());
        }
        match s.state {
            State::Starting { .. } | State::Running { .. } => {}
            _ => return Err(SupError::BadState),
        }
        if status == 0 {
            fx.revoke_caps(id, inc);
            fx.audit(Event::CapsRevoked(id, inc));
            s.state = State::Stopped;
            return Ok(());
        }
        fail(s, Reason::Exited(status), now, fx);
        Ok(())
    }

    /// Advance time: detect unhealthy/unstarted instances and launch due restarts.
    pub fn tick<E: Effects>(&mut self, now: u64, fx: &mut E) {
        for s in self.svcs.iter_mut().flatten() {
            match s.state {
                State::Starting { deadline } if now >= deadline => {
                    fx.kill(s.id, s.inc);
                    fail(s, Reason::StartTimeout, now, fx);
                }
                State::Running { last_beat, .. }
                    if s.policy.health_timeout != 0
                        && now.saturating_sub(last_beat) >= s.policy.health_timeout =>
                {
                    fx.kill(s.id, s.inc);
                    fail(s, Reason::Unhealthy, now, fx);
                }
                State::Backoff { until } if now >= until => launch(s, now, fx),
                _ => {}
            }
        }
    }
}

/// Spawn a new incarnation, revoking nothing (the previous one was revoked when it failed) and granting
/// fresh authority. A spawn or grant failure is itself a failure and goes through backoff.
fn launch<E: Effects>(s: &mut Svc, now: u64, fx: &mut E) {
    s.inc = s.inc.wrapping_add(1).max(1);
    if fx.grant_caps(s.id, s.inc).is_err() {
        fail(s, Reason::SpawnFailed, now, fx);
        return;
    }
    fx.audit(Event::CapsGranted(s.id, s.inc));
    if fx.spawn(s.id, s.inc).is_err() {
        // `fail` revokes the authority just granted, so a failed spawn never leaves a live grant.
        fail(s, Reason::SpawnFailed, now, fx);
        return;
    }
    fx.audit(Event::Started(s.id, s.inc));
    s.state = State::Starting {
        deadline: now.saturating_add(s.policy.start_timeout),
    };
}

/// Common failure path: revoke authority FIRST, audit, then schedule backoff or give up.
fn fail<E: Effects>(s: &mut Svc, reason: Reason, now: u64, fx: &mut E) {
    let ran_stable = matches!(s.state, State::Running { since, .. } if now.saturating_sub(since) >= s.policy.stable_after);
    if ran_stable {
        s.failures = 0;
    }
    fx.revoke_caps(s.id, s.inc);
    fx.audit(Event::CapsRevoked(s.id, s.inc));
    fx.audit(Event::Failure(s.id, s.inc, reason));
    s.failures = s.failures.saturating_add(1);
    if s.failures > s.policy.max_failures {
        s.state = State::Failed;
        fx.audit(Event::GaveUp(s.id));
        return;
    }
    // delay = base << (failures-1), capped; shift bounded to avoid overflow.
    let shift = u32::from(s.failures - 1).min(32);
    // `checked_shl` only rejects shift >= 64; it silently drops high bits, which would turn a huge base into a
    // tiny (even zero) delay. Detect bit loss explicitly and saturate instead.
    let base = s.policy.backoff_base;
    let delay = if base.leading_zeros() < shift {
        u64::MAX
    } else {
        base << shift
    }
    .min(s.policy.backoff_cap);
    s.state = State::Backoff {
        until: now.saturating_add(delay),
    };
    fx.audit(Event::RestartScheduled(s.id, s.inc, delay));
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::format;
    use std::string::String;
    use std::vec::Vec;

    #[derive(Default)]
    struct Fx {
        log: Vec<String>,
        events: Vec<Event>,
        live_caps: Vec<(u16, u32)>,
        fail_spawn: bool,
        refuse_grant: bool,
        kills: Vec<(u16, u32)>,
    }
    impl Effects for Fx {
        fn spawn(&mut self, id: ServiceId, inc: u32) -> Result<(), Refused> {
            self.log.push(format!("spawn {} {}", id.0, inc));
            if self.fail_spawn {
                Err(Refused)
            } else {
                Ok(())
            }
        }
        fn kill(&mut self, id: ServiceId, inc: u32) {
            self.kills.push((id.0, inc));
        }
        fn revoke_caps(&mut self, id: ServiceId, inc: u32) {
            self.log.push(format!("revoke {} {}", id.0, inc));
            self.live_caps.retain(|c| *c != (id.0, inc));
        }
        fn grant_caps(&mut self, id: ServiceId, inc: u32) -> Result<(), Refused> {
            if self.refuse_grant {
                return Err(Refused);
            }
            self.log.push(format!("grant {} {}", id.0, inc));
            self.live_caps.push((id.0, inc));
            Ok(())
        }
        fn audit(&mut self, ev: Event) {
            self.events.push(ev);
        }
    }

    const P: Policy = Policy {
        max_failures: 3,
        backoff_base: 10,
        backoff_cap: 100,
        stable_after: 50,
        health_timeout: 20,
        start_timeout: 5,
    };
    const A: ServiceId = ServiceId(1);

    fn up(s: &mut Supervisor<4>, fx: &mut Fx, now: u64) {
        let (_, inc) = s.status(A).unwrap();
        s.started(A, inc, now, fx).unwrap();
    }

    #[test]
    fn start_grants_before_spawn_and_runs() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        assert_eq!(
            fx.log,
            ["grant 1 1", "spawn 1 1"],
            "authority must exist before the instance runs"
        );
        up(&mut s, &mut fx, 1);
        assert_eq!(
            s.status(A),
            Some((
                State::Running {
                    since: 1,
                    last_beat: 1
                },
                1
            ))
        );
    }

    #[test]
    fn crash_revokes_old_authority_then_restarts_with_fresh_incarnation_after_backoff() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        up(&mut s, &mut fx, 1);
        s.exited(A, 1, 139, 5, &mut fx).unwrap();
        assert!(
            fx.live_caps.is_empty(),
            "dead instance must hold no authority"
        );
        assert_eq!(s.status(A), Some((State::Backoff { until: 15 }, 1)));
        s.tick(14, &mut fx);
        assert_eq!(s.status(A).unwrap().1, 1, "not before backoff expires");
        s.tick(15, &mut fx);
        assert_eq!(s.status(A).unwrap().1, 2);
        assert_eq!(
            fx.live_caps,
            [(1, 2)],
            "only the new incarnation holds authority"
        );
        let i = fx.log.iter().position(|l| l == "revoke 1 1").unwrap();
        let j = fx.log.iter().position(|l| l == "grant 1 2").unwrap();
        assert!(i < j, "revoke before regrant");
    }

    #[test]
    fn huge_backoff_base_saturates_instead_of_wrapping_to_a_tiny_delay() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        let pol = Policy {
            max_failures: 10,
            backoff_base: 1 << 62,
            backoff_cap: u64::MAX,
            ..P
        };
        s.register(A, pol).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        let mut delays = Vec::new();
        for _ in 0..4 {
            let (_, inc) = s.status(A).unwrap();
            s.exited(A, inc, 1, 0, &mut fx).unwrap();
            if let (State::Backoff { until }, _) = s.status(A).unwrap() {
                delays.push(until);
                s.tick(until, &mut fx);
            }
        }
        assert!(
            delays.windows(2).all(|w| w[0] <= w[1]),
            "delay must never shrink: {delays:?}"
        );
        assert_eq!(delays[2], u64::MAX);
    }

    #[test]
    fn backoff_doubles_and_is_capped() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        let pol = Policy {
            max_failures: 10,
            ..P
        };
        s.register(A, pol).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        let mut now = 0;
        let mut delays = Vec::new();
        for _ in 0..6 {
            let (_, inc) = s.status(A).unwrap();
            s.exited(A, inc, 1, now, &mut fx).unwrap();
            if let (State::Backoff { until }, _) = s.status(A).unwrap() {
                delays.push(until - now);
                now = until;
            }
            s.tick(now, &mut fx);
        }
        assert_eq!(delays, [10, 20, 40, 80, 100, 100]);
    }

    #[test]
    fn budget_exhaustion_fails_closed_instead_of_looping() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        let mut now = 0;
        for _ in 0..4 {
            let (st, inc) = s.status(A).unwrap();
            if st == State::Failed {
                break;
            }
            s.exited(A, inc, 1, now, &mut fx).unwrap();
            now += 1000;
            s.tick(now, &mut fx);
        }
        assert_eq!(s.status(A).unwrap().0, State::Failed);
        assert!(fx.events.contains(&Event::GaveUp(A)));
        let spawns = fx.log.iter().filter(|l| l.starts_with("spawn")).count();
        assert_eq!(spawns, 4, "initial + exactly max_failures restarts");
        s.tick(1_000_000, &mut fx);
        assert_eq!(
            fx.log.iter().filter(|l| l.starts_with("spawn")).count(),
            4,
            "no further spawns"
        );
        assert!(fx.live_caps.is_empty());
        s.reset(A).unwrap();
        assert_eq!(s.status(A).unwrap().0, State::Stopped);
    }

    #[test]
    fn stable_run_resets_failure_count() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(
            A,
            Policy {
                health_timeout: 0,
                ..P
            },
        )
        .unwrap();
        s.start(A, 0, &mut fx).unwrap();
        up(&mut s, &mut fx, 0);
        s.exited(A, 1, 1, 1, &mut fx).unwrap();
        s.tick(11, &mut fx);
        up(&mut s, &mut fx, 11);
        s.exited(A, 2, 1, 12, &mut fx).unwrap();
        assert_eq!(s.failures(A), Some(2));
        s.tick(32, &mut fx);
        up(&mut s, &mut fx, 32);
        s.exited(A, 3, 1, 32 + 60, &mut fx).unwrap(); // ran 60 >= stable_after 50
        assert_eq!(
            s.failures(A),
            Some(1),
            "reset by the stable run, then this failure counted"
        );
    }

    #[test]
    fn missed_heartbeat_kills_and_restarts() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        up(&mut s, &mut fx, 0);
        s.heartbeat(A, 1, 15, &mut fx).unwrap();
        s.tick(34, &mut fx);
        assert!(
            matches!(s.status(A), Some((State::Running { .. }, 1))),
            "19 ticks since beat: healthy"
        );
        s.tick(35, &mut fx);
        assert_eq!(fx.kills, [(1, 1)]);
        assert!(fx.events.contains(&Event::Failure(A, 1, Reason::Unhealthy)));
        assert!(matches!(s.status(A), Some((State::Backoff { .. }, 1))));
    }

    #[test]
    fn start_timeout_is_a_failure() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        s.tick(5, &mut fx);
        assert!(
            fx.events
                .contains(&Event::Failure(A, 1, Reason::StartTimeout))
        );
        assert_eq!(fx.kills, [(1, 1)]);
    }

    #[test]
    fn stale_incarnation_events_cannot_affect_the_successor() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        up(&mut s, &mut fx, 0);
        s.exited(A, 1, 1, 1, &mut fx).unwrap();
        s.tick(11, &mut fx); // incarnation 2 starting
        s.started(A, 2, 12, &mut fx).unwrap();
        // late messages from the dead incarnation 1:
        s.exited(A, 1, 1, 13, &mut fx).unwrap();
        s.heartbeat(A, 1, 13, &mut fx).unwrap();
        s.started(A, 1, 13, &mut fx).unwrap();
        assert!(
            matches!(s.status(A), Some((State::Running { .. }, 2))),
            "successor unaffected"
        );
        assert_eq!(
            fx.events
                .iter()
                .filter(|e| matches!(e, Event::StaleIgnored(..)))
                .count(),
            3
        );
        assert_eq!(fx.live_caps, [(1, 2)]);
    }

    #[test]
    fn spawn_failure_and_grant_refusal_go_through_backoff_and_leak_no_authority() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx {
            fail_spawn: true,
            ..Fx::default()
        };
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        assert!(
            fx.live_caps.is_empty(),
            "grant must be undone when spawn fails"
        );
        assert!(matches!(s.status(A), Some((State::Backoff { .. }, 1))));
        let mut fx2 = Fx {
            refuse_grant: true,
            ..Fx::default()
        };
        let mut s2 = Supervisor::<4>::new();
        s2.register(A, P).unwrap();
        s2.start(A, 0, &mut fx2).unwrap();
        assert!(
            fx2.log.iter().all(|l| !l.starts_with("spawn")),
            "never spawn without authority"
        );
        assert!(
            fx2.events
                .contains(&Event::Failure(A, 1, Reason::SpawnFailed))
        );
    }

    #[test]
    fn clean_exit_stops_without_restart() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(A, P).unwrap();
        s.start(A, 0, &mut fx).unwrap();
        up(&mut s, &mut fx, 0);
        s.exited(A, 1, 0, 3, &mut fx).unwrap();
        s.tick(10_000, &mut fx);
        assert_eq!(s.status(A), Some((State::Stopped, 1)));
        assert!(fx.live_caps.is_empty());
    }

    #[test]
    fn validation_and_capacity() {
        let mut s = Supervisor::<1>::new();
        assert_eq!(
            s.register(
                A,
                Policy {
                    backoff_base: 0,
                    ..P
                }
            ),
            Err(SupError::BadPolicy)
        );
        assert_eq!(
            s.register(
                A,
                Policy {
                    backoff_cap: 1,
                    ..P
                }
            ),
            Err(SupError::BadPolicy)
        );
        assert_eq!(
            s.register(
                A,
                Policy {
                    max_failures: 0,
                    ..P
                }
            ),
            Err(SupError::BadPolicy)
        );
        s.register(A, P).unwrap();
        assert_eq!(s.register(A, P), Err(SupError::BadState), "duplicate id");
        assert_eq!(s.register(ServiceId(2), P), Err(SupError::Full));
        let mut fx = Fx::default();
        assert_eq!(s.start(ServiceId(9), 0, &mut fx), Err(SupError::Unknown));
        s.start(A, 0, &mut fx).unwrap();
        assert_eq!(s.start(A, 0, &mut fx), Err(SupError::BadState));
        assert_eq!(s.reset(A), Err(SupError::BadState));
    }

    #[test]
    fn huge_failure_counts_do_not_overflow_the_shift() {
        let mut s = Supervisor::<4>::new();
        let mut fx = Fx::default();
        s.register(
            A,
            Policy {
                max_failures: 255,
                backoff_cap: u64::MAX,
                ..P
            },
        )
        .unwrap();
        s.start(A, 0, &mut fx).unwrap();
        let mut now = 0u64;
        for _ in 0..200 {
            let (st, inc) = s.status(A).unwrap();
            if let State::Backoff { until } = st {
                now = until;
                s.tick(now, &mut fx);
                continue;
            }
            s.exited(A, inc, 1, now, &mut fx).unwrap();
        }
        assert!(s.failures(A).unwrap() > 60);
    }
}
