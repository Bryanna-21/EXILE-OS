//! Scenario runner for supervisor equivalence checking against the C++ port
//! (Userland/Libraries/LibExileSupervisor). Reads a scenario file, prints a canonical trace.
//! Scenario grammar: see Userland/Libraries/LibExileSupervisor/vectors/README.md.
use exile_platform::supervisor::*;

struct Fx {
    spawn_fail: bool,
    grant_fail: bool,
}
fn ev(e: &Event) -> String {
    match *e {
        Event::Started(s, i) => format!("Started {} {}", s.0, i),
        Event::Running(s, i) => format!("Running {} {}", s.0, i),
        Event::Failure(s, i, r) => {
            let r = match r {
                Reason::Exited(c) => format!("Exited({c})"),
                Reason::Unhealthy => "Unhealthy".into(),
                Reason::StartTimeout => "StartTimeout".into(),
                Reason::SpawnFailed => "SpawnFailed".into(),
            };
            format!("Failure {} {} {}", s.0, i, r)
        }
        Event::RestartScheduled(s, i, d) => format!("RestartScheduled {} {} {}", s.0, i, d),
        Event::CapsRevoked(s, i) => format!("CapsRevoked {} {}", s.0, i),
        Event::CapsGranted(s, i) => format!("CapsGranted {} {}", s.0, i),
        Event::GaveUp(s) => format!("GaveUp {}", s.0),
        Event::StaleIgnored(s, i) => format!("StaleIgnored {} {}", s.0, i),
    }
}
impl Effects for Fx {
    fn spawn(&mut self, id: ServiceId, inc: Incarnation) -> Result<(), Refused> {
        println!("fx spawn {} {}", id.0, inc);
        if self.spawn_fail { Err(Refused) } else { Ok(()) }
    }
    fn kill(&mut self, id: ServiceId, inc: Incarnation) {
        println!("fx kill {} {}", id.0, inc);
    }
    fn revoke_caps(&mut self, id: ServiceId, inc: Incarnation) {
        println!("fx revoke {} {}", id.0, inc);
    }
    fn grant_caps(&mut self, id: ServiceId, inc: Incarnation) -> Result<(), Refused> {
        println!("fx grant {} {}", id.0, inc);
        if self.grant_fail { Err(Refused) } else { Ok(()) }
    }
    fn audit(&mut self, e: Event) {
        println!("ev {}", ev(&e));
    }
}
fn ret(r: Result<(), SupError>) {
    println!(
        "ret {}",
        match r {
            Ok(()) => "Ok",
            Err(SupError::Full) => "Full",
            Err(SupError::Unknown) => "Unknown",
            Err(SupError::BadPolicy) => "BadPolicy",
            Err(SupError::BadState) => "BadState",
        }
    );
}
fn main() {
    let path = std::env::args().nth(1).expect("scenario path");
    let text = std::fs::read_to_string(path).expect("read scenario");
    let mut sup = Supervisor::<16>::new();
    let mut fx = Fx { spawn_fail: false, grant_fail: false };
    let mut ids: Vec<u16> = Vec::new();
    for line in text.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        println!("> {line}");
        let w: Vec<&str> = line.split_whitespace().collect();
        let n = |i: usize| -> u64 { w[i].parse().expect("number") };
        let sid = |i: usize| ServiceId(n(i) as u16);
        match w[0] {
            "reg" => {
                let p = Policy {
                    max_failures: n(2) as u8,
                    backoff_base: n(3),
                    backoff_cap: n(4),
                    stable_after: n(5),
                    health_timeout: n(6),
                    start_timeout: n(7),
                };
                let r = sup.register(sid(1), p);
                if r.is_ok() {
                    ids.push(n(1) as u16);
                }
                ret(r);
            }
            "start" => ret(sup.start(sid(1), n(2), &mut fx)),
            "started" => ret(sup.started(sid(1), n(2) as u32, n(3), &mut fx)),
            "beat" => ret(sup.heartbeat(sid(1), n(2) as u32, n(3), &mut fx)),
            "exit" => ret(sup.exited(sid(1), n(2) as u32, w[3].parse::<i32>().expect("status"), n(4), &mut fx)),
            "tick" => sup.tick(n(1), &mut fx),
            "reset" => ret(sup.reset(sid(1))),
            "spawnfail" => fx.spawn_fail = n(1) != 0,
            "grantfail" => fx.grant_fail = n(1) != 0,
            other => panic!("unknown command {other}"),
        }
        for &i in &ids {
            let (st, inc) = sup.status(ServiceId(i)).unwrap();
            let (k, a, b) = match st {
                State::Stopped => ("Stopped", 0, 0),
                State::Starting { deadline } => ("Starting", deadline, 0),
                State::Running { since, last_beat } => ("Running", since, last_beat),
                State::Backoff { until } => ("Backoff", until, 0),
                State::Failed => ("Failed", 0, 0),
            };
            println!("st {} {} {} {} inc={} fail={}", i, k, a, b, inc, sup.failures(ServiceId(i)).unwrap());
        }
    }
}
