# Supervisor port status (LibExileSupervisor ↔ SystemServer)

**Status: library ported and verified on the HOST against the Rust reference model. NOT integrated into SystemServer. NOT built inside the OS tree. NEVER run under the Exile kernel.**

## What exists
* `Meta/Exile/platform/src/supervisor.rs` — reference model (80 platform tests incl. a new regression for backoff overflow).
* `Userland/Libraries/LibExileSupervisor/` — C++20 port, no heap/exceptions/AK/LibCore dependency.
* 7 scenario vectors (`vectors/*.scn`, committed Rust traces `*.expected`). `Meta/Exile/validation/run_supervisor_equivalence.sh` runs both implementations and requires byte-identical traces (lifecycle/backoff/cap, stale incarnations, spawn/grant failure, start timeout, stable-run reset, health off, registry limits, the 2^32 shift cap, 64-bit saturation).
* Mutation check of the C++ port against the vectors: 8 of 9 mutants killed; the survivor was an equivalent mutant. Incarnation wrap (2^32 launches) is not reachable by vectors and is covered only by code review.

## A real defect found by this work
The reference model used `checked_shl`, which only rejects shifts ≥ 64 and silently drops high bits. A large `backoff_base` could wrap to a tiny or zero delay (restart storm). Fixed to saturate; regression test `huge_backoff_base_saturates_instead_of_wrapping_to_a_tiny_delay` (verified to fail on the old code); vector 05 locks the behaviour in both implementations.

## Not done: SystemServer integration (what it needs)
`Userland/Services/SystemServer/Service.cpp::did_exit` currently allows 2 retries only when the run lasted < 1 s, with no backoff, health check, incarnation or audit. To adopt the library:
1. Map each `Service` to a `ServiceId`; implement `Effects` over `Service::spawn()`, `kill(pid)`, and the capability/unveil/pledge grant for that incarnation. Until the kernel has capability objects (ADR-0001) `grant_caps`/`revoke_caps` can only drive pledge/unveil/handles that exist today — that gap must be documented, not hidden.
2. Replace `m_restart_attempts` with `Supervisor::exited` and drive `tick` from a `Core::Timer`; derive `Policy` from the service config file (new keys, defaults preserving current behaviour).
3. Forward `Effects::audit` to the kernel audit sink (no such syscall exists yet) or to a SystemServer-local log, and state which.
4. Build with the OS toolchain (needs LibCore) and run under QEMU. None of that is possible in the current environment.
