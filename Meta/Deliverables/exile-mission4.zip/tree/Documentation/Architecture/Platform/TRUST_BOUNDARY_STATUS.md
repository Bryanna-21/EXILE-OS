# Trust-boundary mission: status, evidence, roadmap

**Completion criterion (from the mission): NOT MET.** It requires independently executing contexts, enforceable permissions, controlled communication
and recoverable service failures *on the intended target*. Nothing was booted here: no QEMU, GRUB, xorriso or pinned toolchain (rustc 1.91.1,
`x86_64-unknown-none`, zig 0.15.2) is available, and `Kernel/` has no capability/channel object to boot. What exists is a **hosted** demonstration.
Runner verdict: `INCOMPLETE` (hosted pass, target BLOCKED); it can never print PASS until the target stage really runs.

## Mission demonstration items (Phase 6)
| # | Item | Hosted test | Evidence level | Target evidence |
|---|---|---|---|---|
| 1 | Two independent contexts | `tb_01_02` (distinct page-table roots, disjoint frames, both scheduled) | HOSTED, simulated MMU and scheduler | NOT RUN |
| 2 | Protected memory between them | `tb_01_02` (same VA, different frames, secret survives) | HOSTED | NOT RUN |
| 3 | Unauthorized memory access rejected | `tb_03` (other-space, kernel-half, null, read-only pointers: refused, nothing changes, audited) | HOSTED | NOT RUN: no CPU fault ever happened |
| 4 | Invalid / revoked capabilities | `tb_04` (never-issued, forged, other-space, rights, released, closed-for-all-holders), `tb_08` (slot reuse) | HOSTED | NOT RUN |
| 5 | Authorized vs unauthorized IPC | `tb_05` (capability required, bounded queue/size, kernel-stamped sender, denials audited) | HOSTED | NOT RUN |
| 6 | Containment of a process failure | `tb_06` (terminate one space; peer told `PEER_DEAD`; survivor and its memory intact) | HOSTED: the "fault" is a modelled termination, **not** a CPU exception | NOT RUN |
| 7 | Recovery of a failed service | `tb_07` + 12 supervisor unit tests (revoke → backoff → fresh grant → client reacquires; old handle stays dead) | HOSTED; supervisor not in SystemServer | NOT RUN |

## Phase status
| Phase | Deliverable | Status |
|---|---|---|
| 1 | Reconciliation report | DONE (`ARCHITECTURE_RECONCILIATION.md`) |
| 2 | Versioned contracts | DONE as v1.2.0 PROPOSED (`CONTRACTS_v1.md` + JSON + drift checker, 10/10 self-test mutations detected) |
| 3 | Isolated execution in the selected kernel | **NOT DONE in `Kernel/`** (cannot build or run). OMNI hosted model re-verified; no new kernel code written |
| 4 | Capability enforcement + IPC | Existing Batch 11 verified; **added** kernel-asserted sender identity and audit ring; explicit cancel tokens (0x104/0x105) implemented, HOSTED tests only |
| 5 | Service supervision | Reference model DONE + tested; **C++ port into SystemServer NOT DONE** |
| 6 | Demonstration | Hosted DONE; target BLOCKED |

## Changes to existing code (all backed up in `/home/claude/backups/m3-20261118T095956Z/`)
`OMNI-Kernel-Batch-11`: `src/ipc.rs` (+`sender` stamped at `commit_send`), `src/sys.rs` (audit hook at the syscall dispatch point, `SpaceTerminated` audit,
sender at result offset 16), `src/lib.rs`, `src/audit.rs` (new), `tests/trust_boundary.rs` (new), `docs/IPC_DESIGN.md`, `Cargo.toml`/`Cargo.lock`
(dev-only path dependency on `exile_platform` for the supervisor model). Wire change: offset 16 of the receive result was reserved-zero (1.0), now the sender (1.1);
no existing test or conformance check read it, and `check_ipc_conformance.py` still passes.

## Evidence (this mission, re-run at submission; logs in `logs/`)
* Batch 11: 28 tests (3 audit unit, 10 caps, 8 IPC e2e, **7 trust boundary**) pass in debug and release; `cargo fmt --check` and `clippy -D warnings` clean for Batch 11 code.
* Mutation check of the new kernel behaviour: 13 mutations, all killed at submission. One (object-generation check in `resolve`) survived the first
  version of the tests, which exposed a real gap; `tb_08` closed it. Supervisor: 11 applicable mutations, all killed; a 12th targeted a redundant revoke that survived
  and was removed from the code (the mutated line no longer exists).
* Platform crate: 79 tests, clippy and fmt clean. Contract checker + runner policy tests pass.
* Batch 11 `verify.sh` (OMNI11_PHASE=pre): all executed checks pass **except** "protected paths" and "unexpected changes outside Batch 11", which fail because this worktree also
  holds earlier work orders' untracked directories (`Meta/Exile/*`, `Documentation/Architecture/Platform`). That script targets a Batch 11 delivery archive; it was not edited
  or weakened. Zig regression and the `Kernel/` syntax check were SKIPPED (no zig; opt-in).
* Pinned compiler: all Rust results are from rustc 1.97.0, **not 1.91.1**.

## Blockers
1. No QEMU/GRUB/xorriso/pinned toolchain; Rust download host returns 403 here.
2. `Kernel/` cannot be compiled or run here, and has no capability/channel object to run.
3. Owner approval of ADR-0001 (kernel ownership) is still pending; syscall numbers 0x100–0x107 are not reserved in `Kernel/API`.

## Roadmap (ordered; each step names its evidence gate)
1. Owner decision on ADR-0001. 2. On a machine with the pinned toolchain and QEMU: run `exile_build.py all` and the Batch 11 QEMU harness (`scripts/qemu_x86_q35.py`) to get the first target evidence.
3. Port `audit` + sender identity + supervisor into `Kernel/` / `SystemServer` (C++), gated by a compile and a QEMU run. 4. Real CPU fault → process-kill path test (ring 3 page fault) under QEMU.
5. (done in this mission: explicit cancel tokens, hosted only) 6. Principal↔space identity link with `LibExilePolicy`; persist/ship audit. 7. Capability derivation trees (revoke by ancestor).

## Reproduce
```
python3 Meta/Exile/contracts/run_trust_boundary.py          # expect OVERALL: INCOMPLETE, exit 3 here
python3 Meta/Exile/contracts/check_contracts.py --self-test
python3 -I -B Meta/Exile/contracts/tests/test_runner.py
(cd Meta/Experiments/OMNI-Kernel-Batch-11 && cargo test --offline)
(cd Meta/Exile/platform && cargo test --offline)
```


## Mission 4 additions (HOSTED evidence only)
* Cancellation tokens 0x104/0x105: implemented in Batch 11, tests cn_01..cn_12, mutation-checked (12/14 killed, 2 equivalent). Contract 1.2.0.
* C++ supervisor port `LibExileSupervisor`: Rust/C++ trace equivalence on 7 vectors; see `SUPERVISOR_PORT.md`. Not integrated into SystemServer.
* Audit: kinds IdentityBound/Fault/PolicyDenied, principal on every record, `bind_identity`, forgery and overflow tests au_01..au_04 (9/9 mutants killed). Gaps listed in CONTRACTS_v1.md.
* Supervisor backoff overflow defect found and fixed in the reference model.
