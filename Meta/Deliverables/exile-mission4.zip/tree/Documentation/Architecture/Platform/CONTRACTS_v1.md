# Trust-boundary contracts, version 1.2.0 (PROPOSED)

Machine-readable form: `Meta/Exile/contracts/exile-contracts-v1.json`. Drift check against the sources:
`python3 Meta/Exile/contracts/check_contracts.py` (and `--self-test`, which must detect 10/10 mutations).
This checks names and numbers. **Behaviour is proven only by the tests listed under each contract**, and all of them are HOSTED.

## Identity
* A *space* is the unit of address-space and capability ownership. `SpaceId` is a `u16`; `0` is the kernel.
* The acting space and thread are **kernel-asserted** (from the scheduler). They are never read from syscall arguments or message bytes.
* A received message carries its sender's space id at offset 16 of the 88-byte receive result (`u32`). Wire 1.0 had zero there; 1.1 fills it.
  Receivers MUST treat 0 as "unknown/kernel". *Tests:* `tb_05` (payload claims space 9; receiver sees 2).
* A *service* has a stable `ServiceId` (u16) and a per-start `Incarnation` (u32, never 0). Events naming an old incarnation are ignored and audited.
  *Tests:* `supervisor::stale_incarnation_events_cannot_affect_the_successor`.
* Gap: no link from `LibExilePolicy` principals to space ids. The broker cannot yet ask "which space is this principal".

## Address-space ownership
A user region belongs to exactly one space. A user pointer is usable only if the caller's region model **and** its page-table walk permit the access;
kernel-half, null, unmapped, other-space and read-only-for-write pointers are refused and change nothing. *Tests:* `tb_01_02`, `tb_03`
(software page tables). **No hardware claim.**

## Capabilities
* Handle = `generation << 16 | index` (generation 0 invalid), 32 per space. A handle is an untrusted number; only the owning table decides what it means.
* Validation order (fixed): live capability → live object with matching generation → object type → rights.
* Create: `endpoint_create`. Transfer: *move* (cannot attenuate) or *copy* (needs TRANSFER and DUPLICATE; may only reduce rights).
* Attenuation: copy-time rights mask. Revocation: `close` (needs ADMIN) destroys the end for **every** holder; `release` drops only the caller's handle;
  space exit releases everything; slot reuse never revives an old handle. *Tests:* `tb_04`, `tb_08` (stale object generation cannot alias a reused slot; found
  by mutation testing), Batch 11 `cap_01..10`.
* Not implemented: derivation trees (revoke-by-ancestor) and objects other than channels.

## IPC
* 32-byte header, ≤1024-byte messages, ≤8 descriptors, queue depth 4, validated field by field; oversize and malformed input rejected, never truncated.
* Timeouts are scheduler ticks (max 1<<20); unbounded waits are refused.
* Failure reporting: peer death → `PEER_DEAD`; terminated waiters → `CANCELLED`; timeouts → `TIMED_OUT`.
* Cancellation: kernel-initiated (peer close, space termination, timeout) and **explicit tokens** (v1.2.0, additive, backward compatible: 1.1 code never calls 0x104/0x105, which previously returned `NOT_SUPPORTED`).
  `0x104` creates a token (8-byte out buffer, handle u32 at offset 0; rights SIGNAL|WAIT|DUPLICATE|TRANSFER = 0x78); `0x105` signals it (needs SIGNAL; sticky, idempotent).
  A send/recv whose `cancel` field names a signalled token (needs WAIT) returns `CANCELLED` and enqueues/consumes nothing; cancellation wins over a queued message.
  Evidence: HOSTED tests cn_01..cn_12 only; not exercised on a booted kernel.

## Audit
One 6-field record (`seq, kind, space, nr, principal, result`) per syscall and per lifecycle event in a 128-entry ring. Kinds: `Allowed, Denied, Failed,
SpaceTerminated, ServiceRestart, IdentityBound, Fault, PolicyDenied`. Overwrites the oldest and counts `dropped`; `export()` copies the held records for a future trusted consumer (a strategy, not persistence).
**Identity link:** a trusted launcher calls `IpcKernel::bind_identity(space, principal, incarnation)` once per space (kernel-side API, no syscall); the 64-bit `principal` (derived from the
LibExilePolicy principal via `exile::policy::kernelPrincipalId`, a SHA-256 prefix; correlation key, not a secret) is attached to every record the space causes and survives its termination. **Forgery:** no syscall reads audit content from user memory;
`record_external` accepts only `ServiceRestart` and `PolicyDenied`. Malformed syscall frames are recorded as `Fault`.
NOT emitted (gaps): space creation (Batch 7 scheduler), capability grant/revoke as distinct kinds (covered by the per-syscall `Allowed` record), page faults / memory-protection violations (need a real MMU),
supervisor decisions other than restarts. Tests au_01..au_04, mutation-checked (9/9). **Kernel memory only: nothing persists or ships it, and it offers no tamper protection.**

## Recovery
`Supervisor` (portable state machine): failures → revoke authority of the dead incarnation **first**, then exponential backoff (`base << n`, capped),
then grant fresh authority and spawn; a failed spawn leaves no grant; budget exhausted → `Failed` (no loop, no kernel failure); a stable run resets the
count; missed heartbeat/start timeouts count as failures. *Tests:* 12 supervisor unit tests (mutation-checked) and `tb_07` against the real kernel state.
**Not wired into `SystemServer`.**
