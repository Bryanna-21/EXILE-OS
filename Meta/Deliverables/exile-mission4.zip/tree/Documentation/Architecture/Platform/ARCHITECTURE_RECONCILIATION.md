# Architecture reconciliation report (Mission: Core Execution and Trust Boundary, Phase 1)

Written from the repository on 2026-11-18, not from earlier reports. Evidence tags: **S** read in source · **T** a test ran in this
mission · **N** nothing executed.

## 0. Repository state at the start
| Worktree | Branch | HEAD | Tracked changes | Untracked |
|---|---|---|---|---|
| `EXILE-OS-wt-orch` (this work) | `validation/orchestrator` | f51661db | none (before this mission) | `Meta/Exile/{build,validation,installer,platform}`, `Documentation/Architecture/Platform` |
| `EXILE-OS-wt-core` | `feature/core-identity-architecture` | f51661db | none | `Userland/Libraries/LibExilePolicy`, `Documentation/Architecture/CoreIdentity` |
Nothing is staged. No branch was switched, nothing committed. **Cross-branch note:** `LibExilePolicy` (wt-core) and
`Meta/Exile/platform` (wt-orch) live on different branches, both untracked; this mission read the former and did not copy or edit it.

## 1. Who owns what
| Subsystem | Owner (keep) | Other implementations | Evidence |
|---|---|---|---|
| Production kernel (x86-64, aarch64, riscv64) | `Kernel/` (C++, Serenity-derived) | `ExileKernel/` (EUK, Rust, 327 lines: boot + memory-map only), OMNI Batches 7–11 (Rust, hosted) | S |
| Processes/threads/scheduler | `Kernel/Tasks` (`Scheduler.cpp` 603 lines, `Process.cpp` 1425, SMP, preemptive) | OMNI Batch 7 (cooperative, uniprocessor, 16 threads) is a test bed, not a kernel | S |
| Address spaces / VM | `Kernel/Memory` (`AddressSpace.cpp`, regions, VM objects, NX/SMEP/SMAP/UMIP enabled per Batch 10 reading) | OMNI Batch 8 mapper + Batch 9 `PagedBacking` (software page tables) | S, T (OMNI parts) |
| Syscalls | `Kernel/Syscalls` (73 files; register convention rax; rdx, rdi, rbx, rsi) | OMNI 0x100–0x1F8 range, `AbiMode` adaptor | S |
| Sandboxing today | `Kernel/Syscalls/{pledge,unveil,unshare}.cpp` | none in OMNI | S |
| **Object capabilities + channel IPC** | **None in `Kernel/`** (grep: no capability object type) | Zig models (Batches 2–5) and **Rust Batch 11** (`caps.rs`, `ipc.rs`, `sys.rs`) | S, T |
| User-facing permission policy | `LibExilePolicy` (`permission.cpp` 367 lines, `broker.cpp` 483, `kernel_map.cpp` 77) | — | S |
| Service supervision | `Userland/Services/SystemServer` (`Service.cpp`: `KeepAlive`, at most 3 restarts and only for runs < 1 s, no backoff, no health check, no audit) | `Meta/Exile/platform/src/supervisor.rs` (new reference model) | S, T |
| Boot | `Kernel/Prekernel` + GRUB/Multiboot (BIOS) | EUK Multiboot reference; UEFI: none | S |

## 2. Duplicates and how they are resolved
1. **Two schedulers/VMs/syscall tables (Kernel/ vs OMNI).** Not competing: `ARCHITECTURE_DECISION.md` (Batch 10) and
   `ARCHITECTURE_AND_MIGRATION.md` (Batch 11) classify OMNI as a test bed whose proven semantics are ported to `Kernel/`.
   **That decision is still PROPOSED and awaits owner approval.** This mission adopts it as a *working assumption* and
   introduces no new kernel, scheduler, VM manager or IPC mechanism. See `ADR-0001`.
2. **Three authority vocabularies.** (a) `LibExilePolicy` principals/grants (user-facing), (b) pledge/unveil (the only authority the
   real kernel enforces today), (c) Batch 11 object capabilities (not in `Kernel/`). Reconciled as layers: the **broker decides**, the
   **kernel enforces**. `kernel_map.cpp` already projects broker grants onto (b); (c) is the future object-level mechanism for IPC.
   Gap: no principal-to-space identity link yet (see `CONTRACTS_v1.md`, "Identity").
3. **Two audit trails.** `LibExilePolicy` `AuditEntry` (policy decisions) and the new kernel audit ring (low-level denials). Different
   layers; correlation needs a shared principal/space id, which does not exist yet.
4. **Two IPC mechanisms.** `LibIPC` (socket-based, used by Exile userland) and Batch 11 channels (opt-in, hosted). No service uses
   channels; migration is staged in Batch 11 `USERLAND_INTEGRATION.md`.

## 3. Missing interfaces and incomplete implementations (found, not hidden)
* `Kernel/` has **no capability or channel-IPC object**; Batch 11 is the only implementation and it runs hosted only.
* Explicit cancellation tokens: implemented in Batch 11 (hosted tests only, contract 1.2.0). Kernel-initiated cancellation works.
* Caller identity on received messages did not exist; **added this mission** (wire 1.1, offset 16 of the receive result).
* No audit log existed in the Rust kernel; **added this mission** (`audit.rs`).
* `SystemServer` has no backoff/health/capability reacquisition; the reference model exists, **the C++ port does not**.
* No QEMU run of any Rust kernel image has ever happened in this environment (no QEMU, GRUB, pinned toolchain).
* `Kernel/` could not be compiled or run here; every statement about it is **S**.

## 4. Decision for this mission
Extend the **existing owner** of each missing piece (Batch 11 for capability/IPC semantics; the platform crate for portable policy
logic) and prove the contract with tests; do not start a parallel kernel. Everything that must run on a CPU is marked BLOCKED.
