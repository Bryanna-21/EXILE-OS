# ADR-0001: Kernel ownership and where the trust-boundary work lands

Status: **Working assumption, owner approval pending.** It restates the PROPOSED decisions of OMNI Batch 10 (`ARCHITECTURE_DECISION.md`) and Batch 11
(`ARCHITECTURE_AND_MIGRATION.md`); it does not make them final.

Context: three kernel-shaped trees exist (`Kernel/`, `ExileKernel/`, OMNI Batches 7–11). The mission forbids competing kernel/scheduler/VM/IPC implementations
and forbids silently changing architecture decisions.

Decision (assumed): `Kernel/` is the production kernel; EUK is the boot reference; OMNI is the semantic test bed. New trust-boundary **semantics** are developed in
the existing owner (Batch 11: audit, sender identity) and in portable `no_std` policy code (`Meta/Exile/platform`: supervisor). **Porting into `Kernel/` (C++) is a
separate, reviewed step** because it cannot be compiled or booted here.

Consequences: (+) no new competing kernel; contracts are testable now. (−) The completion criterion ("demonstrated on the intended target") is NOT met; the demo is hosted.
Alternatives not chosen: building a Rust kernel from EUK (months, unverifiable here); editing `Kernel/` blind (violates "do not claim what you cannot run").
Needs the owner: confirm or change the assumption; reserve syscall numbers 0x100–0x107 in `Kernel/API/Syscall.h` before any port.
