/*
 * Copyright (c) 2026, the Exile OS developers
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#pragma once

// C++ port of the supervision policy in Meta/Exile/platform/src/supervisor.rs.
//
// Semantics are kept IDENTICAL to the Rust reference model and that is CHECKED: both implementations run
// the shared scenario vectors in ./vectors and must produce byte-identical traces
// (Meta/Exile/validation/run_supervisor_equivalence.sh).
//
// STATUS: host-built and host-tested only. This library is NOT yet linked into
// Userland/Services/SystemServer (which still has its own 3-attempt restart logic) and has never run
// under the Exile kernel. No heap use, no exceptions, no dependency on AK/LibCore, so it can be built
// both on a host and inside the OS tree.

#include <cstdint>

namespace exile::supervisor {

using Incarnation = uint32_t; // 0 is never used
using ServiceId = uint16_t;

struct Policy {
    uint8_t max_failures;
    uint64_t backoff_base;
    uint64_t backoff_cap;
    uint64_t stable_after;
    uint64_t health_timeout; // 0 disables health checks
    uint64_t start_timeout;
};

enum class StateKind : uint8_t { Stopped, Starting, Running, Backoff, Failed };

struct State {
    StateKind kind = StateKind::Stopped;
    uint64_t a = 0; // Starting: deadline; Running: since; Backoff: until
    uint64_t b = 0; // Running: last_beat
};

enum class EventKind : uint8_t { Started, Running, Failure, RestartScheduled, CapsRevoked, CapsGranted, GaveUp, StaleIgnored };
enum class ReasonKind : uint8_t { Exited, Unhealthy, StartTimeout, SpawnFailed };

struct Event {
    EventKind kind;
    ServiceId id;
    Incarnation inc = 0;
    ReasonKind reason = ReasonKind::Exited; // Failure only
    int32_t exit_status = 0;                // Failure/Exited only
    uint64_t delay = 0;                     // RestartScheduled only
};

enum class Error : uint8_t { Ok, Full, Unknown, BadPolicy, BadState };

class Effects {
public:
    virtual ~Effects() = default;
    virtual bool spawn(ServiceId, Incarnation) = 0; // false = could not spawn
    virtual void kill(ServiceId, Incarnation) = 0;
    virtual void revoke_caps(ServiceId, Incarnation) = 0;
    virtual bool grant_caps(ServiceId, Incarnation) = 0; // false = refused
    virtual void audit(Event const&) = 0;
};

constexpr unsigned MaxServices = 16;

class Supervisor {
public:
    Error register_service(ServiceId, Policy const&);
    Error start(ServiceId, uint64_t now, Effects&);
    Error reset(ServiceId);
    Error started(ServiceId, Incarnation, uint64_t now, Effects&);
    Error heartbeat(ServiceId, Incarnation, uint64_t now, Effects&);
    Error exited(ServiceId, Incarnation, int32_t status, uint64_t now, Effects&);
    void tick(uint64_t now, Effects&);

    bool status(ServiceId, State& out_state, Incarnation& out_inc) const;
    bool failures(ServiceId, uint8_t& out) const;

private:
    struct Svc {
        bool used = false;
        ServiceId id = 0;
        Policy policy {};
        State state {};
        Incarnation inc = 0;
        uint8_t failures = 0;
    };
    Svc* find(ServiceId);
    Svc const* find(ServiceId) const;
    Svc m_svcs[MaxServices] {};
};

}
