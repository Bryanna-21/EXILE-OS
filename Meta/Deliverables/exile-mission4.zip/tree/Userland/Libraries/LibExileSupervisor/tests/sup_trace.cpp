// Scenario runner for supervisor equivalence checking against the Rust reference model
// (Meta/Exile/platform/examples/sup_trace.rs). Both must print byte-identical traces.
#include "../Supervisor.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

using namespace exile::supervisor;

struct Fx : Effects {
    bool spawn_fail = false, grant_fail = false;
    bool spawn(ServiceId i, Incarnation n) override
    {
        std::printf("fx spawn %u %u\n", i, n);
        return !spawn_fail;
    }
    void kill(ServiceId i, Incarnation n) override { std::printf("fx kill %u %u\n", i, n); }
    void revoke_caps(ServiceId i, Incarnation n) override { std::printf("fx revoke %u %u\n", i, n); }
    bool grant_caps(ServiceId i, Incarnation n) override
    {
        std::printf("fx grant %u %u\n", i, n);
        return !grant_fail;
    }
    void audit(Event const& e) override
    {
        switch (e.kind) {
        case EventKind::Started: std::printf("ev Started %u %u\n", e.id, e.inc); break;
        case EventKind::Running: std::printf("ev Running %u %u\n", e.id, e.inc); break;
        case EventKind::Failure:
            switch (e.reason) {
            case ReasonKind::Exited: std::printf("ev Failure %u %u Exited(%d)\n", e.id, e.inc, e.exit_status); break;
            case ReasonKind::Unhealthy: std::printf("ev Failure %u %u Unhealthy\n", e.id, e.inc); break;
            case ReasonKind::StartTimeout: std::printf("ev Failure %u %u StartTimeout\n", e.id, e.inc); break;
            case ReasonKind::SpawnFailed: std::printf("ev Failure %u %u SpawnFailed\n", e.id, e.inc); break;
            }
            break;
        case EventKind::RestartScheduled: std::printf("ev RestartScheduled %u %u %llu\n", e.id, e.inc, (unsigned long long)e.delay); break;
        case EventKind::CapsRevoked: std::printf("ev CapsRevoked %u %u\n", e.id, e.inc); break;
        case EventKind::CapsGranted: std::printf("ev CapsGranted %u %u\n", e.id, e.inc); break;
        case EventKind::GaveUp: std::printf("ev GaveUp %u\n", e.id); break;
        case EventKind::StaleIgnored: std::printf("ev StaleIgnored %u %u\n", e.id, e.inc); break;
        }
    }
};

static void ret(Error e)
{
    char const* n[] = { "Ok", "Full", "Unknown", "BadPolicy", "BadState" };
    std::printf("ret %s\n", n[static_cast<int>(e)]);
}

int main(int argc, char** argv)
{
    if (argc < 2)
        return 2;
    std::ifstream in(argv[1]);
    if (!in)
        return 2;
    Supervisor sup;
    Fx fx;
    std::vector<unsigned> ids;
    std::string line;
    while (std::getline(in, line)) {
        std::istringstream ss(line);
        std::vector<std::string> w;
        for (std::string t; ss >> t;)
            w.push_back(t);
        if (w.empty() || w[0][0] == '#')
            continue;
        // canonical echo: single-space-joined, like the Rust side's trimmed line (inputs use single spaces)
        std::string echo = w[0];
        for (size_t k = 1; k < w.size(); ++k)
            echo += " " + w[k];
        std::printf("> %s\n", echo.c_str());
        auto n = [&](size_t i) { return std::strtoull(w[i].c_str(), nullptr, 10); };
        auto sn = [&](size_t i) { return std::strtoll(w[i].c_str(), nullptr, 10); };
        auto sid = [&](size_t i) { return static_cast<ServiceId>(n(i)); };
        auto const& c = w[0];
        if (c == "reg") {
            Policy p { static_cast<uint8_t>(n(2)), n(3), n(4), n(5), n(6), n(7) };
            auto r = sup.register_service(sid(1), p);
            if (r == Error::Ok)
                ids.push_back(static_cast<unsigned>(n(1)));
            ret(r);
        } else if (c == "start") ret(sup.start(sid(1), n(2), fx));
        else if (c == "started") ret(sup.started(sid(1), static_cast<Incarnation>(n(2)), n(3), fx));
        else if (c == "beat") ret(sup.heartbeat(sid(1), static_cast<Incarnation>(n(2)), n(3), fx));
        else if (c == "exit") ret(sup.exited(sid(1), static_cast<Incarnation>(n(2)), static_cast<int32_t>(sn(3)), n(4), fx));
        else if (c == "tick") sup.tick(n(1), fx);
        else if (c == "reset") ret(sup.reset(sid(1)));
        else if (c == "spawnfail") fx.spawn_fail = n(1) != 0;
        else if (c == "grantfail") fx.grant_fail = n(1) != 0;
        else {
            std::fprintf(stderr, "unknown command %s\n", c.c_str());
            return 2;
        }
        for (auto i : ids) {
            State st;
            Incarnation inc;
            uint8_t f;
            sup.status(static_cast<ServiceId>(i), st, inc);
            sup.failures(static_cast<ServiceId>(i), f);
            char const* k[] = { "Stopped", "Starting", "Running", "Backoff", "Failed" };
            std::printf("st %u %s %llu %llu inc=%u fail=%u\n", i, k[static_cast<int>(st.kind)], (unsigned long long)st.a, (unsigned long long)st.b, inc, f);
        }
    }
}
