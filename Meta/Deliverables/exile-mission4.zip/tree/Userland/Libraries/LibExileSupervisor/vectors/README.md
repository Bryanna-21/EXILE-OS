# Supervisor equivalence vectors

Scenario files (`*.scn`) drive BOTH the Rust reference model (`Meta/Exile/platform/examples/sup_trace.rs`) and the
C++ port (`tests/sup_trace.cpp`). Each prints a canonical trace; `*.expected` is the committed Rust trace and the
C++ trace must match it byte for byte. Run `Meta/Exile/validation/run_supervisor_equivalence.sh`.

Commands (one per line, single-space separated, `#` comments):
`reg ID max_failures base cap stable_after health_timeout start_timeout` · `start ID T` · `started ID INC T` ·
`beat ID INC T` · `exit ID INC STATUS T` · `tick T` · `reset ID` · `spawnfail 0|1` · `grantfail 0|1`.

HOSTED evidence only: this shows two host builds agree; it says nothing about SystemServer integration or the kernel.
