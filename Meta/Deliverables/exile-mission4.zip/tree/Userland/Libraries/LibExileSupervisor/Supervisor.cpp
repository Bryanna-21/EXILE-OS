/*
 * Copyright (c) 2026, the Exile OS developers
 *
 * SPDX-License-Identifier: BSD-2-Clause
 */

#include "Supervisor.h"

namespace exile::supervisor {

namespace {

uint64_t sat_add(uint64_t a, uint64_t b)
{
    return a > UINT64_MAX - b ? UINT64_MAX : a + b;
}
uint64_t sat_sub(uint64_t a, uint64_t b) { return a > b ? a - b : 0; }

}

}

namespace exile::supervisor {

// Svc is a private type of Supervisor, so the two helpers are templates over it: they are only ever
// instantiated from Supervisor's own member functions.
template<typename S>
static void fail_impl(S& s, ReasonKind reason, int32_t status, uint64_t now, Effects& fx)
{
    bool ran_stable = s.state.kind == StateKind::Running && sat_sub(now, s.state.a) >= s.policy.stable_after;
    if (ran_stable)
        s.failures = 0;
    fx.revoke_caps(s.id, s.inc);
    fx.audit({ EventKind::CapsRevoked, s.id, s.inc });
    Event f { EventKind::Failure, s.id, s.inc };
    f.reason = reason;
    f.exit_status = reason == ReasonKind::Exited ? status : 0;
    fx.audit(f);
    s.failures = s.failures == 255 ? 255 : static_cast<uint8_t>(s.failures + 1);
    if (s.failures > s.policy.max_failures) {
        s.state = { StateKind::Failed, 0, 0 };
        fx.audit({ EventKind::GaveUp, s.id });
        return;
    }
    // delay = base << (failures-1), capped; bit loss saturates to UINT64_MAX (same rule as the Rust model).
    unsigned shift = s.failures - 1u;
    if (shift > 32)
        shift = 32;
    uint64_t delay;
    if (shift >= 64 || (s.policy.backoff_base << shift) >> shift != s.policy.backoff_base)
        delay = UINT64_MAX;
    else
        delay = s.policy.backoff_base << shift;
    if (delay > s.policy.backoff_cap)
        delay = s.policy.backoff_cap;
    s.state = { StateKind::Backoff, sat_add(now, delay), 0 };
    Event r { EventKind::RestartScheduled, s.id, s.inc };
    r.delay = delay;
    fx.audit(r);
}

template<typename S>
static void launch_impl(S& s, uint64_t now, Effects& fx)
{
    s.inc = s.inc + 1;
    if (s.inc == 0)
        s.inc = 1;
    if (!fx.grant_caps(s.id, s.inc)) {
        fail_impl(s, ReasonKind::SpawnFailed, 0, now, fx);
        return;
    }
    fx.audit({ EventKind::CapsGranted, s.id, s.inc });
    if (!fx.spawn(s.id, s.inc)) {
        // fail revokes the authority just granted, so a failed spawn never leaves a live grant.
        fail_impl(s, ReasonKind::SpawnFailed, 0, now, fx);
        return;
    }
    fx.audit({ EventKind::Started, s.id, s.inc });
    s.state = { StateKind::Starting, sat_add(now, s.policy.start_timeout), 0 };
}

Supervisor::Svc* Supervisor::find(ServiceId id)
{
    for (auto& s : m_svcs)
        if (s.used && s.id == id)
            return &s;
    return nullptr;
}
Supervisor::Svc const* Supervisor::find(ServiceId id) const
{
    for (auto const& s : m_svcs)
        if (s.used && s.id == id)
            return &s;
    return nullptr;
}

Error Supervisor::register_service(ServiceId id, Policy const& p)
{
    if (p.backoff_base == 0 || p.backoff_cap < p.backoff_base || p.max_failures == 0 || p.start_timeout == 0)
        return Error::BadPolicy;
    if (find(id))
        return Error::BadState;
    for (auto& s : m_svcs) {
        if (!s.used) {
            s = {};
            s.used = true;
            s.id = id;
            s.policy = p;
            return Error::Ok;
        }
    }
    return Error::Full;
}

Error Supervisor::start(ServiceId id, uint64_t now, Effects& fx)
{
    auto* s = find(id);
    if (!s)
        return Error::Unknown;
    if (s->state.kind != StateKind::Stopped)
        return Error::BadState;
    launch_impl(*s, now, fx);
    return Error::Ok;
}

Error Supervisor::reset(ServiceId id)
{
    auto* s = find(id);
    if (!s)
        return Error::Unknown;
    if (s->state.kind != StateKind::Failed)
        return Error::BadState;
    s->state = {};
    s->failures = 0;
    return Error::Ok;
}

Error Supervisor::started(ServiceId id, Incarnation inc, uint64_t now, Effects& fx)
{
    auto* s = find(id);
    if (!s)
        return Error::Unknown;
    if (inc != s->inc) {
        fx.audit({ EventKind::StaleIgnored, id, inc });
        return Error::Ok;
    }
    if (s->state.kind != StateKind::Starting)
        return Error::BadState;
    s->state = { StateKind::Running, now, now };
    fx.audit({ EventKind::Running, id, inc });
    return Error::Ok;
}

Error Supervisor::heartbeat(ServiceId id, Incarnation inc, uint64_t now, Effects& fx)
{
    auto* s = find(id);
    if (!s)
        return Error::Unknown;
    if (inc != s->inc) {
        fx.audit({ EventKind::StaleIgnored, id, inc });
        return Error::Ok;
    }
    if (s->state.kind == StateKind::Running)
        s->state.b = now;
    return Error::Ok;
}

Error Supervisor::exited(ServiceId id, Incarnation inc, int32_t status, uint64_t now, Effects& fx)
{
    auto* s = find(id);
    if (!s)
        return Error::Unknown;
    if (inc != s->inc) {
        fx.audit({ EventKind::StaleIgnored, id, inc });
        return Error::Ok;
    }
    if (s->state.kind != StateKind::Starting && s->state.kind != StateKind::Running)
        return Error::BadState;
    if (status == 0) {
        fx.revoke_caps(id, inc);
        fx.audit({ EventKind::CapsRevoked, id, inc });
        s->state = {};
        return Error::Ok;
    }
    fail_impl(*s, ReasonKind::Exited, status, now, fx);
    return Error::Ok;
}

void Supervisor::tick(uint64_t now, Effects& fx)
{
    for (auto& s : m_svcs) {
        if (!s.used)
            continue;
        switch (s.state.kind) {
        case StateKind::Starting:
            if (now >= s.state.a) {
                fx.kill(s.id, s.inc);
                fail_impl(s, ReasonKind::StartTimeout, 0, now, fx);
            }
            break;
        case StateKind::Running:
            if (s.policy.health_timeout != 0 && sat_sub(now, s.state.b) >= s.policy.health_timeout) {
                fx.kill(s.id, s.inc);
                fail_impl(s, ReasonKind::Unhealthy, 0, now, fx);
            }
            break;
        case StateKind::Backoff:
            if (now >= s.state.a)
                launch_impl(s, now, fx);
            break;
        default:
            break;
        }
    }
}

bool Supervisor::status(ServiceId id, State& st, Incarnation& inc) const
{
    auto const* s = find(id);
    if (!s)
        return false;
    st = s->state;
    inc = s->inc;
    return true;
}

bool Supervisor::failures(ServiceId id, uint8_t& out) const
{
    auto const* s = find(id);
    if (!s)
        return false;
    out = s->failures;
    return true;
}

}
