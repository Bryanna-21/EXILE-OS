//! Kernel-managed identities + capability-based authorization, enforced at
//! actual access boundaries. No unsafe, no hardware â€” fully host-testable.
//! BATCH-2 FIXES vs Batch 1: Cap now STORES its CapHandle (find/attenuate/
//! revoke match correctly); check() distinguishes DenyStale (revoked or
//! owner-dead) from DenyNoCap; added live_count(); path covering now requires
//! a directory-boundary match so "/data" does NOT cover "/database".

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Pid(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct IdentityId(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Kind { Kernel, User, Service, App, Agent }

#[derive(Debug, Clone, Copy)]
pub struct Identity {
    pub id: IdentityId,
    pub kind: Kind,
    pub owner: Option<IdentityId>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CapHandle(pub u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Right { Read, Write, Grant, Connect, Open }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Resource {
    Path { prefix: [u8; 64], len: usize },
    Endpoint { id: u64 },
    Device { id: u64 },
    Memory { region: u64 },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Decision {
    Allow,
    DenyNoCap,
    DenyStale,
    DenyInsufficient,
}

pub const R_READ: u8 = 1;
pub const R_WRITE: u8 = 2;
pub const R_GRANT: u8 = 4;
pub const R_CONNECT: u8 = 8;
pub const R_OPEN: u8 = 16;

#[derive(Clone, Copy)]
struct Cap {
    handle: CapHandle,     // BATCH-2 FIX: handle is stored, not reconstructed
    owner: Pid,
    resource: Resource,
    rights: u8,
    live: bool,
}

/// Per-kernel capability space. Fixed table, no allocation.
pub struct Space {
    caps: [Option<Cap>; 128],
    next_handle: u64,
    next_identity: u64,
}


impl Space {
    pub fn new_root() -> Self {
        Space { caps: [None; 128], next_handle: 1, next_identity: 1 }
    }

    pub fn new_identity(&mut self, kind: Kind, owner: Option<IdentityId>) -> Identity {
        let id = IdentityId(self.next_identity);
        self.next_identity += 1;
        Identity { id, kind, owner }
    }

    /// THE access-boundary check (BATCH-2 FIX: stale is distinguished).
    /// A cap that covers the resource but is dead (revoked/owner exited)
    /// yields DenyStale; a cap that covers with insufficient rights yields
    /// DenyInsufficient; no covering cap yields DenyNoCap.
    pub fn check(&self, pid: Pid, res: &Resource, rights: u8) -> Decision {
        let mut dead_cover: Option<u8> = None;
        let mut live_partial: Option<u8> = None;
        for c in self.caps.iter().flatten() {
            if c.owner != pid || !resource_covers(c.resource, *res) {
                continue;
            }
            if !c.live {
                dead_cover = Some(c.rights);
                continue;
            }
            if c.rights & rights == rights {
                return Decision::Allow;
            }
            if live_partial.is_none() {
                live_partial = Some(c.rights);
            }
        }
        if live_partial.is_some() {
            Decision::DenyInsufficient
        } else if dead_cover.is_some() {
            Decision::DenyStale
        } else {
            Decision::DenyNoCap
        }
    }

    /// Grant rights to `to`. Requires the granter to hold `rights|GRANT` on
    /// the exact resource. Attenuation is inherent: granted rights âŠ† granter's.
    pub fn grant(&mut self, from: Pid, to: Pid, res: Resource, rights: u8) -> Result<CapHandle, Decision> {
        let need = rights | R_GRANT;
        match self.check(from, &res, need) {
            Decision::Allow => self.insert(to, res, rights),
            other => Err(other),
        }
    }

    /// Attenuate an existing capability down to a strict subset.
    pub fn attenuate(&mut self, pid: Pid, h: CapHandle, subset: u8) -> Result<CapHandle, Decision> {
        let slot = self.slot_of(pid, h).ok_or(Decision::DenyStale)?;
        // SAFETY-free: slot_of validated the slot exists and is owned/live.
        let (resource, rights) = {
            let c = self.caps[slot].expect("slot_of checked");
            (c.resource, c.rights)
        };
        if subset & !rights != 0 || subset == 0 {
            return Err(Decision::DenyInsufficient);
        }
        self.insert(pid, resource, subset)
    }

    pub fn revoke(&mut self, pid: Pid, h: CapHandle) -> Result<(), Decision> {
        let slot = self.slot_of(pid, h).ok_or(Decision::DenyStale)?;
        if let Some(c) = self.caps[slot].as_mut() {
            c.live = false;
        }
        Ok(())
    }

    /// On process exit: every capability it holds dies with it.
    pub fn revoke_all(&mut self, pid: Pid) -> usize {
        let mut n = 0;
        for c in self.caps.iter_mut().flatten() {
            if c.owner == pid && c.live {
                c.live = false;
                n += 1;
            }
        }
        n
    }

    /// BATCH-2 FIX (defect 5): count of live caps for syscall introspection.
    pub fn live_count(&self) -> u64 {
        self.caps.iter().flatten().filter(|c| c.live).count() as u64
    }

    pub fn table_len(&self) -> usize {
        self.caps.len()
    }

    fn slot_of(&self, pid: Pid, h: CapHandle) -> Option<usize> {
        self.caps.iter().position(|c| matches!(c, Some(c) if c.handle == h && c.owner == pid && c.live))
    }

    fn insert(&mut self, owner: Pid, resource: Resource, rights: u8) -> Result<CapHandle, Decision> {
        let slot = self.caps.iter().position(|c| c.is_none()).ok_or(Decision::DenyNoCap)?;
        let h = CapHandle(self.next_handle);
        self.next_handle += 1;
        self.caps[slot] = Some(Cap { handle: h, owner, resource, rights, live: true });
        Ok(h)
    }
}

/// BATCH-2 FIX: covering requires a directory-boundary match: the granted
/// prefix must equal the requested path up to its length, and the next
/// granted byte (if any) must be '/' or the granted prefix must end at the
/// full 64-byte buffer. This kills the "/data"-covers-"/database" bug at
/// BOTH ends (granted and requested).
fn resource_covers(granted: Resource, requested: Resource) -> bool {
    match (granted, requested) {
        (
            Resource::Path { prefix: g, len: gl },
            Resource::Path { prefix: r, len: rl },
        ) => {
            if rl < gl {
                return false; // requested is shorter than the granted prefix
            }
            if g[..gl] != r[..gl] {
                return false;
            }
            if gl == rl {
                return true; // exact match
            }
            // boundary: the granted prefix must terminate at a '/' in the
            // requested path (e.g. granted "/data" covers "/data/f" because
            // r[gl] == '/'), or the granted buffer is fully used.
            gl == 64 || r[gl] == b'/'
        }
        (Resource::Endpoint { id: a }, Resource::Endpoint { id: b }) => a == b,
        (Resource::Device { id: a }, Resource::Device { id: b }) => a == b,
        (Resource::Memory { region: a }, Resource::Memory { region: b }) => a == b,
        _ => false,
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    fn path(s: &str) -> Resource {
        let mut p = [0u8; 64];
        p[..s.len()].copy_from_slice(s.as_bytes());
        Resource::Path { prefix: p, len: s.len() }
    }

    #[test]
    fn grant_then_check_allows() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/data"), R_READ | R_WRITE).unwrap();
        assert_eq!(sp.check(Pid(2), &path("/data/file"), R_READ), Decision::Allow);
    }

    #[test]
    fn no_capability_is_deny() {
        let sp = Space::new_root();
        assert_eq!(sp.check(Pid(9), &path("/x"), R_READ), Decision::DenyNoCap);
    }

    #[test]
    fn insufficient_rights_denied() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/data"), R_READ).unwrap();
        assert_eq!(sp.check(Pid(2), &path("/data/f"), R_WRITE), Decision::DenyInsufficient);
    }

    #[test]
    fn attenuation_only_shrinks_and_cannot_reclaim() {
        let mut sp = Space::new_root();
        let h = sp.grant(Pid(1), Pid(2), path("/d"), R_READ | R_WRITE).unwrap();
        let h2 = sp.attenuate(Pid(2), h, R_READ).unwrap();
        assert_eq!(sp.check(Pid(2), &path("/d/f"), R_READ), Decision::Allow);
        assert_eq!(sp.check(Pid(2), &path("/d/f"), R_WRITE), Decision::DenyInsufficient);
        assert!(sp.attenuate(Pid(2), h2, R_WRITE).is_err()); // re-grow blocked
        assert!(sp.attenuate(Pid(2), h2, 0).is_err());        // empty subset blocked
    }

    #[test]
    fn grant_requires_grant_right() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        assert!(sp.grant(Pid(2), Pid(3), path("/d"), R_READ).is_err());
    }

    #[test]
    fn revocation_takes_effect_immediately_and_is_stale() {
        let mut sp = Space::new_root();
        let h = sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        sp.revoke(Pid(2), h).unwrap();
        assert_eq!(sp.check(Pid(2), &path("/d"), R_READ), Decision::DenyStale);
    }

    #[test]
    fn revoke_all_on_exit_kills_stale_handles() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/d"), R_READ | R_WRITE).unwrap();
        sp.grant(Pid(1), Pid(2), path("/e"), R_READ).unwrap();
        assert_eq!(sp.revoke_all(Pid(2)), 2);
        assert_eq!(sp.check(Pid(2), &path("/d"), R_READ), Decision::DenyStale);
        assert_eq!(sp.check(Pid(2), &path("/e"), R_READ), Decision::DenyStale);
    }

    #[test]
    fn path_prefix_needs_boundary_not_prefix_bytes() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/data"), R_READ).unwrap();
        assert_eq!(sp.check(Pid(2), &path("/database"), R_READ), Decision::DenyNoCap);
        assert_eq!(sp.check(Pid(2), &path("/data"), R_READ), Decision::Allow);
        assert_eq!(sp.check(Pid(2), &path("/data/x/y"), R_READ), Decision::Allow);
        assert_eq!(sp.check(Pid(2), &path("/dat"), R_READ), Decision::DenyNoCap);
    }

    #[test]
    fn handle_reuse_after_slot_free_still_unique() {
        let mut sp = Space::new_root();
        let h = sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        sp.revoke(Pid(2), h).unwrap();
        let h2 = sp.grant(Pid(1), Pid(3), path("/d"), R_READ).unwrap();
        assert_ne!(h, h2);
        // stale handle from before cannot be confused with the live one
        assert_eq!(sp.check(Pid(3), &path("/d"), R_READ), Decision::Allow);
        assert!(sp.revoke(Pid(3), h).is_err()); // old handle is dead
        assert!(sp.revoke(Pid(3), h2).is_ok());
    }

    #[test]
    fn live_count_tracks_grants_and_revoctions() {
        let mut sp = Space::new_root();
        assert_eq!(sp.live_count(), 0);
        let h = sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        assert_eq!(sp.live_count(), 1);
        sp.revoke(Pid(2), h).unwrap();
        assert_eq!(sp.live_count(), 0);
        sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        sp.grant(Pid(1), Pid(3), path("/e"), R_READ).unwrap();
        assert_eq!(sp.revoke_all(Pid(2)), 1);
        assert_eq!(sp.live_count(), 1);
    }

    #[test]
    fn stale_handle_of_dead_process_rejected() {
        let mut sp = Space::new_root();
        sp.grant(Pid(1), Pid(2), path("/d"), R_READ).unwrap();
        sp.revoke_all(Pid(2));
        // Pid(2) is gone; every operation on its handles must fail
        let sp2 = &mut sp;
        let h = CapHandle(1);
        assert!(sp2.revoke(Pid(2), h).is_err());
        assert!(sp2.attenuate(Pid(2), h, R_READ).is_err());
    }

    #[test]
    fn identity_ids_monotonic_and_not_pids() {
        let mut sp = Space::new_root();
        let a = sp.new_identity(Kind::Service, None);
        let b = sp.new_identity(Kind::Agent, Some(a.id));
        assert_ne!(a.id, b.id);
        assert_eq!(b.owner, Some(a.id));
        // identity ids and pids are different number spaces by construction
        assert_ne!(a.id.0, Pid(a.id.0).0.0);
    }
}

