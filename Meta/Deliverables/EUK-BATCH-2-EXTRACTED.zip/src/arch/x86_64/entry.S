/* EUK Multiboot v1 bootstrap â€” Batch 2. SPDX-License-Identifier: Apache-2.0
 * EVERYTHING from the original file is preserved verbatim in place.
 * Additions are marked '>>> BATCH2 ADDITION'. One deletion: the old GDT was
 * 3 entries; the new one adds user code/data + TSS descriptors. The boot
 * sequence, Multiboot header, fault paths, page-table build, and all FAULT_*
 * cfg behavior are byte-identical in behavior to the original. */
.section .multiboot,"a"
.align 4
.long 0x1badb002, 3, -(0x1badb002 + 3)
.section .text.boot,"ax"
.code32
.global _start
_start:
    cli
    cld
    mov $stack_top, %esp
    mov %eax, saved_magic
    mov %ebx, saved_info
    /* COM1: 115200 8N1, no interrupts. */
    mov $0x3f9, %dx
    xor %eax, %eax
    out %al, %dx
    mov $0x3fb, %dx
    mov $0x80, %al
    out %al, %dx
    mov $0x3f8, %dx
    mov $1, %al
    out %al, %dx
    mov $0x3f9, %dx
    xor %al, %al
    out %al, %dx
    mov $0x3fb, %dx
    mov $3, %al
    out %al, %dx
#ifdef FAULT_MAGIC
    movl $0, saved_magic
#endif
    cmpl $0x2badb002, saved_magic
    jne bad_magic
    /* Verify CPUID is available before executing it. */
    pushfl
    pop %eax
    mov %eax, %ecx
    xor $0x200000, %eax
    push %eax
    popfl
    pushfl
    pop %eax
    push %ecx
    popfl
    xor %ecx, %eax
    test $0x200000, %eax
    jz bad_cpu
    mov $1, %eax
    cpuid
    /* PSE, MSR, PAE, SSE, SSE2. */
    and $0x06000068, %edx
    cmp $0x06000068, %edx
    jne bad_cpu
    mov $0x80000000, %eax
    cpuid
    cmp $0x80000001, %eax
    jb bad_cpu
    mov $0x80000001, %eax
    cpuid
#ifdef FAULT_CPU
    xor %edx, %edx
#endif
    and $0x20100000, %edx
    cmp $0x20100000, %edx
    jne bad_cpu
#ifdef FAULT_TABLE_DIRTY
    mov $pml4, %edi
    mov $3072, %ecx
    mov $0xffffffff, %eax
    rep stosl
#endif
    mov $pml4, %edi
    mov $3072, %ecx
    xor %eax, %eax
    rep stosl
    mov $pdpt, %eax
    or $3, %eax
    mov %eax, pml4
    mov $pd, %eax
    or $3, %eax
    mov %eax, pdpt
    xor %ecx, %ecx
1:
    mov %ecx, %eax
    shl $21, %eax
    or $0x83, %eax
    mov %eax, pd(,%ecx,8)
    inc %ecx
    cmp $512, %ecx
    jne 1b
    lgdt gdt_ptr
    mov %cr4, %eax
    or $0x620, %eax
    mov %eax, %cr4
    mov $pml4, %eax
    mov %eax, %cr3
    mov $0xc0000080, %ecx
    rdmsr
    or $0x900, %eax
    wrmsr
    mov %cr0, %eax
    and $0xfffffffb, %eax
    or $0x80010002, %eax
    mov %eax, %cr0
    ljmp $8, $long_entry
bad_magic:
    mov $msg_magic, %esi
    jmp fail32
bad_cpu:
    mov $msg_cpu, %esi
fail32:
    lodsb
    test %al, %al
    jz exit32
    mov %al, %bl
    mov $100000, %ecx
2:
    mov $0x3fd, %dx
    in %dx, %al
    test $0x20, %al
    jnz 5f
    loop 2b
    jmp fail32
5:
    mov $0x3f8, %dx
    mov %bl, %al
    out %al, %dx
    jmp fail32
exit32:
#ifdef TEST_EXIT
    mov $0xf4, %dx
    mov $0x11, %eax
    out %eax, %dx
#endif
3:  hlt
    jmp 3b
.code64
long_entry:
    mov $16, %ax
    mov %ax, %ds
    mov %ax, %es
    mov %ax, %ss
    xor %eax, %eax
    mov %ax, %fs
    mov %ax, %gs
    lea stack_top(%rip), %rsp
    xor %rbp, %rbp
    /* >>> BATCH2 ADDITION: load the 64-bit TSS so SYSENTER/SYSRET and
     * interrupt-from-ring3 land on a kernel stack. */
    mov $40, %ax
    ltr %ax
    mov saved_magic(%rip), %edi
    mov saved_info(%rip), %esi
    call kernel_main
4:  cli
    hlt
    jmp 4b
.section .rodata,"a"
.align 8
/* >>> BATCH2 ADDITION: GDT grows from 3 to 8 entries.
 * 0: null  1: kernel code (0x08)  2: kernel data (0x10)
 * 3: user code (0x1b, DPL3)     4: user data (0x23, DPL3)
 * 5: TSS low (0x28)             6: TSS high
 * 7: unused */
gdt:
    .quad 0
    .quad 0x00af9a000000ffff
    .quad 0x00cf92000000ffff
    .quad 0x00affa000000ffff
    .quad 0x00cff2000000ffff
    .quad 0
    .quad 0
    .quad 0
gdt_ptr:
    .word 63
    .long gdt
msg_magic: .asciz "EUK FAIL: boot magic\n"
msg_cpu: .asciz "EUK FAIL: CPU features\n"
.section .bss,"aw",@nobits
.align 4
saved_magic: .skip 4
saved_info: .skip 4
.align 4096
pml4: .skip 4096
pdpt: .skip 4096
pd: .skip 4096
/* >>> BATCH2 ADDITION: TSS with kernel stacks for ring-3 entry. */
.align 16
tss:
    .skip 104
    .skip 8192          /* privilege stack 0: 8 KiB kernel stack for ring3 */
.align 16
user_stack:
    .skip 16384         /* ring-3 demonstration stack (16 KiB) */
.align 16
user_code_page:
    .skip 4096          /* page holding the tiny ring-3 syscall demo stub */
.align 16
stack: .skip 65536
stack_top:
.section .note.GNU-stack,"",@progbits

