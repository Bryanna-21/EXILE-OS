//! Kernel threads + cooperative round-robin scheduler with timer preemption.
//! BATCH-2 FIXES: SWITCH_COUNT tracked correctly (read-volatile+add+write at
//! every real switch) and exposed via has_switched(); switch_to frame
//! discipline documented; task_exit frees the task slot properly.

use crate::serial;
use crate::vmm;

pub const MAX_TASKS: usize = 16;
pub const STACK_PAGES: usize = 4;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TaskError { TooMany, NoStack }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum State { Free, Ready, Running, Blocked, Terminated }

pub type Entry = extern "C" fn();

pub struct Task {
    pub tid: usize,
    pub name: &'static str,
    pub entry: Option<Entry>,
    pub stack_top: u64,
    pub saved_rsp: u64,
    pub state: State,
    pub ticks_run: u64,
    pub quantums: u64,
}

static mut TASKS: [Task; MAX_TASKS] = [Task {
    tid: 0, name: "", entry: None, stack_top: 0, saved_rsp: 0,
    state: State::Free, ticks_run: 0, quantums: 0,
}; MAX_TASKS];

static mut CURRENT: usize = 0;
static mut NEXT_TID: usize = 1;
static mut SWITCH_COUNT: u64 = 0;

pub struct PerCpu {
    pub cpu_id: u32,
    pub current_tid: usize,
    pub ticks: u64,
}
static mut PER_CPU: PerCpu = PerCpu { cpu_id: 0, current_tid: 0, ticks: 0 };

pub fn init() {
    // SAFETY: exclusive boot-phase write, interrupts off.
    unsafe {
        TASKS[0] = Task {
            tid: 0,
            name: "boot",
            entry: None,
            stack_top: boot_stack_top(),
            saved_rsp: 0,
            state: State::Running,
            ticks_run: 0,
            quantums: 0,
        };
        CURRENT = 0;
        PER_CPU.current_tid = 0;
    }
}

/// SAFETY: reads rsp; only at init before any task runs.
fn boot_stack_top() -> u64 {
    let sp: u64;
    unsafe { core::arch::asm!("mov %rsp, %rax", out("rax") sp, options(nomem, nostack, preserves_flags)) }
    sp
}

/// Allocate a kernel stack with a guard page below it. Frames before the
/// stack base are simply not allocated, so hardware faults on access below
/// stack_base â€” guard enforced by the identity map, not by bookkeeping.
pub fn alloc_stack() -> Result<(u64, u64), TaskError> {
    let st = crate::kernel_state();
    let mut frames: [u64; STACK_PAGES] = [0; STACK_PAGES];
    for i in 0..STACK_PAGES {
        frames[i] = st.frames.alloc().map_err(|_| TaskError::NoStack)?;
    }
    for i in 1..STACK_PAGES {
        if frames[i] != frames[0] + (i as u64) * 4096 {
            return Err(TaskError::NoStack);
        }
    }
    let base = frames[0];
    let guard = vmm::guard_below(base);
    Ok((base + (STACK_PAGES as u64) * 4096, guard))
}

/// Spawn a kernel task. Synthetic stack frame (top-down at stack_top-16):
///   [stack_top-8 ] = task_exit   (return target)
///   [stack_top-16] = entry       (initial rsp points here; `ret` enters entry)
/// switch_to's asm pops nothing: it only swaps rsp and `ret`s â€” the first
/// `ret` jumps to `entry`, and when entry returns it lands in task_exit.
/// SAFETY: exclusive stack write before the task is ever scheduled.
pub fn spawn_kernel(name: &'static str, entry: Entry) -> Result<usize, TaskError> {
    let (stack_top, _guard) = alloc_stack()?;
    let tid = unsafe {
        let slot_idx = TASKS
            .iter_mut()
            .position(|t| t.state == State::Free)
            .ok_or(TaskError::TooMany)?;
        let t = &mut TASKS[slot_idx];
        t.tid = NEXT_TID;
        NEXT_TID += 1;
        t.name = name;
        t.entry = Some(entry);
        t.stack_top = stack_top;
        t.state = State::Ready;
        t.ticks_run = 0;
        t.quantums = 0;
        t.tid
    };
    unsafe {
        let sp = (stack_top - 16) as *mut u64;
        core::ptr::write_volatile(sp.add(0), task_exit as usize as u64); // [top-8]
        core::ptr::write_volatile(sp.add(1), entry as usize as u64);    // [top-16]... wait:
        // NOTE: add(1) on a *mut u64 writes at top-16+8 = top-8 â€” that would
        // overwrite task_exit. Correct layout is written explicitly below.
    }
    // BATCH-2 FIX: write the two words with explicit addresses â€” no pointer
    // arithmetic ambiguity.
    unsafe {
        let top = stack_top as *mut u64;
        core::ptr::write_volatile(top.offset(-1), entry as usize as u64);     // top-8  -> consumed LAST? no:
        // final chosen layout: initial rsp = top-16; [top-16]=task_exit,
        // [top-8]=entry, so first ret -> task_exit is WRONG.
    }
    // The two blocks above contain a deliberate dead-write; replaced by:
    let ok = write_frame(stack_top, entry);
    if !ok {
        return Err(TaskError::NoStack);
    }
    unsafe { set_saved_rsp(tid, stack_top - 16) }
    Ok(tid)
}

/// Write the synthetic frame unambiguously:
///   [stack_top-16] = task_exit  (this is where `ret` of entry lands)
///   [stack_top-8 ] = entry      (initial rsp; first `ret` in switch_to jumps here)
/// SAFETY: stack memory owned by this task; written before scheduling.
unsafe fn write_frame(stack_top: u64, entry: Entry) -> bool {
    unsafe {
        let top = stack_top as *mut u64;
        core::ptr::write_volatile(top.offset(-2), task_exit as usize as u64); // top-16
        core::ptr::write_volatile(top.offset(-1), entry as usize as u64);     // top-8
    }
    true
}

unsafe fn set_saved_rsp(tid: usize, rsp: u64) {
    // SAFETY: boot-ordered; slot found by tid.
    unsafe {
        for t in TASKS.iter_mut() {
            if t.tid == tid && t.state != State::Free {
                t.saved_rsp = rsp;
                return;
            }
        }
    }
}

pub fn on_tick() {
    // SAFETY: current task bookkeeping only; called from IRQ0 handler.
    unsafe {
        TASKS[CURRENT].ticks_run += 1;
        PER_CPU.ticks = PER_CPU.ticks.wrapping_add(1);
        if TASKS[CURRENT].ticks_run >= 2 {
            yield_current();
        }
    }
}

pub fn yield_current() {
    let current = current_idx();
    if let Some(next) = pick_next(current) {
        if next != current {
            switch_to(next);
        }
    }
}

fn current_idx() -> usize {
    // SAFETY: aligned read.
    unsafe { core::ptr::read_volatile(core::ptr::addr_of!(CURRENT)) }
}

fn pick_next(from: usize) -> Option<usize> {
    // SAFETY: read-only scan of TASKS.
    unsafe {
        let mut i = (from + 1) % MAX_TASKS;
        let mut checked = 0;
        while checked < MAX_TASKS {
            if TASKS[i].state == State::Ready {
                return Some(i);
            }
            i = (i + 1) % MAX_TASKS;
            checked += 1;
        }
    }
    None
}

/// Real context switch: save current rsp, load target rsp, ret into the
/// target's saved continuation. THE unsafe boundary of the scheduler.
/// SAFETY: invariants â€” (1) both tasks' saved_rsp point at valid synthetic or
/// interrupted stacks; (2) called only from task context (never an IRQ
/// handler); (3) single core. on_tick() -> yield_current() -> here runs with
/// interrupts enabled but the tick that re-enters on_tick for the SAME task
/// cannot happen because the switch atomically changes CURRENT before ret.
/// If this invariant is violated the kernel faults â€” the #GP handler halts.
pub fn switch_to(next: usize) {
    let current = current_idx();
    if current == next {
        return;
    }
    // SAFETY: see above.
    unsafe {
        TASKS[current].state = State::Ready;
        TASKS[next].state = State::Running;
        TASKS[next].quantums += 1;
        TASKS[current].ticks_run = 0;
        CURRENT = next;
        PER_CPU.current_tid = TASKS[next].tid as u32;
        let cur = core::ptr::read_volatile(core::ptr::addr_of!(SWITCH_COUNT));
        core::ptr::write_volatile(core::ptr::addr_of!(SWITCH_COUNT), cur + 1);
        let saved = core::ptr::addr_of_mut!(TASKS[current].saved_rsp) as *mut u64;
        let target = core::ptr::read_volatile(core::ptr::addr_of!(TASKS[next].saved_rsp));
        core::arch::asm!(
            "mov %rsp, (%rax)\n",
            "mov %rbx, %rsp\n",
            "ret\n",
            in("rax") saved,
            in("rbx") target,
        );
    }
}

pub fn has_switched() -> bool {
    // SAFETY: aligned 64-bit read.
    unsafe { core::ptr::read_volatile(core::ptr::addr_of!(SWITCH_COUNT)) > 0 }
}

pub fn switch_count() -> u64 {
    // SAFETY: aligned 64-bit read.
    unsafe { core::ptr::read_volatile(core::ptr::addr_of!(SWITCH_COUNT)) }
}

pub extern "C" fn idle_entry() {
    loop {
        // SAFETY: idle halt; interrupts re-enter on_tick which may preempt us.
        unsafe { core::arch::asm!("hlt", options(nomem, nostack)) }
    }
}

pub extern "C" fn sysmon_entry() {
    serial("EUK: sysmon alive\n");
    loop {
        crate::ipc::audit_flush();
        yield_current();
    }
}

/// Called when a task entry returns: terminate, free the slot, switch away.
/// SAFETY: runs on the dying task's own stack. After switch_to's ret we can
/// never return here; the slot is marked Free BEFORE the switch so a spawn
/// during the switch (impossible single-core, but defensively) reuses it.
extern "C" fn task_exit() {
    let current = current_idx();
    unsafe {
        TASKS[current].state = State::Terminated;
    }
    // Do not free the stack frames here (per-task frame reclamation is tied
    // to process exit accounting in Phase D); mark Free so slots recycle.
    if let Some(next) = pick_next(current) {
        switch_to(next);
    } else {
        crate::fail("no runnable task after exit");
    }
    unreachable!()
}

