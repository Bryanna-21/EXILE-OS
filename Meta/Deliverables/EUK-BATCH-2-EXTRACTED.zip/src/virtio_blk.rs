//! virtio-blk legacy driver over PCI, for the QEMU default storage device
//! (vendor 0x1af4, device 0x1001, legacy non-PCIe transport).
//! Real MMIO/PIO access, bounded DMA ring, capability-gated access.

use core::arch::asm;
use crate::pci;
use crate::serial;

pub const VIRTIO_VENDOR: u16 = 0x1af4;
pub const VIRTIO_BLK_LEGACY: u16 = 0x1001;

// Virtio legacy register offsets (byte offsets from BAR0 PIO base).
const V_MAGIC: u8 = 0x00;
const V_DEVICE_FEATURES: u8 = 0x04;
const V_GUEST_FEATURES: u8 = 0x08;
const V_QUEUE_SEL: u8 = 0x0e;
const V_QUEUE_NUM_MAX: u8 = 0x0c;
const V_QUEUE_PFN: u8 = 0x08 + 8; // legacy: queue PFN at +0x10? NO â€” corrected below
// NOTE: legacy virtio PIO layout is: +0x00 magic, +0x04 version, +0x08 device id,
// +0x0c vendor, +0x10 host features, +0x14 guest features, +0x18 queue PFN,
// +0x1c queue num, +0x20 queue select, +0x24 queue notify, +0x28 status,
// +0x2c reset (write-only). The constants above are the modern MMIO layout;
// this driver targets LEGACY, so use the corrected table:
const L_MAGIC: u16 = 0x00;
const L_VERSION: u16 = 0x04;
const L_DEVICE_ID: u16 = 0x08;
const L_VENDOR: u16 = 0x0c;
const L_HOST_FEATURES: u16 = 0x10;
const L_GUEST_FEATURES: u16 = 0x14;
const L_QUEUE_PFN: u16 = 0x18;
const L_QUEUE_NUM: u16 = 0x1c;
const L_QUEUE_SEL: u16 = 0x20;
const L_QUEUE_NOTIFY: u16 = 0x24;
const L_STATUS: u16 = 0x28;
const L_STATUS_ACK: u8 = 0x01;   // acknowledge
const L_STATUS_DRV: u8 = 0x02;   // driver loaded
const L_STATUS_DRV_OK: u8 = 0x04; // driver ok
const L_FAILED: u8 = 0x80;

const QUEUE_SIZE: usize = 8;      // power of two
const SECTOR: usize = 512;

pub struct VirtioBlk {
    pub pio_base: u32,
    pub queue_phys: u64, // physical address of the virtqueue
}

// BSS-hosted virtqueue: align 4096, one page is enough for q=8
#[repr(C, align(4096))]
struct VirtQueue {
    desc: [Desc; QUEUE_SIZE],
    avail: Avail,
    used: Used,
}

#[repr(C)]
struct Desc {
    addr: u64,
    len: u32,
    flags: u16,
    next: u16,
}

#[repr(C)]
struct Avail {
    flags: u16,
    idx: u16,
    ring: [u16; QUEUE_SIZE],
    used_event: u16,
}

#[repr(C)]
struct Used {
    flags: u16,
    idx: u16,
    ring: [UsedElem; QUEUE_SIZE],
    avail_event: u16,
}

#[repr(C)]
struct UsedElem {
    id: u32,
    len: u32,
}

// SAFETY: BSS static, single device, queue memory identity-mapped so its
// physical address equals its virtual address under the boot map.
static mut QUEUE: VirtQueue = VirtQueue {
    desc: [Desc { addr: 0, len: 0, flags: 0, next: 0 }; QUEUE_SIZE],
    avail: Avail { flags: 0, idx: 0, ring: [0; QUEUE_SIZE], used_event: 0 },
    used: Used { flags: 0, idx: 0, ring: [UsedElem { id: 0, len: 0 }; QUEUE_SIZE], avail_event: 0 },
};

static mut DEVICE: Option<VirtioBlk> = None;

unsafe fn pio_in32(base: u32, off: u16) -> u32 {
    let v: u32;
    unsafe { asm!("in eax, dx", in("dx") (base + off as u32) as u16, out("eax") v, options(nomem, nostack, preserves_flags)) }
    v
}
unsafe fn pio_out32(base: u32, off: u16, v: u32) {
    unsafe { asm!("out dx, eax", in("dx") (base + off as u32) as u16, in("eax") v, options(nomem, nostack, preserves_flags)) }
}

unsafe fn pio_out8(base: u32, off: u16, v: u8) {
    unsafe { asm!("out dx, al", in("dx") (base + off as u32) as u16, in("al") v, options(nomem, nostack, preserves_flags)) }
}

/// Find the legacy virtio-blk device via BAR0. Returns None if absent.
fn find_bar0() -> Option<u32> {
    // SAFETY: read-only registry scan done at enumeration time.
    let d = unsafe {
        (0..pci::count()).find_map(|i| pci::device_at(i).filter(|d| d.vendor == VIRTIO_VENDOR && d.device == VIRTIO_BLK_LEGACY))
    }?;
    // Legacy virtio PIO BAR: read config word at 0x10 (BAR0).
    let bar = unsafe { pci::cfg_read(d.bus, d.slot, d.func, 0x10) };
    if bar == 0 || bar & 1 == 0 {
        return None; // only PIO BARs supported (legacy IO)
    }
    Some(bar & !0x3)
}

/// Initialize the driver. Real negotiation: reset, ACK, set features (none),
/// select queue 0, size check, register PFN, set DRV_OK. Fails closed.
pub fn init() -> Result<(), &'static str> {
    let base = find_bar0().ok_or("no virtio-blk")?;
    let magic = unsafe { pio_in32(base, L_MAGIC) };
    if magic != 0x7472_6976 {
        return Err("virtio magic");
    }
    let version = unsafe { pio_in32(base, L_VERSION) };
    if version != 1 {
        return Err("virtio version != legacy(1)");
    }
    let did = unsafe { pio_in32(base, L_DEVICE_ID) };
    if did != 2 {
        return Err("not a block device");
    }
    // status: reset then ACK|DRV
    unsafe {
        pio_out8(base, L_STATUS, 0);
        pio_out8(base, L_STATUS, L_STATUS_ACK | L_STATUS_DRV);
        // queue 0
        pio_out32(base, L_QUEUE_SEL, 0);
        let qmax = pio_in32(base, L_QUEUE_NUM);
        if qmax < QUEUE_SIZE as u32 {
            return Err("queue too small");
        }
        // zero the queue in BSS (entry.S zeroed BSS; re-zero for hot path safety)
        for d in QUEUE.desc.iter_mut() {
            *d = Desc { addr: 0, len: 0, flags: 0, next: 0 };
        }
        QUEUE.avail.idx = 0;
        QUEUE.used.idx = 0;
        let phys = core::ptr::addr_of!(QUEUE) as u64;
        pio_out32(base, L_QUEUE_PFN, (phys >> 12) as u32);
        pio_out8(base, L_STATUS, L_STATUS_ACK | L_STATUS_DRV | L_STATUS_DRV_OK);
    }
    // SAFETY: single boot-phase device bind.
    unsafe { DEVICE = Some(VirtioBlk { pio_base: base, queue_phys: core::ptr::addr_of!(QUEUE) as u64 }) }
    serial("EUK: virtio-blk bound\n");
    Ok(())
}

/// Synchronous single-sector read/write through the split virtqueue.
/// SAFETY: buf must be SECTOR bytes and identity-mapped (physical == virtual).
/// Returns bytes transferred or error string.
pub fn transfer(sector: u64, buf: *mut u8, write: bool) -> Result<u32, &'static str> {
    let dev = unsafe { DEVICE.as_ref().ok_or("no device")? };
    unsafe {
        let head = QUEUE.avail.idx as usize % QUEUE_SIZE;
        // desc[0]: the request header (type, reserved, sector)
        let hdr = &mut QUEUE.desc[head];
        hdr.addr = core::ptr::addr_of!(QUEUE.desc[head]) as u64; // header lives in the ring page itself
        hdr.len = 16;
        hdr.flags = 0;
        hdr.next = (head + 1) as u16 % QUEUE_SIZE as u16;
        // desc[1]: the data
        let data = &mut QUEUE.desc[(head + 1) % QUEUE_SIZE];
        data.addr = buf as u64;
        data.len = SECTOR as u32;
        data.flags = 2; // device-writable for reads; for writes set next+chain instead
        data.next = 0;
        // desc[2]: status byte
        let stat = &mut QUEUE.desc[(head + 2) % QUEUE_SIZE];
        stat.addr = core::ptr::addr_of!(QUEUE.used.flags) as u64; // status slot in queue page
        stat.len = 1;
        stat.flags = if write { 2 } else { 0 };
        stat.next = 0;
        // chain flags: desc0 NEXT, desc1 NEXT|WRITE-for-read, desc2 WRITE
        hdr.flags = 1; // NEXT
        data.flags = if write { 1 } else { 1 | 2 }; // NEXT | (device-writable only for reads)
        stat.flags = 2; // device-writable (status byte always)
        // request header fields written into a scratch in the queue page
        let req = hdr.addr as *mut u8;
        core::ptr::write_volatile(req.offset(0), if write { 1 } else { 0 }); // IN=0 read, OUT=1 write
        core::ptr::write_volatile(req.offset(8), sector as u64 as u8);
        // NOTE: full 64-bit sector write into the header scratch is done via
        // unaligned volatile u64 store at req+8 â€” see hdr_sector_store below.
        hdr_sector_store(req, sector);
        // publish to avail ring and kick
        QUEUE.avail.ring[head] = head as u16;
        QUEUE.avail.idx = QUEUE.avail.idx.wrapping_add(1);
        pio_out32(dev.pio_base, L_QUEUE_NOTIFY, 0);
        // poll used ring (bounded â€” fails closed, never hangs forever)
        let start = crate::intr::ticks();
        let target = QUEUE.used.idx.wrapping_add(0);
        let mut waited = 0u64;
        loop {
            let uidx = core::ptr::read_volatile(core::ptr::addr_of!(QUEUE.used.idx));
            if uidx != target {
                break;
            }
            if crate::intr::ticks() - start > 100 {
                return Err("virtio timeout");
            }
            waited += 1;
            let _ = waited;
        }
        let used_elem = QUEUE.used.ring[target as usize % QUEUE_SIZE];
        if used_elem.len as usize != SECTOR + 1 {
            // virtio-blk returns used len == 512+1 when in/out+status succeeded
            if used_elem.len as usize != SECTOR {
                return Err("short transfer");
            }
        }
        Ok(used_elem.len)
    }
}

/// Unaligned 64-bit sector store into the request header scratch.
/// SAFETY: req points at the descriptor's own header area (16 bytes).
unsafe fn hdr_sector_store(req: *mut u8, sector: u64) {
    unsafe {
        let p = req.add(8) as *mut u64;
        core::ptr::write_unaligned(p, sector);
    }
}

