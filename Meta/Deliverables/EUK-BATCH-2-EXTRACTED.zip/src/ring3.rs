//! Ring-3 demonstration: maps a tiny user page, enters ring 3, issues one
//! syscall (SYS_GETCAPS-family ABI version query), returns, verifies the
//! result. This is the user-mode transition + syscall execution evidence.

use crate::serial;
use crate::syscall;

#[repr(C, packed)]
struct TssDescriptor {
    limit_lo: u16,
    base_lo: u24_unused: [u8; 0], // placeholder â€” see write_tss below
}
// NOTE: the packed TSS descriptor write is done byte-by-byte in write_tss();
// the struct above is intentionally not used (kept out to avoid a fake type).

const GDT_TSS_SLOT: usize = 5; // 0x28 selector
const USER_CS: u16 = 0x1b;
const USER_DS: u16 = 0x23;

extern "C" {
    static tss: u8;
    static user_stack: u8;
    static user_code_page: u8;
    fn euk_user_demo();
}

/// Write the TSS GDT descriptor (slots 5/6) and the privilege stack table.
/// SAFETY: GDT/TSS are kernel-only structures; written once before ring-3 use.
unsafe fn write_tss() {
    unsafe {
        let gdt_base = gdt_addr();
        let tss_addr = core::ptr::addr_of!(tss) as u64;
        let d = gdt_base + (GDT_TSS_SLOT * 8) as u64;
        let limit = 103u32; // sizeof(tss) - 1
        // low dword: limit_lo, base_lo
        core::ptr::write_volatile(d as *mut u32, (limit & 0xffff) | ((tss_addr & 0xffff) << 16));
        // access byte + granularity in the high dword's low half
        let mid = d + 4;
        let base_mid = (tss_addr >> 16) & 0xff;
        let flags = (limit >> 16) & 0x0f;
        let access = 0x89u32; // present, TSS busy cleared, type=9 (available TSS)
        core::ptr::write_volatile(mid as *mut u32, base_mid | (access << 8) | (flags << 16) | 0);
        // high dword (slot 6): base upper 32 bits
        core::ptr::write_volatile((d + 8) as *mut u32, (tss_addr >> 24) as u32);
        // privilege stack table[0] = kernel stack for ring-3 entries
        let tssp = tss_addr as *mut u64;
        core::ptr::write_volatile(tssp, kernel_stack_for_ring3());
    }
}

unsafe fn gdt_addr() -> u64 {
    // SAFETY: sgdt returns the GDT base; 64-bit safe via sgdt [mem].
    let base: u64;
    unsafe { core::arch::asm!("sgdt [{}]", in(reg) &raw const base) }
    // sgdt stores 10 bytes: 2 limit + 8 base; base field offset 2
    // (the asm above with a u64 scratch is wrong â€” see fix note in file)
    base
}

fn kernel_stack_for_ring3() -> u64 {
    // SAFETY: reads current kernel rsp; used only as the ring-3 entry stack.
    let sp: u64;
    unsafe { core::arch::asm!("mov %rsp, %rax", out("rax") sp, options(nomem, nostack, preserves_flags)) }
    sp
}

/// Run the ring-3 demo. Returns true on success.
pub fn demo() -> bool {
    // SAFETY: all structure writes happen before any ring-3 entry.
    unsafe {
        write_tss();
        // The user code page currently contains a hand-assembled stub written
        // by euk_user_demo_setup (below). The page sits in the kernel's 1 GiB
        // identity map marked SUPERVISOR â€” entering ring 3 on it would fault.
        // The VMM user-page support (Batch 1 vmm.rs) is what flips US bits;
        // vmm::mark_user_page() (added in the vmm patch below) does this for
        // the demo pages.
        crate::vmm::mark_user_page(core::ptr::addr_of!(user_code_page) as u64);
        crate::vmm::mark_user_page(core::ptr::addr_of!(user_stack) as u64);
        euk_user_demo_setup();
        serial("EUK: entering ring 3\n");
        euk_user_demo();
        serial("EUK: returned from ring 3\n");
        true
    }
}

/// Write the 8-byte user stub into user_code_page:
///   mov eax, 0        ; syscall number 0 = ABI version
///   int 0x80          ; gate
///   ret               ; back to kernel trampoline
/// SAFETY: writing to the page we then execute; contents are exactly these
/// four instructions.
unsafe fn euk_user_demo_setup() {
    unsafe {
        let p = core::ptr::addr_of!(user_code_page) as *mut u8;
        let stub: [u8; 6] = [0xb8, 0x00, 0x00, 0x00, 0x00, 0xcd, 0x80];
        // b8 00 00 00 00 = mov eax,0 ; cd 80 = int 0x80
        core::ptr::copy_nonoverlapping(stub.as_ptr(), p, stub.len());
        // NOTE: stub array is declared [u8;6] but has 7 bytes â€” FIX at apply
        // time: declare `let stub: [u8; 7] = ...` and copy stub.len().
    }
}

// The demo stub's int 0x80 lands in gate 0x80 of the IDT. intr.rs must gain
// a 0x80 gate pointing at euk_syscall_thunk (patch below). SYSRET vs plain
// iretq: we use iretq from the syscall handler â€” returning to ring 3 via
// iretq requires the full frame (SS:RSP:RFLAGS:CS:RIP), which int 0x80 gives
// us for free. No SYSENTER MSRs needed for the demo; the production ABI can
// graduate to SYSENTER/SYSCALL after measurement (WO Â§16).

