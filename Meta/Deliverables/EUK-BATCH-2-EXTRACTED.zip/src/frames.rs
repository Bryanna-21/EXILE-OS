//! Live physical frame allocator. BATCH-2: no behavioral change to the
//! allocator itself (Batch 1 logic stands); the fix is testability â€” the
//! host-test shim (test.py v2) provides `memory::Region`, so this file now
//! hosts its tests without kernel coupling.

use crate::memory::Region;

pub const PAGE: u64 = 4096;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FrameError {
    NoMemory,
}

pub struct FrameAlloc {
    regions: [Extent; 32],
    region_count: usize,
    cursor_region: usize,
    cursor_frame: u64,
    free: u64,
}

#[derive(Clone, Copy)]
struct Extent {
    start: u64,
    end: u64,
}

impl FrameAlloc {
    pub fn new(map: &[Region], reserved_end: u64, ceiling: u64) -> Result<Self, FrameError> {
        let mut regions = [Extent { start: 0, end: 0 }; 32];
        let mut region_count = 0usize;
        let mut free = 0u64;
        for r in map.iter() {
            if r.kind != 1 {
                continue;
            }
            let start = r.start.max(reserved_end).next_multiple_of(PAGE);
            let end = r.end.min(ceiling) & !(PAGE - 1);
            if start < end && region_count < regions.len() {
                regions[region_count] = Extent { start, end };
                region_count += 1;
                free += (end - start) / PAGE;
            }
        }
        if region_count == 0 {
            return Err(FrameError::NoMemory);
        }
        Ok(Self { regions, region_count, cursor_region: 0, cursor_frame: regions[0].start, free })
    }

    pub fn alloc(&mut self) -> Result<u64, FrameError> {
        let mut scanned = 0usize;
        loop {
            let ext = self.regions[self.cursor_region];
            if self.cursor_frame + PAGE <= ext.end {
                let frame = self.cursor_frame;
                self.cursor_frame += PAGE;
                self.free -= 1;
                return Ok(frame);
            }
            self.cursor_region = (self.cursor_region + 1) % self.region_count;
            self.cursor_frame = self.regions[self.cursor_region].start;
            scanned += 1;
            if scanned > self.region_count {
                return Err(FrameError::NoMemory);
            }
        }
    }

    pub fn free_bytes(&self) -> u64 {
        self.free * PAGE
    }

    pub fn total_bytes(&self) -> u64 {
        self.regions[..self.region_count].iter().map(|e| e.end - e.start).sum()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::memory::Region;

    fn frame_ok() -> FrameAlloc {
        FrameAlloc::new(
            &[
                Region::new(0, 32 * 1024 * 1024, 1).unwrap(),
                Region::new(0x8000_0000, 8 * 1024 * 1024, 1).unwrap(),
            ],
            16 * 1024 * 1024,
            0x4000_0000,
        )
        .unwrap()
    }

    #[test]
    fn skips_reserved_prefix() {
        let a = frame_ok();
        assert_eq!(a.total_bytes(), 16 * 1024 * 1024 + 8 * 1024 * 1024);
    }

    #[test]
    fn allocs_aligned_and_increasing() {
        let mut a = frame_ok();
        let f = a.alloc().unwrap();
        assert_eq!(f % PAGE, 0);
        assert!(f >= 16 * 1024 * 1024);
        assert_eq!(a.alloc().unwrap(), f + PAGE);
    }

    #[test]
    fn exhausts_to_err_not_panic() {
        let mut a = FrameAlloc::new(
            &[Region::new(0, 32 * 1024 * 1024, 1).unwrap()],
            16 * 1024 * 1024,
            32 * 1024 * 1024,
        )
        .unwrap();
        let total = a.free_bytes() / PAGE;
        for _ in 0..total {
            a.alloc().unwrap();
        }
        assert_eq!(a.alloc(), Err(FrameError::NoMemory));
    }

    #[test]
    fn wraps_to_second_region() {
        let mut a = frame_ok();
        // first region: 16 MiB usable â†’ 4096 frames
        for _ in 0..4096 {
            a.alloc().unwrap();
        }
        let f = a.alloc().unwrap();
        assert_eq!(f, 0x8000_0000); // second region start
    }

    #[test]
    fn no_usable_regions_is_error() {
        assert!(FrameAlloc::new(&[Region::new(0, 1024, 2).unwrap()], 0, 1024).is_err());
    }

    #[test]
    fn reserved_kind_only_skipped() {
        let a = FrameAlloc::new(
            &[
                Region::new(0, 32 * 1024 * 1024, 1).unwrap(),
                Region::new(0, 4 * 1024 * 1024, 3).unwrap(), // ACPI-ish, skipped
            ],
            16 * 1024 * 1024,
            32 * 1024 * 1024,
        )
        .unwrap();
        assert_eq!(a.total_bytes(), 16 * 1024 * 1024);
    }
}

