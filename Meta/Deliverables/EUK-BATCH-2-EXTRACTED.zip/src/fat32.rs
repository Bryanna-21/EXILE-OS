//! Minimal FAT32 read support over virtio-blk: BPB validation, cluster chain
//! walking, bounded directory lookup, capability-checked at fs.rs boundary.
//! Write support deliberately NOT implemented (WO: no fake functionality;
//! read-only is the honest scope until the write path is boot-tested).

use crate::virtio_blk;

pub const SECTOR: usize = 512;
const CLUSTER_SIZE: usize = 4096;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FatError {
    NoDevice,
    BadSignature,
    BadBpb,
    OutOfRange,
    NotFound,
    IoError,
}

pub struct Fat32 {
    bytes_per_sector: u16,
    sectors_per_cluster: u8,
    reserved_sectors: u16,
    num_fats: u8,
    root_cluster: u32,
    fat_start_sector: u32,
    cluster_start_sector: u32,
}

static mut FS: Option<Fat32> = None;
static mut SCRATCH: [u8; SECTOR] = [0; SECTOR];
static mut CLUSTER_BUF: [u8; CLUSTER_SIZE] = [0; CLUSTER_SIZE];

fn u16_at(b: &[u8], i: usize) -> u16 {
    u16::from_le_bytes([b[i], b[i + 1]])
}
fn u32_at(b: &[u8], i: usize) -> u32 {
    u32::from_le_bytes([b[i], b[i + 1], b[i + 2], b[i + 3]])
}

fn is_eoc(c: u32) -> bool {
    c >= 0x0fff_fff8
}

pub fn mount() -> Result<(), FatError> {
    if virtio_blk::init().is_err() {
        return Err(FatError::NoDevice);
    }
    // read boot sector (sector 0) into SCRATCH
    let ok = read_sector(0).map_err(|_| FatError::IoError)?;
    if !ok {
        return Err(FatError::IoError);
    }
    // SAFETY: SCRATCH written by read_sector above.
    let b: &[u8; SECTOR] = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(SCRATCH)) };
    if &b[0x36..0x3e] != b"FAT32   " && &b[0x52..0x5a] != b"FAT32   " {
        return Err(FatError::BadSignature);
    }
    let bytes_per_sector = u16_at(b, 11);
    let sectors_per_cluster = b[13];
    let reserved_sectors = u16_at(b, 14);
    let num_fats = b[16];
    if bytes_per_sector as usize != SECTOR {
        return Err(FatError::BadBpb); // only 512-byte sectors supported
    }
    if sectors_per_cluster == 0 || num_fats == 0 {
        return Err(FatError::BadBpb);
    }
    let fat_start_sector = reserved_sectors as u32;
    let fat_sectors = u32_at(b, 36);
    let cluster_start_sector = fat_start_sector + fat_sectors * num_fats as u32;
    // SAFETY: boot-phase single write.
    unsafe {
        FS = Some(Fat32 {
            bytes_per_sector,
            sectors_per_cluster,
            reserved_sectors,
            num_fats,
            root_cluster: u32_at(b, 44),
            fat_start_sector,
            cluster_start_sector,
        })
    }
    Ok(())
}

fn fs() -> &'static Fat32 {
    // SAFETY: set by mount before use.
    unsafe { FS.as_ref().expect("fat32 before mount") }
}

fn read_sector(sector: u32) -> Result<bool, ()> {
    // SAFETY: SCRATCH is a kernel static; transfer() requires identity-mapped
    // buffer of exactly SECTOR bytes â€” SCRATCH qualifies.
    match virtio_blk::transfer(sector as u64, core::ptr::addr_of_mut!(SCRATCH) as *mut u8, false) {
        Ok(n) => Ok(n >= 512),
        Err(_) => Err(()),
    }
}

fn next_cluster(cluster: u32) -> Result<u32, FatError> {
    let f = fs();
    let fat_offset = (cluster as u64) * 4;
    let sector = f.fat_start_sector as u64 + fat_offset / SECTOR as u64;
    if sector > u32::MAX as u64 {
        return Err(FatError::OutOfRange);
    }
    if read_sector(sector as u32).is_err() {
        return Err(FatError::IoError);
    }
    // SAFETY: SCRATCH holds the FAT sector just read.
    let b: &[u8; SECTOR] = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(SCRATCH)) };
    let off = (fat_offset % SECTOR as u64) as usize;
    if off + 4 > SECTOR {
        return Err(FatError::OutOfRange); // FAT entry straddles sectors: not supported yet
    }
    Ok(u32_at(b, off) & 0x0fff_ffff)
}

/// Read one full cluster into CLUSTER_BUF. Bounded: only CLUSTER_SIZE bytes.
fn read_cluster(cluster: u32) -> Result<(), FatError> {
    let f = fs();
    let sectors = f.sectors_per_cluster as usize;
    if sectors * SECTOR > CLUSTER_SIZE {
        return Err(FatError::BadBpb); // cluster larger than our buffer: unsupported
    }
    let first = f.cluster_start_sector + (cluster - 2) * f.sectors_per_cluster as u32;
    for i in 0..sectors {
        if read_sector(first + i as u32).is_err() {
            return Err(FatError::IoError);
        }
        // SAFETY: copy SCRATCH into the right slice of CLUSTER_BUF.
        let dst = unsafe { core::ptr::addr_of_mut!(CLUSTER_BUF) };
        let src = unsafe { core::ptr::addr_of!(SCRATCH) };
        unsafe {
            core::ptr::copy_nonoverlapping(src as *const u8, (dst as *mut u8).add(i * SECTOR), SECTOR);
        }
    }
    Ok(())
}

/// Look up a short (8.3) name in the root directory. Bounded walk.
pub fn lookup_root(name: &[u8]) -> Result<Option<(u32, u32)>, FatError> {
    if name.is_empty() || name.len() > 11 {
        return Ok(None);
    }
    let f = fs();
    let mut cluster = f.root_cluster;
    let mut hops = 0u32;
    loop {
        read_cluster(cluster)?;
        // SAFETY: CLUSTER_BUF filled by read_cluster.
        let buf: &[u8; CLUSTER_SIZE] = unsafe { core::ptr::read_volatile(core::ptr::addr_of!(CLUSTER_BUF)) };
        for entry in buf.chunks(32).take(CLUSTER_SIZE / 32) {
            if entry[0] == 0x00 {
                return Ok(None); // end of directory
            }
            if entry[0] == 0xe5 {
                continue; // deleted
            }
            if entry[11] & 0x08 != 0 {
                continue; // LFN entry
            }
            let nm = &entry[..11];
            let nm = match core::str::from_utf8(&nm[..11]) {
                Ok(s) => s,
                Err(_) => continue,
            };
            if nm.trim_end_matches(' ') == core::str::from_utf8(name).unwrap_or("?") {
                let cluster_hi = u16_at(entry, 20) as u32;
                let cluster_lo = u16_at(entry, 26) as u32;
                let size = u32_at(entry, 28);
                return Ok(Some(((cluster_hi << 16) | cluster_lo, size)));
            }
        }
        cluster = next_cluster(cluster)?;
        if is_eoc(cluster) {
            return Ok(None);
        }
        hops += 1;
        if hops > 64 {
            return Err(FatError::OutOfRange); // unbounded chain protection
        }
    }
}

