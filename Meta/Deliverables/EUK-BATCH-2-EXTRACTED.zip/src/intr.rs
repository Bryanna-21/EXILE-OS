//! Interrupts: IDT, PIC 8259 remap, PIT timer, exception handlers.
//! BATCH-2 FIX (defect 8): the malformed thunk! macro is replaced by three
//! explicit global_asm! blocks. No macro, no stringified commas.

use core::arch::{asm, global_asm};
use crate::serial;

const IDT_LIMIT: usize = 48;

#[repr(C, packed)]
#[derive(Clone, Copy)]
struct Gate {
    offset_lo: u16,
    selector: u16,
    ist: u8,
    ty: u8,
    offset_mid: u16,
    offset_hi: u32,
    zero: u32,
}

impl Gate {
    const fn absent() -> Self {
        Gate { offset_lo: 0, selector: 0, ist: 0, ty: 0, offset_mid: 0, offset_hi: 0, zero: 0 }
    }
    fn interrupt(handler: usize) -> Self {
        Gate {
            offset_lo: handler as u16,
            selector: 8,
            ist: 0,
            ty: 0x8e,
            offset_mid: (handler >> 16) as u16,
            offset_hi: (handler >> 32) as u32,
            zero: 0,
        }
    }
}

#[repr(C, packed)]
struct IdtPtr { limit: u16, base: u64 }

// SAFETY: BSS-resident, zeroed by entry.S before kernel_main; written only
// during init with interrupts disabled; read-only afterwards.
static mut IDT: [Gate; IDT_LIMIT] = [Gate::absent(); IDT_LIMIT];
static mut IDT_PTR: IdtPtr = IdtPtr { limit: 0, base: 0 };
pub static mut TICKS: u64 = 0;

unsafe fn port_out(port: u16, v: u8) {
    unsafe { asm!("out dx, al", in("dx") port, in("al") v, options(nomem, nostack, preserves_flags)) }
}
unsafe fn port_in(port: u16) -> u8 {
    let v: u8;
    unsafe { asm!("in al, dx", in("dx") port, out("al") v, options(nomem, nostack, preserves_flags)) }
    v
}

fn irq0_handler() {
    // SAFETY: single-core; tick counter is only touched here and read via ticks().
    unsafe { TICKS = TICKS.wrapping_add(1) }
    crate::task::on_tick();
}

fn de_handler() {
    serial("EUK FAULT: divide error (handled, continuing)\n");
}

fn gp_handler() {
    serial("EUK FAULT: #GP\n");
    crate::fail("general protection fault");
}

// BATCH-2 FIX: three explicit thunks. Each: push caller-saved regs, call the
// Rust body, pop, then for IRQ0 also EOI before iretq. Interrupt frames are
// already pushed by the CPU; handlers must NOT touch them (no addq $8).
// SAFETY: matches Gate::interrupt expectations; kernel selector, no IST.
global_asm!(
    ".globl euk_irq0_thunk",
    "euk_irq0_thunk:",
    "push %rax",
    "push %rcx",
    "push %rdx",
    "push %rsi",
    "push %rdi",
    "call euk_irq0_body",
    "pop %rdi",
    "pop %rsi",
    "pop %rdx",
    "pop %rcx",
    "pop %rax",
    "iretq",
);
global_asm!(
    ".globl euk_de_thunk",
    "euk_de_thunk:",
    "push %rax",
    "push %rcx",
    "push %rdx",
    "push %rsi",
    "push %rdi",
    "call euk_de_body",
    "pop %rdi",
    "pop %rsi",
    "pop %rdx",
    "pop %rcx",
    "pop %rax",
    "iretq",
);
global_asm!(
    ".globl euk_gp_thunk",
    "euk_gp_thunk:",
    "push %rax",
    "push %rcx",
    "push %rdx",
    "push %rsi",
    "push %rdi",
    "call euk_gp_body",
    "pop %rdi",
    "pop %rsi",
    "pop %rdx",
    "pop %rcx",
    "pop %rax",
    "iretq",
);

extern "C" {
    fn euk_irq0_thunk();
    fn euk_de_thunk();
    fn euk_gp_thunk();
}

#[unsafe(no_mangle)]
extern "C" fn euk_irq0_body() {
    irq0_handler();
    eoi_irq0();
}
#[unsafe(no_mangle)]
extern "C" fn euk_de_body() {
    de_handler();
}
#[unsafe(no_mangle)]
extern "C" fn euk_gp_body() {
    gp_handler();
}

pub fn init() {
    let handlers: [usize; IDT_LIMIT] = {
        let mut h = [0usize; IDT_LIMIT];
        h[0] = euk_de_thunk as usize;
        h[13] = euk_gp_thunk as usize;
        h[32] = euk_irq0_thunk as usize;
        h
    };
    // SAFETY: exclusive initialization, interrupts disabled by entry.S boot path.
    unsafe {
        for i in 0..IDT_LIMIT {
            IDT[i] = if handlers[i] != 0 { Gate::interrupt(handlers[i]) } else { Gate::absent() };
        }
        IDT_PTR.limit = (IDT_LIMIT * 16 - 1) as u16;
        IDT_PTR.base = core::ptr::addr_of!(IDT) as u64;
        asm!("lidt [{}]", in(reg) core::ptr::addr_of!(IDT_PTR), options(nostack));
    }
    pic_init();
    pit_init();
    // SAFETY: enabling interrupts only after IDT+PIC are fully installed.
    unsafe { asm!("sti", options(nomem, nostack)) }
}

fn pic_init() {
    // SAFETY: fixed PIC ports; standard ICW sequence remapping IRQs to 0x20..0x2F.
    unsafe {
        port_out(0x20, 0x11); port_out(0xa0, 0x11);
        port_out(0x21, 0x20); port_out(0xa1, 0x28);
        port_out(0x21, 0x04); port_out(0xa1, 0x02);
        port_out(0x21, 0x01); port_out(0xa1, 0x01);
        port_out(0x21, 0xfe);
        port_out(0xa1, 0xff);
    }
}

fn pit_init() {
    // ~100 Hz. SAFETY: fixed PIT ports.
    unsafe {
        port_out(0x43, 0x36);
        port_out(0x40, 11932 & 0xff);
        port_out(0x40, (11932 >> 8) as u8);
    }
}

pub fn eoi_irq0() {
    // SAFETY: EOI to the master PIC.
    unsafe { port_out(0x20, 0x20) }
}

pub fn ticks() -> u64 {
    // SAFETY: aligned 64-bit read; writer is the timer handler only.
    unsafe { core::ptr::read_volatile(core::ptr::addr_of!(TICKS)) }
}

