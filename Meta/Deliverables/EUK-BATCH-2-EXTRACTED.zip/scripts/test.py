#!/usr/bin/env python3
"""Host-side unit tests for portable EUK logic (v2).

Coverage: memory.rs, capability.rs (self-contained, direct rustc --test) and
frames.rs (needs crate::memory::Region, so it is compiled inside a generated
shim crate). IPC/queue mechanics are covered by capability-adjacent tests;
ipc.rs itself remains kernel-coupled (statics) and is validated by the boot
selftests 10-13, not here. Kernel-coupled modules are NOT host-tested here â€”
that separation is deliberate and documented per WO Â§5."""
import os
import pathlib
import shutil
import subprocess

root = pathlib.Path(__file__).resolve().parents[1]
build_dir = root / 'build'
shim_dir = build_dir / 'shim-crate'
build_dir.mkdir(exist_ok=True)

rustc = os.environ.get('EUK_HOST_RUSTC', 'rustc')

def run(cmd, **kw):
    print('+', ' '.join(str(c) for c in cmd), flush=True)
    subprocess.run([str(c) for c in cmd], check=True, **kw)

# --- 1. self-contained modules -------------------------------------------
for mod in ('memory', 'capability'):
    src = root / 'src' / f'{mod}.rs'
    out = build_dir / f'{mod}-tests'
    print(f'== host tests: {mod}.rs')
    run([rustc, '--edition=2024', '--test', src, '-o', out])
    run([out])

# --- 2. frames.rs inside a generated shim crate --------------------------
# frames.rs uses `crate::memory::Region`; give it a real crate root that
# declares memory + frames as modules.
if shim_dir.exists():
    shutil.rmtree(shim_dir)
(shim_dir / 'src').mkdir(parents=True)
(shim_dir / 'Cargo.toml').write_text(
    '[package]\nname = "euk-host-shim"\nversion = "0.1.0"\nedition = "2024"\n'
)
(shim_dir / 'src' / 'lib.rs').write_text(
    '#![cfg_attr(not(test), allow(dead_code))]\n'
    'pub mod memory;\n'
    'pub mod frames;\n'
)
shutil.copyfile(root / 'src' / 'memory.rs', shim_dir / 'src' / 'memory.rs')
shutil.copyfile(root / 'src' / 'frames.rs', shim_dir / 'src' / 'frames.rs')
print('== host tests: frames.rs (shim crate)')
run(['cargo', 'test', '--manifest-path', shim_dir / 'Cargo.toml', '--offline'], cwd=shim_dir)

print('ALL HOST TESTS PASSED')

